"""8×8 v3.3: 独立包修复 + 二维支持域扫描

1. 独立包: 无绝对路径, BASE_DIR=脚本目录, 本地mylib
2. 二维支持域: canonical区域φ=0~45°, θ=35~60°, 步长1°/5°
3. 每点保存完整诊断+权值(valid时)
4. 状态分离: direct_solver_outcome / final_label / rotation_source
5. Fallback标记degraded
"""

import os, sys, time, json, csv, shutil
import numpy as np

# 独立包: 用脚本目录作为BASE_DIR
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MYLIB_DIR = os.path.join(BASE_DIR, 'mylib')
sys.path.insert(0, MYLIB_DIR)
sys.path.insert(0, BASE_DIR)

# 本地导入(不依赖外部project目录)
from antenna_calc import taylor_2d_separable, angular_distance_deg
import cvxpy as cp

OUTPUT_DIR = os.path.join(BASE_DIR, 'output')
os.makedirs(OUTPUT_DIR, exist_ok=True)

LAMBDA_MM = 23.9834
NX = NY = 8
N_ELEM = 64
SLL_DESIGN = 30
FREQ_GHZ = 12.5
EPS_NULL = 0.0316  # -30dB
EPS_NULL_CHECK_DB = 28.0
N_COARSE = 11
N_CUTTING_ITERS = 10
N_EVAL = 81
TRUST_RADIUS_FACTOR = 0.3
NORM_RATIO = 1.5


def load_real_coordinates():
    csv_path = os.path.join(BASE_DIR, 'element_port_map.csv')
    coords = []; normals = []
    with open(csv_path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            x = float(row['x_mm']) / LAMBDA_MM
            y = float(row['y_mm']) / LAMBDA_MM
            z = float(row['z_mm']) / LAMBDA_MM
            coords.append((x, y, z))
            normals.append((float(row['ew_x']), float(row['ew_y']), float(row['ew_z'])))
    return np.array(coords), np.array(normals)


def steering_vec_3d(px, py, pz, u, v, w):
    k = 2 * np.pi
    return np.exp(1j * k * (px * u + py * v + pz * w))

def coordinate_taylor_3d(px, py, pz, amp_x, amp_y, theta0, phi0):
    k = 2 * np.pi
    u0 = np.sin(np.deg2rad(theta0)) * np.cos(np.deg2rad(phi0))
    v0 = np.sin(np.deg2rad(theta0)) * np.sin(np.deg2rad(phi0))
    w0 = np.cos(np.deg2rad(theta0))
    amp = np.outer(amp_y, amp_x).ravel()
    phase = k * (px * u0 + py * v0 + pz * w0)
    return amp * np.exp(1j * phase)

def normalize_weights(w, px, py, pz, u0, v0, w0):
    a_main = steering_vec_3d(px, py, pz, u0, v0, w0)
    resp = np.conj(a_main) @ w
    if np.abs(resp) < 1e-12: return w
    return w / resp

def uv_to_uvw(u, v):
    return np.sqrt(np.maximum(1.0 - u**2 - v**2, 0))

def get_null_dirs(theta0, phi0):
    if theta0 < 10:
        return [(30, 0), (30, 90), (30, 180), (30, 270)]
    return [
        (theta0, (phi0 + 90) % 360),
        (theta0, (phi0 + 180) % 360),
        (theta0, (phi0 + 270) % 360),
        (min(theta0 + 25, 85), (phi0 + 45) % 360),
    ]

def angular_distance_uvw(q1, q2):
    q1 = np.asarray(q1, dtype=float); q2 = np.asarray(q2, dtype=float)
    n1 = np.linalg.norm(q1); n2 = np.linalg.norm(q2)
    if n1 < 1e-10 or n2 < 1e-10: return 180.0
    return float(np.degrees(np.arccos(np.clip(np.dot(q1, q2) / (n1 * n2), -1.0, 1.0))))


def solve_socp(px, py, pz, u0, v0, w0, sl_u, sl_v, sl_w,
               null_u, null_v, null_w, w_taylor_n, trust_r, norm_max, peaks=None):
    n = len(px)
    w = cp.Variable(n, complex=True); t = cp.Variable()
    a_main = steering_vec_3d(px, py, pz, u0, v0, w0)
    cons = [a_main.conj() @ w == 1.0 + 0j]
    for u_s, v_s, w_s in zip(sl_u, sl_v, sl_w):
        cons.append(cp.norm(steering_vec_3d(px, py, pz, u_s, v_s, w_s).conj() @ w, 2) <= t)
    for u_n, v_n, w_n in zip(null_u, null_v, null_w):
        cons.append(cp.norm(steering_vec_3d(px, py, pz, u_n, v_n, w_n).conj() @ w, 2) <= EPS_NULL)
    cons.append(cp.norm(w - (w_taylor_n.real + 1j * w_taylor_n.imag), 2) <= trust_r)
    cons.append(cp.norm(w, 2) <= norm_max)
    if peaks:
        for u_p, v_p, w_p in peaks:
            cons.append(cp.norm(steering_vec_3d(px, py, pz, u_p, v_p, w_p).conj() @ w, 2) <= 1.0)
    prob = cp.Problem(cp.Minimize(t), cons)
    try:
        prob.solve(solver=cp.SCS, verbose=False, max_iters=20000)
        if prob.status not in ['optimal', 'optimal_inaccurate']:
            return None, 'solver_failed'
    except Exception:
        return None, 'solver_failed'
    return w.value, 'optimal'


def eval_full(w, px, py, pz, theta0, phi0, null_dirs, n_eval=N_EVAL):
    k = 2 * np.pi
    u0 = np.sin(np.deg2rad(theta0)) * np.cos(np.deg2rad(phi0))
    v0 = np.sin(np.deg2rad(theta0)) * np.sin(np.deg2rad(phi0))
    w0 = np.cos(np.deg2rad(theta0))
    u = np.linspace(-1, 1, n_eval); v = np.linspace(-1, 1, n_eval)
    ug, vg = np.meshgrid(u, v, indexing='ij')
    vis = (ug**2 + vg**2) <= 1.0; wg = uv_to_uvw(ug, vg)
    bw = 0.886 * 2.0 / NX * 180 / np.pi
    exc = np.sin(np.deg2rad(3.0 * bw / max(np.cos(np.deg2rad(theta0)), 0.1)))
    dist = np.sqrt((ug - u0)**2 + (vg - v0)**2)
    sl_mask = (dist >= exc) & vis
    vf = vis.ravel(); uf = ug.ravel(); vf2 = vg.ravel(); wf = wg.ravel()
    pat = np.zeros(len(uf))
    for i in range(len(uf)):
        if vf[i]:
            psi = k * (px * uf[i] + py * vf2[i] + pz * wf[i])
            pat[i] = np.abs(np.sum(np.conj(w) * np.exp(1j * psi)))
    psi_m = k * (px * u0 + py * v0 + pz * w0)
    mr = np.abs(np.sum(np.conj(w) * np.exp(1j * psi_m)))
    pi = np.argmax(pat)
    pu = uf[pi]; pv = vf2[pi]; pw = wf[pi]; pv_val = pat[pi]
    pt_c = np.degrees(np.arcsin(np.clip(np.sqrt(pu**2+pv**2), 0, 1)))
    pp_c = np.degrees(np.arctan2(pv, pu)) % 360
    for rt in np.arange(max(0, pt_c-2.0), min(90, pt_c+2.0)+0.25, 0.25):
        for rp_uw in np.arange(pp_c-2.0, pp_c+2.0+0.25, 0.25):
            rp = rp_uw % 360.0
            ru = np.sin(np.deg2rad(rt))*np.cos(np.deg2rad(rp))
            rv = np.sin(np.deg2rad(rt))*np.sin(np.deg2rad(rp))
            rw = np.cos(np.deg2rad(rt))
            if ru**2+rv**2 > 1.0: continue
            vr = np.abs(np.sum(np.conj(w)*np.exp(1j*k*(px*ru+py*rv+pz*rw))))
            if vr > pv_val: pv_val=vr; pu=ru; pv=rv; pw=rw
    pr = pv_val / (mr + 1e-30)
    pth = np.degrees(np.arcsin(np.clip(np.sqrt(pu**2+pv**2), 0, 1)))
    pph = np.degrees(np.arctan2(pv, pu)) % 360
    pte = angular_distance_deg(pth, pph, theta0, phi0)
    sf = sl_mask.ravel(); ps = pat[sf]
    sll = 20*np.log10(np.max(ps)/(mr+1e-30)) if mr > 1e-10 else -300
    suf = uf[sf]; svf = vf2[sf]; swf = wf[sf]
    si = np.argsort(ps)[::-1][:10]
    worst = [(suf[i], svf[i], swf[i]) for i in si]
    nulls = []
    for tn, pn in null_dirs:
        un = np.sin(np.deg2rad(tn))*np.cos(np.deg2rad(pn))
        vn = np.sin(np.deg2rad(tn))*np.sin(np.deg2rad(pn))
        wn = np.cos(np.deg2rad(tn))
        nd = 20*np.log10(np.abs(np.sum(np.conj(w)*np.exp(1j*k*(px*un+py*vn+pz*wn))))/(mr+1e-30))
        nulls.append(float(nd))
    return {'sll': float(sll), 'pt': float(pte), 'mr': float(mr),
            'pr': float(pr), 'pu': float(pu), 'pv': float(pv), 'pw': float(pw),
            'wn': float(max(nulls)), 'nulls': nulls, 'worst': worst}


def check_safety(ev, me, wn, tn, nl=NORM_RATIO):
    if me > 1e-3: return False, f'main_err={me:.2e}'
    if ev['pt'] > 1.0: return False, f'pt={ev["pt"]:.2f}'
    if ev['pr'] > 1.001: return False, f'peak={ev["pr"]:.4f}'
    if ev['wn'] > -EPS_NULL_CHECK_DB: return False, f'null={ev["wn"]:.1f}'
    nr = wn / (tn + 1e-30)
    if nr > nl: return False, f'norm={nr:.2f}'
    return True, ''

def check_teacher(ev, ts, me, wn, tn, nl=NORM_RATIO):
    ok, r = check_safety(ev, me, wn, tn, nl)
    if not ok: return False, r
    if ev['sll'] - ts > -0.5: return False, f'imp={ev["sll"]-ts:.1f}'
    return True, ''


def solve_dir(px, py, pz, ax, ay, th0, ph0, nd,
              trf=TRUST_RADIUS_FACTOR, nl=NORM_RATIO):
    u0 = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph0))
    v0 = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph0))
    w0 = np.cos(np.deg2rad(th0))
    wt = coordinate_taylor_3d(px, py, pz, ax, ay, th0, ph0)
    wtn = normalize_weights(wt, px, py, pz, u0, v0, w0)
    te = eval_full(wtn, px, py, pz, th0, ph0, nd)
    tn = np.linalg.norm(wtn)
    tme = abs(abs(np.conj(steering_vec_3d(px,py,pz,u0,v0,w0))@wtn)-1.0)
    nu = [np.sin(np.deg2rad(t))*np.cos(np.deg2rad(p)) for t,p in nd]
    nv = [np.sin(np.deg2rad(t))*np.sin(np.deg2rad(p)) for t,p in nd]
    nw = [np.cos(np.deg2rad(t)) for t,p in nd]
    uc = np.linspace(-1,1,N_COARSE); vc = np.linspace(-1,1,N_COARSE)
    ugc,vgc = np.meshgrid(uc,vc,indexing='ij')
    visc = (ugc**2+vgc**2)<=1.0; wgc = uv_to_uvw(ugc,vgc)
    bw = 0.886*2.0/NX*180/np.pi
    exc = np.sin(np.deg2rad(3.0*bw/max(np.cos(np.deg2rad(th0)),0.1)))
    dc = np.sqrt((ugc-u0)**2+(vgc-v0)**2)
    smc = (dc>=exc)&visc
    slu = list(ugc[smc]); slv = list(vgc[smc]); slw = list(wgc[smc])
    tr = trf*tn; nm = nl*tn
    bv = None; br = None; pc = []; so = 'not_attempted'; ni = 0
    for it in range(N_CUTTING_ITERS):
        wo, so = solve_socp(px,py,pz,u0,v0,w0,slu,slv,slw,nu,nv,nw,wtn,tr,nm,pc)
        if wo is None: break
        so = 'optimal'
        won = normalize_weights(wo, px, py, pz, u0, v0, w0)
        se = eval_full(won, px, py, pz, th0, ph0, nd)
        ni = it+1
        me = abs(abs(np.conj(steering_vec_3d(px,py,pz,u0,v0,w0))@won)-1.0)
        wn = np.linalg.norm(won)
        it_ok, reason = check_teacher(se, te['sll'], me, wn, tn, nl)
        if it_ok:
            if bv is None or se['sll'] < bv['sll']:
                bv = {'sll': se['sll'], 'w': won.copy(), 'ev': se, 'me': me, 'wn': wn}
        else:
            is_s, _ = check_safety(se, me, wn, tn, nl)
            if is_s:
                if br is None or se['sll'] < br['sll']:
                    br = {'sll': se['sll'], 'w': won.copy(), 'ev': se, 'me': me, 'wn': wn, 'reason': reason}
        if se['pr'] > 1.001 or se['pt'] > 1.0:
            npk = (se['pu'], se['pv'], se['pw'])
            tc = any(angular_distance_uvw(npk, p) < 2.0 for p in pc)
            if not tc and len(pc) < 5: pc.append(npk)
        for uw,vw,ww in se['worst'][:2]:
            al = any(abs(s-uw)<0.01 and abs(sv-vw)<0.01 for s,sv in zip(slu,slv))
            if not al: slu.append(uw); slv.append(vw); slw.append(ww)
    if so == 'optimal' and bv is None and br is not None:
        so = 'optimal_but_rejected'
    return {'bv': bv, 'br': br, 'te': te, 'wtn': wtn, 'tn': tn, 'tme': tme,
            'so': so, 'ni': ni, 'npc': len(pc)}


def main():
    print('='*70)
    print('8x8 Support Domain Scan v3.3')
    print(f'  Canonical: theta=35-60 step 1, phi=0-45 step 5 (refine 1 near boundary)')
    print(f'  Null: design=-30dB, check=-28dB, trust={TRUST_RADIUS_FACTOR}, norm={NORM_RATIO}')
    print(f'  BASE_DIR: {BASE_DIR}')
    print('='*70)

    coords, normals = load_real_coordinates()
    px, py, pz = coords[:,0], coords[:,1], coords[:,2]
    ax, ay = taylor_2d_separable(NX, NY, SLL_DESIGN)
    print(f'Loaded {len(px)} elements')

    # 扫描网格
    thetas = list(range(35, 61))  # 35-60, step 1
    phis_coarse = list(range(0, 46, 5))  # 0-45, step 5
    # 在边界附近细化φ
    phis_fine = []
    for th in thetas:
        pf = list(phis_coarse)
        # 在axial(0°)和diagonal(45°)附近细化
        for base in [0, 45]:
            for off in [-2, -1, 1, 2]:
                v = base + off
                if 0 <= v <= 45 and v not in pf:
                    pf.append(v)
        phis_fine.append(sorted(pf))

    all_points = []
    weights_data = {}  # (th, ph) -> (w_re, w_im)
    t_start = time.time()

    for th in thetas:
        phis = phis_fine[th - 35]
        for ph in phis:
            nd = get_null_dirs(float(th), float(ph))
            sol = solve_dir(px, py, pz, ax, ay, float(th), float(ph), nd)

            # 状态分离
            direct_outcome = sol['so']
            rotation_source = 'none'
            w_final = sol['wtn']  # default: Taylor
            ev_final = sol['te']
            me_final = sol['tme']
            wn_final = sol['tn']

            if sol['bv'] is not None:
                final_label = 'valid'
                w_final = sol['bv']['w']
                ev_final = sol['bv']['ev']
                me_final = sol['bv']['me']
                wn_final = sol['bv']['wn']
                rotation_source = 'direct'
            else:
                t_safe, _ = check_safety(sol['te'], sol['tme'], sol['tn'], sol['tn'])
                if t_safe:
                    if sol['te']['sll'] > -15:
                        final_label = 'degraded'  # Taylor安全但SLL很差
                    else:
                        final_label = 'fallback_taylor'
                else:
                    if sol['br'] is not None:
                        final_label = 'unsupported_with_rejected'
                        w_final = sol['br']['w']
                        ev_final = sol['br']['ev']
                        me_final = sol['br']['me']
                        wn_final = sol['br']['wn']
                    else:
                        final_label = 'unsupported'

            imp = ev_final['sll'] - sol['te']['sll']
            nr = wn_final / (sol['tn'] + 1e-30)

            r = {
                'theta': float(th), 'phi': float(ph),
                'taylor_sll': float(sol['te']['sll']),
                'final_sll': float(ev_final['sll']),
                'improvement': float(imp),
                'pt': float(ev_final['pt']),
                'peak_ratio': float(ev_final['pr']),
                'worst_null': float(ev_final['wn']),
                'null_depths': ev_final['nulls'],
                'w_norm': float(wn_final), 't_norm': float(sol['tn']),
                'norm_ratio': float(nr),
                'max_amp': float(np.max(np.abs(w_final))),
                'main_err': float(me_final),
                'direct_solver_outcome': direct_outcome,
                'final_label': final_label,
                'rotation_source': rotation_source,
                'n_iters': sol['ni'], 'n_peaks': sol['npc'],
                'reject_reason': sol['br']['reason'] if sol['br'] else '',
            }
            all_points.append(r)

            if final_label == 'valid':
                weights_data[(th, ph)] = (w_final.real.copy(), w_final.imag.copy())

            print(f'  th={th:2d} ph={ph:2d}: T={sol["te"]["sll"]:6.1f} F={ev_final["sll"]:6.1f} '
                  f'd={imp:+5.1f} pt={ev_final["pt"]:.2f} pk={ev_final["pr"]:.4f} '
                  f'null={ev_final["wn"]:5.1f} nr={nr:.2f} '
                  f'solver={direct_outcome:>25} [{final_label}]')

    total_time = time.time() - t_start

    # 汇总
    labels = {}
    for p in all_points:
        lb = p['final_label']
        labels[lb] = labels.get(lb, 0) + 1

    print(f'\n{"="*70}')
    print(f'SUMMARY: {len(all_points)} points, {total_time:.1f}s')
    for lb, n in sorted(labels.items()):
        print(f'  {lb}: {n}')

    # 支持域边界
    print(f'\nSupport domain boundary (axial phi=0):')
    for th in thetas:
        axial = [p for p in all_points if p['theta'] == th and p['phi'] == 0]
        if axial:
            lb = axial[0]['final_label']
            print(f'  theta={th:2d}: {lb} (T={axial[0]["taylor_sll"]:.1f})')

    print(f'\nSupport domain boundary (diagonal phi=45):')
    for th in thetas:
        diag = [p for p in all_points if p['theta'] == th and p['phi'] == 45]
        if diag:
            lb = diag[0]['final_label']
            print(f'  theta={th:2d}: {lb} (T={diag[0]["taylor_sll"]:.1f})')

    # 保存JSON
    out_json = os.path.join(OUTPUT_DIR, 'support_domain_v3_3.json')
    with open(out_json, 'w') as f:
        json.dump({
            'points': all_points,
            'label_counts': labels,
            'total_time_s': total_time,
            'config': {
                'freq_ghz': FREQ_GHZ, 'lambda_mm': LAMBDA_MM,
                'nx': NX, 'ny': NY, 'sll_design': SLL_DESIGN,
                'eps_null': EPS_NULL, 'null_check_db': EPS_NULL_CHECK_DB,
                'trust': TRUST_RADIUS_FACTOR, 'norm': NORM_RATIO,
                'n_iters': N_CUTTING_ITERS, 'n_eval': N_EVAL, 'refine_step': 0.25,
                'theta_range': [35, 60], 'phi_range': [0, 45],
            },
        }, f, indent=2, default=str)
    print(f'\nJSON: {out_json}')

    # 保存权值NPZ
    if weights_data:
        n_w = len(weights_data)
        w_re = np.zeros((n_w, N_ELEM)); w_im = np.zeros((n_w, N_ELEM))
        meta_th = []; meta_ph = []
        for i, ((th, ph), (wr, wi)) in enumerate(sorted(weights_data.items())):
            w_re[i] = wr; w_im[i] = wi
            meta_th.append(th); meta_ph.append(ph)
        out_npz = os.path.join(OUTPUT_DIR, 'support_domain_weights_v3_3.npz')
        np.savez(out_npz, w_re=w_re, w_im=w_im,
                 theta=np.array(meta_th), phi=np.array(meta_ph),
                 px=px, py=py, pz=pz)
        print(f'Weights: {out_npz} ({n_w} valid points)')
    else:
        print('No valid weights to save.')

    # 写requirements.txt
    req_path = os.path.join(BASE_DIR, 'requirements.txt')
    with open(req_path, 'w') as f:
        f.write(f'numpy>=1.24\nscipy>=1.10\ncvxpy>=1.5\n# SCS solver (bundled with cvxpy)\n# Python {sys.version.split()[0]}\n')
    # 写版本信息
    ver_path = os.path.join(OUTPUT_DIR, 'versions.txt')
    with open(ver_path, 'w') as f:
        f.write(f'Python: {sys.version}\n')
        f.write(f'NumPy: {np.__version__}\n')
        try:
            import scipy; f.write(f'SciPy: {scipy.__version__}\n')
        except: pass
        try:
            f.write(f'CVXPY: {cvxpy.__version__}\n')
        except: pass
    print(f'Requirements: {req_path}')
    print(f'Versions: {ver_path}')
    print('='*70)


if __name__ == '__main__':
    main()
