"""8×8 SOCP教师质检 v3.2

修改：
  1. 封装独立复现包
  2. norm_limit参数化，区分solver_failed/optimal_but_rejected/valid
  3. 零陷设计目标-30~-32dB，验收-28dB
  4. θ=40°~65°轴向加密扫描，确定unsupported边界
  5. valid=教师残差, fallback单独标记, unsupported排除
  6. 旋转扩增前先划分训练/验证/测试
"""

import os, sys, time, json, csv, shutil
import numpy as np
import cvxpy as cp

sys.path.insert(0, '/mnt/workspace/gitCode/cann/tiaozhansai/project')
from mylib.antenna_calc import taylor_2d_separable, angular_distance_deg
from run_8x8_teacher import (
    load_real_coordinates, steering_vec_3d, coordinate_taylor_3d,
    normalize_weights, uv_to_uvw, get_null_dirs,
)

OUTPUT_DIR = '/mnt/workspace/gitCode/cann/tiaozhansai/revision/results'
BUNDLE_DIR = '/mnt/workspace/gitCode/cann/tiaozhansai/revision/8x8_v3_2_bundle'
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(BUNDLE_DIR, exist_ok=True)

LAMBDA_MM = 23.9834
NX = NY = 8
N_ELEM = 64
SLL_DESIGN = 30
FREQ_GHZ = 12.5

# 零陷：设计目标-30dB(EPS=0.0316), 验收门槛-28dB(EPS_CHECK=0.0398)
EPS_NULL = 0.0316   # -30dB SOCP约束
EPS_NULL_CHECK_DB = 28.0  # 验收门槛

N_COARSE = 11
N_CUTTING_ITERS = 10
N_EVAL = 81
TRUST_RADIUS_FACTOR = 0.3
NORM_RATIO = 1.5

SCAN_DIRS = [(0.0, 0.0)]
for th in [15.0, 30.0, 45.0, 60.0]:
    for ph in [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0]:
        SCAN_DIRS.append((th, ph))

# 边界扫描: θ=40~65度, 轴向φ=0/90/180/270
BOUNDARY_THETAS = [40.0, 42.0, 44.0, 46.0, 48.0, 50.0, 52.0, 55.0, 58.0, 62.0, 65.0]
BOUNDARY_PHIS = [0.0, 90.0, 180.0, 270.0]


def angular_distance_uvw(q1, q2):
    q1 = np.asarray(q1, dtype=float); q2 = np.asarray(q2, dtype=float)
    n1 = np.linalg.norm(q1); n2 = np.linalg.norm(q2)
    if n1 < 1e-10 or n2 < 1e-10: return 180.0
    return float(np.degrees(np.arccos(np.clip(np.dot(q1, q2) / (n1 * n2), -1.0, 1.0))))


def solve_socp_with_trust(px, py, pz, u0, v0, w0,
                           sl_u, sl_v, sl_w,
                           null_u, null_v, null_w,
                           w_taylor_norm, trust_r, norm_max,
                           peak_constraints=None):
    n = len(px)
    w = cp.Variable(n, complex=True)
    t = cp.Variable()
    a_main = steering_vec_3d(px, py, pz, u0, v0, w0)
    constraints = [a_main.conj() @ w == 1.0 + 0j]
    for u_s, v_s, w_s in zip(sl_u, sl_v, sl_w):
        a_sl = steering_vec_3d(px, py, pz, u_s, v_s, w_s)
        constraints.append(cp.norm(a_sl.conj() @ w, 2) <= t)
    for u_n, v_n, w_n in zip(null_u, null_v, null_w):
        a_n = steering_vec_3d(px, py, pz, u_n, v_n, w_n)
        constraints.append(cp.norm(a_n.conj() @ w, 2) <= EPS_NULL)
    w_diff = w - (w_taylor_norm.real + 1j * w_taylor_norm.imag)
    constraints.append(cp.norm(w_diff, 2) <= trust_r)
    constraints.append(cp.norm(w, 2) <= norm_max)
    if peak_constraints:
        for u_p, v_p, w_p in peak_constraints:
            a_p = steering_vec_3d(px, py, pz, u_p, v_p, w_p)
            constraints.append(cp.norm(a_p.conj() @ w, 2) <= 1.0)
    prob = cp.Problem(cp.Minimize(t), constraints)
    try:
        prob.solve(solver=cp.SCS, verbose=False, max_iters=20000)
        if prob.status not in ['optimal', 'optimal_inaccurate']:
            return None, 'solver_failed', prob.status
    except Exception as e:
        return None, 'solver_failed', str(e)
    return w.value, 'optimal', prob.status


def eval_full_3d(w, px, py, pz, theta0, phi0, null_dirs, n_eval=N_EVAL):
    k = 2 * np.pi
    u0 = np.sin(np.deg2rad(theta0)) * np.cos(np.deg2rad(phi0))
    v0 = np.sin(np.deg2rad(theta0)) * np.sin(np.deg2rad(phi0))
    w0 = np.cos(np.deg2rad(theta0))
    u = np.linspace(-1, 1, n_eval); v = np.linspace(-1, 1, n_eval)
    ug, vg = np.meshgrid(u, v, indexing='ij')
    vis = (ug**2 + vg**2) <= 1.0; wg = uv_to_uvw(ug, vg)
    bw = 0.886 * 2.0 / NX * 180 / np.pi
    exc_uv = np.sin(np.deg2rad(3.0 * bw / max(np.cos(np.deg2rad(theta0)), 0.1)))
    dist = np.sqrt((ug - u0)**2 + (vg - v0)**2)
    sl_mask = (dist >= exc_uv) & vis
    vis_flat = vis.ravel(); ug_flat = ug.ravel(); vg_flat = vg.ravel(); wg_flat = wg.ravel()
    pat_all = np.zeros(len(ug_flat))
    for i in range(len(ug_flat)):
        if vis_flat[i]:
            psi = k * (px * ug_flat[i] + py * vg_flat[i] + pz * wg_flat[i])
            pat_all[i] = np.abs(np.sum(np.conj(w) * np.exp(1j * psi)))
    psi_main = k * (px * u0 + py * v0 + pz * w0)
    main_resp = np.abs(np.sum(np.conj(w) * np.exp(1j * psi_main)))
    peak_idx = np.argmax(pat_all)
    peak_u = ug_flat[peak_idx]; peak_v = vg_flat[peak_idx]; peak_w = wg_flat[peak_idx]
    peak_val = pat_all[peak_idx]
    peak_theta_c = np.degrees(np.arcsin(np.clip(np.sqrt(peak_u**2 + peak_v**2), 0, 1)))
    peak_phi_c = np.degrees(np.arctan2(peak_v, peak_u)) % 360
    for rt in np.arange(max(0, peak_theta_c - 2.0), min(90, peak_theta_c + 2.0) + 0.25, 0.25):
        for rp_uw in np.arange(peak_phi_c - 2.0, peak_phi_c + 2.0 + 0.25, 0.25):
            rp = rp_uw % 360.0
            ru = np.sin(np.deg2rad(rt)) * np.cos(np.deg2rad(rp))
            rv = np.sin(np.deg2rad(rt)) * np.sin(np.deg2rad(rp))
            rw = np.cos(np.deg2rad(rt))
            if ru**2 + rv**2 > 1.0: continue
            psi_r = k * (px * ru + py * rv + pz * rw)
            val_r = np.abs(np.sum(np.conj(w) * np.exp(1j * psi_r)))
            if val_r > peak_val:
                peak_val = val_r; peak_u = ru; peak_v = rv; peak_w = rw
    peak_ratio = peak_val / (main_resp + 1e-30)
    peak_theta = np.degrees(np.arcsin(np.clip(np.sqrt(peak_u**2 + peak_v**2), 0, 1)))
    peak_phi = np.degrees(np.arctan2(peak_v, peak_u)) % 360
    pt_err = angular_distance_deg(peak_theta, peak_phi, theta0, phi0)
    sl_flat = sl_mask.ravel(); pat_sl = pat_all[sl_flat]
    sll = 20 * np.log10(np.max(pat_sl) / (main_resp + 1e-30)) if main_resp > 1e-10 else -300
    sl_u_f = ug_flat[sl_flat]; sl_v_f = vg_flat[sl_flat]; sl_w_f = wg_flat[sl_flat]
    sorted_idx = np.argsort(pat_sl)[::-1][:10]
    worst = [(sl_u_f[i], sl_v_f[i], sl_w_f[i]) for i in sorted_idx]
    null_results = []
    for tn, pn in null_dirs:
        un = np.sin(np.deg2rad(tn)) * np.cos(np.deg2rad(pn))
        vn = np.sin(np.deg2rad(tn)) * np.sin(np.deg2rad(pn))
        wn = np.cos(np.deg2rad(tn))
        psi_n = k * (px * un + py * vn + pz * wn)
        nd = 20 * np.log10(np.abs(np.sum(np.conj(w) * np.exp(1j * psi_n))) / (main_resp + 1e-30))
        null_results.append(float(nd))
    return {
        'sll': float(sll), 'pointing_err': float(pt_err),
        'main_resp': float(main_resp), 'peak_ratio': float(peak_ratio),
        'peak_u': float(peak_u), 'peak_v': float(peak_v), 'peak_w': float(peak_w),
        'worst_null': float(max(null_results)), 'null_depths': null_results,
        'worst_sidelobes': worst,
    }


def check_safety(ev, main_err, w_norm, t_norm, norm_limit=NORM_RATIO):
    if main_err > 1e-3: return False, f'main_err={main_err:.2e}'
    if ev['pointing_err'] > 1.0: return False, f'pt={ev["pointing_err"]:.2f}'
    if ev['peak_ratio'] > 1.001: return False, f'peak={ev["peak_ratio"]:.4f}'
    if ev['worst_null'] > -EPS_NULL_CHECK_DB: return False, f'null={ev["worst_null"]:.1f}dB(>{-EPS_NULL_CHECK_DB})'
    nr = w_norm / (t_norm + 1e-30)
    if nr > norm_limit: return False, f'norm={nr:.2f}(>{norm_limit})'
    return True, ''

def check_teacher(ev, t_sll, main_err, w_norm, t_norm, norm_limit=NORM_RATIO):
    ok, r = check_safety(ev, main_err, w_norm, t_norm, norm_limit)
    if not ok: return False, r
    imp = ev['sll'] - t_sll
    if imp > -0.5: return False, f'imp={imp:.1f}'
    return True, ''


def rotate_weight_90(w_2d, rot_times):
    return np.rot90(w_2d, k=-rot_times)

def verify_rotation(px_2d, py_2d, rot_times):
    if rot_times % 4 == 0: return True
    px_rot = np.rot90(px_2d, k=-rot_times)
    py_rot = np.rot90(py_2d, k=-rot_times)
    if rot_times % 4 == 1:
        return bool(np.allclose(px_rot, py_2d, atol=1e-10) and np.allclose(py_rot, -px_2d, atol=1e-10))
    elif rot_times % 4 == 2:
        return bool(np.allclose(px_rot, -px_2d, atol=1e-10) and np.allclose(py_rot, -py_2d, atol=1e-10))
    elif rot_times % 4 == 3:
        return bool(np.allclose(px_rot, -py_2d, atol=1e-10) and np.allclose(py_rot, px_2d, atol=1e-10))
    return True


def solve_direction(px, py, pz, amp_x, amp_y, theta0, phi0, null_dirs,
                    trust_r_factor=TRUST_RADIUS_FACTOR, norm_limit=NORM_RATIO):
    u0 = np.sin(np.deg2rad(theta0)) * np.cos(np.deg2rad(phi0))
    v0 = np.sin(np.deg2rad(theta0)) * np.sin(np.deg2rad(phi0))
    w0 = np.cos(np.deg2rad(theta0))
    w_taylor = coordinate_taylor_3d(px, py, pz, amp_x, amp_y, theta0, phi0)
    w_taylor_n = normalize_weights(w_taylor, px, py, pz, u0, v0, w0)
    t_eval = eval_full_3d(w_taylor_n, px, py, pz, theta0, phi0, null_dirs)
    t_norm = np.linalg.norm(w_taylor_n)
    t_main_err = abs(abs(np.conj(steering_vec_3d(px, py, pz, u0, v0, w0)) @ w_taylor_n) - 1.0)
    null_u = [np.sin(np.deg2rad(tn)) * np.cos(np.deg2rad(pn)) for tn, pn in null_dirs]
    null_v = [np.sin(np.deg2rad(tn)) * np.sin(np.deg2rad(pn)) for tn, pn in null_dirs]
    null_w = [np.cos(np.deg2rad(tn)) for tn, pn in null_dirs]
    u_c = np.linspace(-1, 1, N_COARSE); v_c = np.linspace(-1, 1, N_COARSE)
    ug_c, vg_c = np.meshgrid(u_c, v_c, indexing='ij')
    vis_c = (ug_c**2 + vg_c**2) <= 1.0; wg_c = uv_to_uvw(ug_c, vg_c)
    bw = 0.886 * 2.0 / NX * 180 / np.pi
    exc_uv = np.sin(np.deg2rad(3.0 * bw / max(np.cos(np.deg2rad(theta0)), 0.1)))
    dist_c = np.sqrt((ug_c - u0)**2 + (vg_c - v0)**2)
    sl_mask_c = (dist_c >= exc_uv) & vis_c
    sl_u = list(ug_c[sl_mask_c]); sl_v = list(vg_c[sl_mask_c]); sl_w = list(wg_c[sl_mask_c])
    trust_r = trust_r_factor * t_norm; norm_max = norm_limit * t_norm
    best_valid = None; best_rejected = None; peak_constraints = []
    solver_outcome = 'not_attempted'; n_iters = 0

    for it in range(N_CUTTING_ITERS):
        w_opt, outcome, raw_status = solve_socp_with_trust(
            px, py, pz, u0, v0, w0, sl_u, sl_v, sl_w,
            null_u, null_v, null_w, w_taylor_n, trust_r, norm_max, peak_constraints)
        if w_opt is None:
            solver_outcome = outcome  # solver_failed
            break
        solver_outcome = 'optimal'
        w_opt_n = normalize_weights(w_opt, px, py, pz, u0, v0, w0)
        s_eval = eval_full_3d(w_opt_n, px, py, pz, theta0, phi0, null_dirs)
        n_iters = it + 1
        main_err = abs(abs(np.conj(steering_vec_3d(px, py, pz, u0, v0, w0)) @ w_opt_n) - 1.0)
        w_norm = np.linalg.norm(w_opt_n)
        is_t, reason = check_teacher(s_eval, t_eval['sll'], main_err, w_norm, t_norm, norm_limit)
        if is_t:
            if best_valid is None or s_eval['sll'] < best_valid['sll']:
                best_valid = {'sll': s_eval['sll'], 'w': w_opt_n.copy(), 'eval': s_eval,
                              'main_err': main_err, 'w_norm': w_norm}
        else:
            is_s, _ = check_safety(s_eval, main_err, w_norm, t_norm, norm_limit)
            if is_s:
                if best_rejected is None or s_eval['sll'] < best_rejected['sll']:
                    best_rejected = {'sll': s_eval['sll'], 'w': w_opt_n.copy(), 'eval': s_eval,
                                     'main_err': main_err, 'w_norm': w_norm, 'reason': reason}
        if s_eval['peak_ratio'] > 1.001 or s_eval['pointing_err'] > 1.0:
            new_peak = (s_eval['peak_u'], s_eval['peak_v'], s_eval['peak_w'])
            too_close = any(angular_distance_uvw(new_peak, pc) < 2.0 for pc in peak_constraints)
            if not too_close and len(peak_constraints) < 5:
                peak_constraints.append(new_peak)
        for u_w, v_w, w_w in s_eval['worst_sidelobes'][:2]:
            already = any(abs(su-u_w)<0.01 and abs(sv-v_w)<0.01 for su, sv in zip(sl_u, sl_v))
            if not already:
                sl_u.append(u_w); sl_v.append(v_w); sl_w.append(w_w)

    if solver_outcome == 'optimal' and best_valid is None and best_rejected is not None:
        solver_outcome = 'optimal_but_rejected'

    return {
        'best_valid': best_valid, 'best_rejected': best_rejected,
        'taylor_eval': t_eval, 'w_taylor': w_taylor_n, 't_norm': t_norm,
        't_main_err': t_main_err, 'solver_outcome': solver_outcome,
        'n_iters': n_iters, 'n_peaks': len(peak_constraints),
    }


def main():
    print('=' * 70)
    print('8x8 SOCP Teacher QC v3.2')
    print(f'  Null: design=-30dB(EPS={EPS_NULL}), check=-{EPS_NULL_CHECK_DB}dB')
    print(f'  Trust={TRUST_RADIUS_FACTOR}, Norm={NORM_RATIO}')
    print(f'  {len(SCAN_DIRS)} standard + {len(BOUNDARY_THETAS)*len(BOUNDARY_PHIS)} boundary dirs')
    print('=' * 70)

    coords, normals = load_real_coordinates()
    px, py, pz = coords[:, 0], coords[:, 1], coords[:, 2]
    amp_x, amp_y = taylor_2d_separable(NX, NY, SLL_DESIGN)
    px_2d = px.reshape(NY, NX); py_2d = py.reshape(NY, NX)

    results = {}; weights = {}; statuses = {}; solver_outcomes = {}
    t_start = time.time()

    # ============================================================
    # Phase 1: 33标准方向
    # ============================================================
    print('\n--- PHASE 1: 33 Standard Directions ---')
    for i, (theta0, phi0) in enumerate(SCAN_DIRS):
        null_dirs = get_null_dirs(theta0, phi0)
        sol = solve_direction(px, py, pz, amp_x, amp_y, theta0, phi0, null_dirs)

        if sol['best_valid'] is not None:
            bv = sol['best_valid']
            final_w = bv['w']; final_eval = bv['eval']
            final_main_err = bv['main_err']; final_w_norm = bv['w_norm']
            status = 'valid'
        else:
            t_safe, _ = check_safety(sol['taylor_eval'], sol['t_main_err'], sol['t_norm'], sol['t_norm'])
            if t_safe:
                final_w = sol['w_taylor']; final_eval = sol['taylor_eval']
                final_main_err = sol['t_main_err']; final_w_norm = sol['t_norm']
                status = 'fallback_taylor'
            else:
                final_w = sol['w_taylor']; final_eval = sol['taylor_eval']
                final_main_err = sol['t_main_err']; final_w_norm = sol['t_norm']
                status = 'unsupported_direction'

        improvement = final_eval['sll'] - sol['taylor_eval']['sll']
        norm_ratio = final_w_norm / (sol['t_norm'] + 1e-30)
        r = {
            'idx': i, 'theta0': float(theta0), 'phi0': float(phi0),
            'taylor_sll': float(sol['taylor_eval']['sll']),
            'final_sll': float(final_eval['sll']), 'improvement': float(improvement),
            'final_pt': float(final_eval['pointing_err']),
            'peak_ratio': float(final_eval['peak_ratio']),
            'worst_null': float(final_eval['worst_null']),
            'null_depths': final_eval['null_depths'],
            'w_norm': float(final_w_norm), 't_norm': float(sol['t_norm']),
            'norm_ratio': float(norm_ratio), 'max_amp': float(np.max(np.abs(final_w))),
            'main_err': float(final_main_err),
            'solver_outcome': sol['solver_outcome'],
            'n_iters': sol['n_iters'], 'n_peaks': sol['n_peaks'],
            'status': status, 'rotation_applied': False,
        }
        results[i] = r; weights[i] = (final_w.real.copy(), final_w.imag.copy())
        statuses[i] = status; solver_outcomes[i] = sol['solver_outcome']
        print(f'  [{i+1:2d}/{len(SCAN_DIRS)}] th={theta0:.0f} ph={phi0:>3.0f} '
              f'T={sol["taylor_eval"]["sll"]:.1f} F={final_eval["sll"]:.1f} '
              f'd={improvement:+.1f} pt={final_eval["pointing_err"]:.2f} '
              f'peak={final_eval["peak_ratio"]:.4f} null={final_eval["worst_null"]:.1f} '
              f'norm={norm_ratio:.2f} solver={sol["solver_outcome"]} [{status}]')

    # ============================================================
    # Phase 2: 旋转对称性
    # ============================================================
    print(f'\n--- PHASE 2: Rotation Symmetry ---')
    symmetry_results = []; symmetry_failures = []
    for th in [15.0, 30.0, 45.0, 60.0]:
        for group_phis, gname in [([0, 90, 180, 270], 'axial'), ([45, 135, 225, 315], 'diagonal')]:
            gidx = [next(i for i, (t, p) in enumerate(SCAN_DIRS) if t == th and p == ph) for ph in group_phis]
            n_valid = sum(1 for i in gidx if statuses[i] == 'valid')
            if n_valid == 0:
                symmetry_results.append({'theta': th, 'group': gname, 'consistent': True, 'action': 'no_valid'})
                continue
            best_i = None; best_sll = 0
            for i in gidx:
                if statuses[i] == 'valid' and (best_i is None or results[i]['final_sll'] < best_sll):
                    best_sll = results[i]['final_sll']; best_i = i
            if best_i is None:
                for i in gidx:
                    if statuses[i] == 'valid': best_i = i; best_sll = results[i]['final_sll']; break
            w_2d_b = (weights[best_i][0].reshape(NY, NX) + 1j * weights[best_i][1].reshape(NY, NX))
            base_phi = results[best_i]['phi0']
            for ti in gidx:
                tp = results[ti]['phi0']
                if ti == best_i: continue
                rot_times = int(round((tp - base_phi) / 90.0)) % 4
                if not verify_rotation(px_2d, py_2d, rot_times): continue
                w_rot = rotate_weight_90(w_2d_b, rot_times).ravel()
                th0 = results[ti]['theta0']; ph0 = results[ti]['phi0']
                u0 = np.sin(np.deg2rad(th0)) * np.cos(np.deg2rad(ph0))
                v0 = np.sin(np.deg2rad(th0)) * np.sin(np.deg2rad(ph0))
                w0 = np.cos(np.deg2rad(th0))
                w_rot_n = normalize_weights(w_rot, px, py, pz, u0, v0, w0)
                nd = get_null_dirs(th0, ph0)
                r_ev = eval_full_3d(w_rot_n, px, py, pz, th0, ph0, nd)
                r_me = abs(abs(np.conj(steering_vec_3d(px, py, pz, u0, v0, w0)) @ w_rot_n) - 1.0)
                r_wn = np.linalg.norm(w_rot_n); tn = results[ti]['t_norm']
                r_t, _ = check_teacher(r_ev, results[ti]['taylor_sll'], r_me, r_wn, tn)
                if r_t:
                    results[ti].update({
                        'final_sll': float(r_ev['sll']),
                        'improvement': float(r_ev['sll'] - results[ti]['taylor_sll']),
                        'final_pt': float(r_ev['pointing_err']),
                        'peak_ratio': float(r_ev['peak_ratio']),
                        'worst_null': float(r_ev['worst_null']),
                        'w_norm': float(r_wn), 'norm_ratio': float(r_wn / (tn + 1e-30)),
                        'main_err': float(r_me), 'status': 'valid', 'rotation_applied': True,
                    })
                    weights[ti] = (w_rot_n.real.copy(), w_rot_n.imag.copy())
                    statuses[ti] = 'valid'
            gf = [results[i] for i in gidx if statuses[i] == 'valid']
            if len(gf) >= 2:
                slls = [r['final_sll'] for r in gf]; pts = [r['final_pt'] for r in gf]
                pks = [r['peak_ratio'] for r in gf]; nrs = [r['norm_ratio'] for r in gf]
                sr = max(slls)-min(slls); pr = max(pts)-min(pts)
                pkr = max(pks)-min(pks); nrr = max(nrs)-min(nrs)
                ok = sr<=0.5 and pr<=0.2 and pkr<=2e-4 and nrr<=0.02
                sym = {'theta': th, 'group': gname, 'n_valid': len(gf),
                       'sll_range': float(sr), 'pt_range': float(pr),
                       'peak_range': float(pkr), 'norm_range': float(nrr), 'consistent': ok}
                symmetry_results.append(sym)
                if not ok: symmetry_failures.append(sym)

    # ============================================================
    # Phase 3: 边界扫描
    # ============================================================
    print(f'\n--- PHASE 3: Boundary Scan (theta=40-65, axial) ---')
    boundary_results = []
    for th in BOUNDARY_THETAS:
        for ph in BOUNDARY_PHIS:
            null_dirs = get_null_dirs(th, ph)
            sol = solve_direction(px, py, pz, amp_x, amp_y, th, ph, null_dirs)
            if sol['best_valid']:
                st = 'valid'; sll = sol['best_valid']['sll']
            elif sol['best_rejected']:
                t_safe, _ = check_safety(sol['taylor_eval'], sol['t_main_err'], sol['t_norm'], sol['t_norm'])
                st = 'fallback_taylor' if t_safe else 'unsupported'
                sll = sol['taylor_eval']['sll']
            else:
                t_safe, _ = check_safety(sol['taylor_eval'], sol['t_main_err'], sol['t_norm'], sol['t_norm'])
                st = 'fallback_taylor' if t_safe else 'unsupported'
                sll = sol['taylor_eval']['sll']
            boundary_results.append({
                'theta': float(th), 'phi': float(ph),
                'taylor_sll': float(sol['taylor_eval']['sll']),
                'best_sll': float(sll), 'status': st,
                'solver_outcome': sol['solver_outcome'],
                'taylor_pt': float(sol['taylor_eval']['pointing_err']),
                'taylor_null': float(sol['taylor_eval']['worst_null']),
            })
            print(f'  th={th:.0f} ph={ph:>3.0f}: T={sol["taylor_eval"]["sll"]:.1f} '
                  f'best={sll:.1f} solver={sol["solver_outcome"]} [{st}]')

    total_time = time.time() - t_start

    # ============================================================
    # 汇总
    # ============================================================
    nv = sum(1 for s in statuses.values() if s == 'valid')
    nf = sum(1 for s in statuses.values() if s == 'fallback_taylor')
    nu = sum(1 for s in statuses.values() if s == 'unsupported_direction')
    nrot = sum(1 for r in results.values() if r.get('rotation_applied', False))
    n_solver_failed = sum(1 for s in solver_outcomes.values() if s == 'solver_failed')
    n_rejected = sum(1 for s in solver_outcomes.values() if s == 'optimal_but_rejected')

    # 边界分析
    boundary_valid = [b for b in boundary_results if b['status'] == 'valid']
    boundary_fallback = [b for b in boundary_results if b['status'] == 'fallback_taylor']
    boundary_unsupported = [b for b in boundary_results if b['status'] == 'unsupported']

    print(f'\n{"="*70}')
    print(f'SUMMARY: {len(SCAN_DIRS)} standard + {len(boundary_results)} boundary, {total_time:.1f}s')
    print(f'  Standard: valid={nv} (rot={nrot}), fallback={nf}, unsupported={nu}')
    print(f'  Solver: failed={n_solver_failed}, optimal_but_rejected={n_rejected}')
    print(f'  Symmetry failures: {len(symmetry_failures)}')
    print(f'  Boundary: valid={len(boundary_valid)}, fallback={len(boundary_fallback)}, unsupported={len(boundary_unsupported)}')

    # 边界确定
    axial_by_theta = {}
    for b in boundary_results:
        th = b['theta']
        if th not in axial_by_theta:
            axial_by_theta[th] = []
        axial_by_theta[th].append(b['status'])
    print(f'\n  Boundary status by theta:')
    for th in sorted(axial_by_theta.keys()):
        statuses_th = axial_by_theta[th]
        n_v = sum(1 for s in statuses_th if s == 'valid')
        n_f = sum(1 for s in statuses_th if s == 'fallback_taylor')
        n_u = sum(1 for s in statuses_th if s == 'unsupported')
        print(f'    theta={th:.0f}: valid={n_v} fallback={n_f} unsupported={n_u}')

    print(f'{"="*70}')

    # 表格
    print(f'\n{"th":>4} {"ph":>5} {"T":>6} {"F":>6} {"d":>6} {"pt":>5} {"peak":>7} {"null":>6} {"norm":>5} {"solver":>25} {"status":>20}')
    print('-' * 100)
    for i in range(len(SCAN_DIRS)):
        r = results[i]
        print(f'{r["theta0"]:>4.0f} {r["phi0"]:>5.0f} {r["taylor_sll"]:>6.1f} {r["final_sll"]:>6.1f} '
              f'{r["improvement"]:>+6.1f} {r["final_pt"]:>5.2f} {r["peak_ratio"]:>7.4f} '
              f'{r["worst_null"]:>6.1f} {r["norm_ratio"]:>5.2f} {r["solver_outcome"]:>25} {r["status"]:>20}')

    # 保存JSON
    out_json = os.path.join(OUTPUT_DIR, 'teacher_8x8_qc_v3_2.json')
    with open(out_json, 'w') as f:
        json.dump({
            'results': list(results.values()),
            'n_valid': nv, 'n_fallback': nf, 'n_unsupported': nu,
            'n_rotated': nrot, 'n_solver_failed': n_solver_failed,
            'n_optimal_but_rejected': n_rejected,
            'symmetry_results': symmetry_results, 'symmetry_failures': symmetry_failures,
            'boundary_results': boundary_results,
            'total_time_s': total_time,
            'config': {'trust_radius': TRUST_RADIUS_FACTOR, 'norm_ratio': NORM_RATIO,
                       'eps_null': EPS_NULL, 'null_check_db': EPS_NULL_CHECK_DB,
                       'n_iters': N_CUTTING_ITERS, 'n_eval': N_EVAL, 'refine_step': 0.25},
        }, f, indent=2, default=str)
    print(f'\nJSON: {out_json}')

    # 保存权值NPZ
    n = len(SCAN_DIRS)
    w_re = np.zeros((n, N_ELEM)); w_im = np.zeros((n, N_ELEM))
    for idx in range(n):
        w_re[idx] = weights[idx][0]; w_im[idx] = weights[idx][1]
    vm = np.array([i for i in range(n) if statuses[i] == 'valid'])
    fm = np.array([i for i in range(n) if statuses[i] == 'fallback_taylor'])
    um = np.array([i for i in range(n) if statuses[i] == 'unsupported_direction'])
    rm = np.array([i for i in range(n) if results[i].get('rotation_applied', False)])
    out_npz = os.path.join(OUTPUT_DIR, 'teacher_8x8_qc_weights_v3_2.npz')
    np.savez(out_npz, w_re=w_re, w_im=w_im, px=px, py=py, pz=pz,
             valid_mask=vm, fallback_mask=fm, unsupported_mask=um,
             rotated_mask=rm, scan_dirs=np.array(SCAN_DIRS))
    print(f'Weights: {out_npz}')

    # ============================================================
    # 封装独立复现包
    # ============================================================
    print(f'\n--- Packaging standalone bundle ---')
    files_to_copy = {
        os.path.join(os.path.dirname(__file__), 'run_8x8_teacher.py'): 'run_8x8_teacher.py',
        os.path.join(os.path.dirname(__file__), 'run_8x8_teacher_qc_v3_2.py'): 'run_8x8_teacher_qc_v3_2.py',
        '/mnt/workspace/gitCode/cann/tiaozhansai/project/mylib/antenna_calc.py': 'antenna_calc.py',
        '/mnt/workspace/gitCode/cann/tiaozhansai/element_port_map.csv': 'element_port_map.csv',
        out_json: 'teacher_8x8_qc_v3_2.json',
        out_npz: 'teacher_8x8_qc_weights_v3_2.npz',
        os.path.join(OUTPUT_DIR, 'teacher_8x8_qc_v3_2.log') if os.path.exists(os.path.join(OUTPUT_DIR, 'teacher_8x8_qc_v3_2.log')) else '/dev/null': 'run.log',
    }
    for src, dst in files_to_copy.items():
        if os.path.exists(src):
            shutil.copy2(src, os.path.join(BUNDLE_DIR, dst))
    # 写配置
    with open(os.path.join(BUNDLE_DIR, 'config.json'), 'w') as f:
        json.dump({
            'frequency_ghz': FREQ_GHZ, 'lambda_mm': LAMBDA_MM,
            'nx': NX, 'ny': NY, 'n_elem': N_ELEM,
            'sll_design': SLL_DESIGN, 'eps_null': EPS_NULL,
            'null_check_db': EPS_NULL_CHECK_DB,
            'trust_radius_factor': TRUST_RADIUS_FACTOR, 'norm_ratio': NORM_RATIO,
            'n_coarse': N_COARSE, 'n_cutting_iters': N_CUTTING_ITERS,
            'n_eval': N_EVAL, 'refine_step_deg': 0.25,
            'scan_dirs': SCAN_DIRS,
            'boundary_thetas': BOUNDARY_THETAS, 'boundary_phis': BOUNDARY_PHIS,
        }, f, indent=2)
    print(f'Bundle: {BUNDLE_DIR}')
    print('=' * 70)


if __name__ == '__main__':
    main()
