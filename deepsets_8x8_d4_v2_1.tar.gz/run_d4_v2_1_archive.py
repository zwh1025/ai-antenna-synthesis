"""D4 v2.1 安全归档: NPZ补字段 + 安全导出器 + 支持域查找表 + 1440°测试 + 全波清单

不重新训练, 不修改536组通过权值。
"""

import os, sys, json, hashlib
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(BASE_DIR, 'mylib'))
OUTPUT_DIR = os.path.join(BASE_DIR, 'output')

N_ELEM = 64
NX = NY = 8

D4_TRANSFORMS = [
    (0, 'identity'), (1, 'rot90'), (2, 'rot180'), (3, 'rot270'),
    (4, 'mirror_x'), (5, 'mirror_y'), (6, 'mirror_diag'), (7, 'mirror_anti'),
]
INVERSE_TID = {0:0, 1:3, 2:2, 3:1, 4:4, 5:5, 6:6, 7:7}


def load_coords():
    import csv
    csv_path = os.path.join(BASE_DIR, 'element_port_map.csv')
    coords = []
    with open(csv_path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            coords.append((
                float(row['x_mm']) / 23.9834,
                float(row['y_mm']) / 23.9834,
                float(row['z_mm']) / 23.9834,
            ))
    return np.array(coords)


def apply_d4_transform(x, y, z, tid):
    if tid == 0: return x, y, z
    elif tid == 1: return y, -x, z
    elif tid == 2: return -x, -y, z
    elif tid == 3: return -y, x, z
    elif tid == 4: return -x, y, z
    elif tid == 5: return x, -y, z
    elif tid == 6: return y, x, z
    elif tid == 7: return -y, -x, z
    return x, y, z


def build_permutation(coords, tid):
    n = len(coords)
    px = coords[:, 0]; py = coords[:, 1]; pz = coords[:, 2]
    perm = np.zeros(n, dtype=np.int32)
    for i in range(n):
        tx, ty, tz = apply_d4_transform(px[i], py[i], pz[i], tid)
        best_j = 0; best_d = 1e10
        for j in range(n):
            d = (px[j]-tx)**2 + (py[j]-ty)**2 + (pz[j]-tz)**2
            if d < best_d: best_d = d; best_j = j
        perm[i] = best_j
    return perm


def transform_phi(phi, tid):
    if tid == 0: return phi % 360
    elif tid == 1: return (phi + 90) % 360
    elif tid == 2: return (phi + 180) % 360
    elif tid == 3: return (phi + 270) % 360
    elif tid == 4: return (180 - phi) % 360
    elif tid == 5: return (360 - phi) % 360
    elif tid == 6: return (90 - phi) % 360
    elif tid == 7: return (270 - phi) % 360
    return phi % 360


def angular_phi_error(p1, p2):
    d = abs(p1 % 360 - p2 % 360)
    return min(d, 360 - d)


def fold_to_canonical(phi_target):
    phi_target = phi_target % 360
    for tid in range(8):
        inv_tid = INVERSE_TID[tid]
        phi_c = transform_phi(phi_target, inv_tid) % 360
        if 0 <= phi_c <= 45 + 1e-10:
            phi_restore = transform_phi(phi_c, tid) % 360
            if angular_phi_error(phi_restore, phi_target) < 1e-10:
                return phi_c, tid
    raise RuntimeError(f"No valid D4 canonical mapping for phi={phi_target}")


def steering_vec(px, py, pz, u, v, w):
    k = 2 * np.pi
    return np.exp(1j * k * (px * u + py * v + pz * w))

def normalize_mainlobe(w, px, py, pz, u0, v0, w0):
    a = steering_vec(px, py, pz, u0, v0, w0)
    resp = np.conj(a) @ w
    if np.abs(resp) < 1e-12: return w
    return w / resp

def angular_dist_deg(th1, ph1, th2, ph2):
    t1, p1 = np.deg2rad(th1), np.deg2rad(ph1)
    t2, p2 = np.deg2rad(th2), np.deg2rad(ph2)
    cos_d = np.cos(t1)*np.cos(t2) + np.sin(t1)*np.sin(t2)*np.cos(p1-p2)
    return float(np.rad2deg(np.arccos(np.clip(cos_d, -1, 1))))

def get_null_dirs(theta0, phi0):
    if theta0 < 10:
        return [(30, 0), (30, 90), (30, 180), (30, 270)]
    return [
        (theta0, (phi0 + 90) % 360),
        (theta0, (phi0 + 180) % 360),
        (theta0, (phi0 + 270) % 360),
        (min(theta0 + 25, 85), (phi0 + 45) % 360),
    ]


def eval_full_81(w, px, py, pz, th0, ph0, null_dirs):
    k = 2 * np.pi
    u0 = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph0))
    v0 = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph0))
    w0 = np.cos(np.deg2rad(th0))
    n_eval = 81
    u = np.linspace(-1, 1, n_eval); v = np.linspace(-1, 1, n_eval)
    ug, vg = np.meshgrid(u, v, indexing='ij')
    vis = (ug**2 + vg**2) <= 1.0; wg = np.sqrt(np.maximum(1-ug**2-vg**2, 0))
    bw = 0.886 * 2.0 / NX * 180 / np.pi
    exc = np.sin(np.deg2rad(3.0 * bw / max(np.cos(np.deg2rad(th0)), 0.1)))
    dist = np.sqrt((ug-u0)**2 + (vg-v0)**2)
    sl_mask = (dist >= exc) & vis
    vf = vis.ravel(); uf = ug.ravel(); vf2 = vg.ravel(); wf = wg.ravel()
    pat = np.zeros(len(uf))
    for i in range(len(uf)):
        if vf[i]:
            psi = k * (px*uf[i] + py*vf2[i] + pz*wf[i])
            pat[i] = np.abs(np.sum(np.conj(w) * np.exp(1j * psi)))
    psi_m = k * (px*u0 + py*v0 + pz*w0)
    mr = np.abs(np.sum(np.conj(w) * np.exp(1j * psi_m)))
    pi2 = np.argmax(pat)
    pval = pat[pi2]
    pu = uf[pi2]; pv = vf2[pi2]; pw = wf[pi2]
    pt_c = np.degrees(np.arcsin(np.clip(np.sqrt(pu**2+pv**2), 0, 1)))
    pp_c = np.degrees(np.arctan2(pv, pu)) % 360
    for rt in np.arange(max(0, pt_c-2.0), min(90, pt_c+2.0)+0.25, 0.25):
        for rpw in np.arange(pp_c-2.0, pp_c+2.0+0.25, 0.25):
            rp = rpw % 360.0
            ru = np.sin(np.deg2rad(rt))*np.cos(np.deg2rad(rp))
            rv = np.sin(np.deg2rad(rt))*np.sin(np.deg2rad(rp))
            rw = np.cos(np.deg2rad(rt))
            if ru**2+rv**2 > 1.0: continue
            vr = np.abs(np.sum(np.conj(w)*np.exp(1j*k*(px*ru+py*rv+pz*rw))))
            if vr > pval: pval=vr; pu=ru; pv=rv; pw=rw
    pr = pval / (mr + 1e-30)
    pth = np.degrees(np.arcsin(np.clip(np.sqrt(pu**2+pv**2), 0, 1)))
    pph = np.degrees(np.arctan2(pv, pu)) % 360
    pte = angular_dist_deg(pth, pph, th0, ph0)
    sf = sl_mask.ravel(); ps = pat[sf]
    sll = 20*np.log10(np.max(ps)/(mr+1e-30)) if mr > 1e-10 else -300
    nulls = []
    for tn, pn in null_dirs:
        un = np.sin(np.deg2rad(tn))*np.cos(np.deg2rad(pn))
        vn = np.sin(np.deg2rad(tn))*np.sin(np.deg2rad(pn))
        wn = np.cos(np.deg2rad(tn))
        nd = 20*np.log10(np.abs(np.sum(np.conj(w)*np.exp(1j*k*(px*un+py*vn+pz*wn))))/(mr+1e-30))
        nulls.append(float(nd))
    return {'sll': float(sll), 'pt': float(pte), 'pr': float(pr),
            'mr': float(mr), 'wn': float(max(nulls)), 'nulls': nulls}


def taylor_2d(Nx, Ny, SLL):
    import math
    posx = (np.arange(1, Nx + 1) - (Nx / 2 + 0.5)) * 0.5
    posy = (np.arange(1, Ny + 1) - (Ny / 2 + 0.5)) * 0.5
    def taylor_1d(N, pos, RdB):
        R0 = 10 ** (RdB / 20)
        A = np.arccosh(R0) / np.pi
        n_bar = max(int(np.ceil(2 * A ** 2 + 0.5)), 2)
        m = np.arange(1, n_bar).reshape(-1, 1)
        n = np.arange(1, n_bar).reshape(1, -1)
        def fact(x):
            return np.array([math.factorial(int(v)) for v in np.asarray(x).ravel()]).reshape(np.asarray(x).shape)
        sigma = n_bar / (A ** 2 + (n_bar - 0.5) ** 2) ** 0.5
        Sm1 = (fact(n_bar - 1) ** 2) / fact(n_bar + m - 1) / fact(n_bar - m - 1)
        Sm2 = np.prod(1 - (m ** 2 / sigma ** 2 / (A ** 2 + (n - 0.5) ** 2)), axis=1).reshape(-1, 1)
        Sm = Sm1 * Sm2
        pos = np.asarray(pos).reshape(1, -1)
        exc = 1 + 2 * np.sum(Sm * np.cos(m * pos * 2 * np.pi / (N * 0.5)), axis=0)
        exc = exc / np.max(exc)
        return exc.ravel()
    ax = taylor_1d(Nx, posx, SLL)
    ay = taylor_1d(Ny, posy, SLL)
    return ax, ay


def main():
    print('='*70)
    print('D4 v2.1 Safety Archive')
    print('='*70)

    coords = load_coords()
    px = coords[:, 0]; py = coords[:, 1]; pz = coords[:, 2]
    perms = {tid: build_permutation(coords, tid) for tid, _ in D4_TRANSFORMS}
    ax_taylor, ay_taylor = taylor_2d(NX, NY, 30)

    # 加载v5_d4_v2结果
    with open(os.path.join(OUTPUT_DIR, 'results_v5_d4_v2.json')) as f:
        v2 = json.load(f)

    block_test = v2['block_test']
    n = len(block_test)
    print(f'Loaded {n} Block Test results from v2')

    # ============================================================
    # 1. 补充NPZ字段
    # ============================================================
    w_re_arr = np.array([[r['w_re'][j] for j in range(N_ELEM)] for r in block_test])
    w_im_arr = np.array([[r['w_im'][j] for j in range(N_ELEM)] for r in block_test])

    final_pass = np.array([r['final_pass'] for r in block_test])
    alpha_arr = np.array([r['alpha'] for r in block_test])
    theta_arr = np.array([r['theta0'] for r in block_test])
    target_phi_arr = np.array([r['target_phi'] for r in block_test])
    canon_phi_arr = np.array([r['canonical_phi'] for r in block_test])
    tid_arr = np.array([r['d4_tid'] for r in block_test])
    parent_id_arr = np.array([r['parent_id'] for r in block_test])

    # 加载支持域标签
    npz_split = np.load(os.path.join(OUTPUT_DIR, 'split_v4_2.npz'), allow_pickle=True)
    labels_all = npz_split['labels']; thetas_all = npz_split['thetas']
    phis_all = npz_split['phis']; t_sll_all = npz_split['taylor_sll']

    support_labels = []
    modes = []
    failure_reasons = []
    safe_to_export = []

    for i, r in enumerate(block_test):
        parent = r['parent_id']
        sl = r.get('support_label', 'valid')

        # mode规则
        if sl == 'valid':
            if r['final_pass']:
                if r['alpha'] == 1.0:
                    mode = 'ai'
                elif r['alpha'] > 0:
                    mode = 'ai_alpha'
                else:
                    mode = 'taylor'  # alpha=0 but pass=taylor
                fail_reason = ''
            else:
                mode = 'rejected_after_alpha'
                fail_reason = 'no_alpha_solution'
                # 检查Taylor是否安全
                t_parent = float(thetas_all[parent])
                ph_parent = float(phis_all[parent])
                wt = np.outer(ay_taylor, ax_taylor).ravel() * np.exp(1j * 2*np.pi * (
                    px*np.sin(np.deg2rad(t_parent))*np.cos(np.deg2rad(ph_parent)) +
                    py*np.sin(np.deg2rad(t_parent))*np.sin(np.deg2rad(ph_parent)) +
                    pz*np.cos(np.deg2rad(t_parent))))
                u0p = np.sin(np.deg2rad(t_parent))*np.cos(np.deg2rad(ph_parent))
                v0p = np.sin(np.deg2rad(t_parent))*np.sin(np.deg2rad(ph_parent))
                w0p = np.cos(np.deg2rad(t_parent))
                wt_n = normalize_mainlobe(wt, px, py, pz, u0p, v0p, w0p)
                nd_p = get_null_dirs(t_parent, ph_parent)
                ev_t = eval_full_81(wt_n, px, py, pz, t_parent, ph_parent, nd_p)
                if ev_t['wn'] > -28:
                    fail_reason += f'; taylor_null_failed; worst_null={ev_t["wn"]:.2f}dB'
        elif sl == 'fallback_taylor':
            mode = 'taylor'
            fail_reason = ''
        elif sl in ('degraded', 'unsupported'):
            mode = 'rejected'
            fail_reason = f'support_label={sl}'
        else:
            mode = 'rejected'
            fail_reason = f'unknown_support_label={sl}'

        support_labels.append(sl)
        modes.append(mode)
        failure_reasons.append(fail_reason)
        safe_to_export.append(mode in ('ai', 'ai_alpha', 'taylor') and r['final_pass'])

    safe_to_export = np.array(safe_to_export, dtype=bool)
    modes_arr = np.array(modes, dtype=object)

    # 统计
    n_safe = np.sum(safe_to_export)
    n_rejected = np.sum(~safe_to_export)
    n_ai = sum(1 for m in modes if m == 'ai')
    n_ai_alpha = sum(1 for m in modes if m == 'ai_alpha')
    n_taylor = sum(1 for m in modes if m == 'taylor')
    n_rejected_after = sum(1 for m in modes if m == 'rejected_after_alpha')
    n_rejected_other = sum(1 for m in modes if m == 'rejected')

    print(f'\nSafety classification:')
    print(f'  ai: {n_ai}, ai_alpha: {n_ai_alpha}, taylor: {n_taylor}')
    print(f'  rejected_after_alpha: {n_rejected_after}, rejected: {n_rejected_other}')
    print(f'  safe_to_export: {n_safe}/{n} ({n_safe/n*100:.1f}%)')

    # 失败方向明细
    failed = [(i, block_test[i]) for i in range(n) if not safe_to_export[i]]
    print(f'\nFailed directions ({len(failed)}):')
    for i, r in failed:
        print(f'  idx={i} th={r["theta0"]:.1f} ph={r["target_phi"]:.1f} '
              f'tid={r["d4_tid"]} parent={r["parent_id"]} '
              f'mode={modes[i]} reason={failure_reasons[i]}')

    # ============================================================
    # 2. 保存安全NPZ
    # ============================================================
    out_npz = os.path.join(OUTPUT_DIR, 'predictions_v5_d4_v2_1.npz')
    np.savez(out_npz,
             w_re=w_re_arr, w_im=w_im_arr,
             px=px, py=py, pz=pz,
             final_pass=final_pass,
             safe_to_export=safe_to_export,
             mode=modes_arr,
             failure_reason=np.array(failure_reasons, dtype=object),
             support_label=np.array(support_labels, dtype=object),
             alpha=alpha_arr,
             canonical_parent_id=parent_id_arr,
             theta=theta_arr,
             target_phi=target_phi_arr,
             canonical_phi=canon_phi_arr,
             d4_tid=tid_arr,
             )

    with open(out_npz, 'rb') as f:
        npz_sha = hashlib.sha256(f.read()).hexdigest()
    print(f'\nNPZ: {out_npz} (SHA: {npz_sha})')

    # ============================================================
    # 3. 保存JSON
    # ============================================================
    results_v21 = {
        'version': 'v2.1',
        'n_total': n,
        'n_safe': int(n_safe),
        'n_failed': int(n_rejected),
        'stats': {
            'ai': n_ai, 'ai_alpha': n_ai_alpha, 'taylor': n_taylor,
            'rejected_after_alpha': n_rejected_after, 'rejected': n_rejected_other,
        },
        'failed_directions': [{
            'idx': i, 'theta': float(r['theta0']), 'phi': float(r['target_phi']),
            'tid': int(r['d4_tid']), 'parent_id': int(r['parent_id']),
            'mode': modes[i], 'failure_reason': failure_reasons[i],
        } for i, r in failed],
        'block_test': block_test,
    }
    out_json = os.path.join(OUTPUT_DIR, 'results_v5_d4_v2_1.json')
    with open(out_json, 'w') as f:
        json.dump(results_v21, f, indent=2, default=str)

    with open(out_json, 'rb') as f:
        json_sha = hashlib.sha256(f.read()).hexdigest()
    print(f'JSON: {out_json} (SHA: {json_sha})')

    # ============================================================
    # 4. 安全导出器
    # ============================================================
    exporter_code = '''"""安全导出器: 只导出safe_to_export=true的权值。"""
import os, sys, json
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(BASE_DIR, 'output')


def export_weights(theta, phi, npz_path=None):
    """导出指定方向的权值。只允许safe_to_export=true。

    Returns:
        (w_re, w_im, metadata) 或 raise ValueError
    """
    if npz_path is None:
        npz_path = os.path.join(OUTPUT_DIR, 'predictions_v5_d4_v2_1.npz')
    data = np.load(npz_path, allow_pickle=True)

    thetas = data['theta']
    phis = data['target_phi']
    safe = data['safe_to_export']

    # 查找匹配方向
    best_idx = -1; best_dist = 1e10
    for i in range(len(thetas)):
        d = abs(float(thetas[i]) - theta) + abs(float(phis[i]) - phi)
        if d < best_dist:
            best_dist = d; best_idx = i

    if best_dist > 0.1:
        raise ValueError(f'No matching direction for theta={theta}, phi={phi}')

    if not bool(safe[best_idx]):
        mode = str(data['mode'][best_idx])
        reason = str(data['failure_reason'][best_idx])
        raise ValueError(
            f'Direction theta={theta}, phi={phi} is NOT safe to export.\\n'
            f'  mode={mode}, failure_reason={reason}\\n'
            f'  support_label={str(data["support_label"][best_idx])}\\n'
            f'  This direction must not be used to excite HFSS.')

    w_re = data['w_re'][best_idx]
    w_im = data['w_im'][best_idx]
    meta = {
        'idx': int(best_idx),
        'theta': float(data['theta'][best_idx]),
        'phi': float(data['target_phi'][best_idx]),
        'mode': str(data['mode'][best_idx]),
        'alpha': float(data['alpha'][best_idx]),
        'tid': int(data['d4_tid'][best_idx]),
        'parent_id': int(data['canonical_parent_id'][best_idx]),
    }
    return w_re, w_im, meta


def list_safe_directions(npz_path=None):
    """列出所有可导出方向。"""
    if npz_path is None:
        npz_path = os.path.join(OUTPUT_DIR, 'predictions_v5_d4_v2_1.npz')
    data = np.load(npz_path, allow_pickle=True)
    safe = data['safe_to_export']
    results = []
    for i in range(len(safe)):
        if bool(safe[i]):
            results.append({
                'idx': i,
                'theta': float(data['theta'][i]),
                'phi': float(data['target_phi'][i]),
                'mode': str(data['mode'][i]),
                'alpha': float(data['alpha'][i]),
            })
    return results


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--theta', type=float, required=True)
    parser.add_argument('--phi', type=float, required=True)
    args = parser.parse_args()
    try:
        w_re, w_im, meta = export_weights(args.theta, args.phi)
        print(f'OK: {meta}')
        print(f'  w_re[:5]: {w_re[:5]}')
    except ValueError as e:
        print(f'REJECTED: {e}')
        sys.exit(1)
'''
    exporter_path = os.path.join(BASE_DIR, 'export_safe_weights.py')
    with open(exporter_path, 'w') as f:
        f.write(exporter_code)
    print(f'Exporter: {exporter_path}')

    # ============================================================
    # 5. 支持域查找表
    # ============================================================
    # 从v4教师数据构建canonical支持域
    teacher_npz = np.load(os.path.join(OUTPUT_DIR, 'split_v4_2.npz'), allow_pickle=True)
    t_labels = teacher_npz['labels']
    t_thetas = teacher_npz['thetas']
    t_phis = teacher_npz['phis']
    t_t_sll = teacher_npz['taylor_sll']

    canonical_support = []
    for i in range(len(t_thetas)):
        if t_labels[i] != 1:
            # 非valid: 确定分类
            if t_t_sll[i] > -15:
                label = 'degraded'
            elif t_t_sll[i] > -28:
                label = 'fallback_taylor'
            else:
                label = 'unsupported'
        else:
            label = 'valid'

        # 折叠到canonical
        th = float(t_thetas[i])
        ph = float(t_phis[i])
        try:
            canon_ph, tid = fold_to_canonical(ph)
        except:
            canon_ph = ph % 46; tid = 0

        canonical_support.append({
            'theta': th, 'canonical_phi': canon_ph,
            'original_phi': ph, 'label': label,
            'source_idx': i,
        })

    # 保存查找表
    lookup = {
        'version': 'v2.1',
        'description': 'D4 canonical support domain lookup table',
        'note': 'unknown directions must be conservatively rejected',
        'entries': canonical_support,
    }
    lookup_json = os.path.join(OUTPUT_DIR, 'support_domain_lookup.json')
    with open(lookup_json, 'w') as f:
        json.dump(lookup, f, indent=2, default=str)

    # NPZ版本
    lookup_npz = os.path.join(OUTPUT_DIR, 'support_domain_lookup.npz')
    np.savez(lookup_npz,
             theta=np.array([e['theta'] for e in canonical_support]),
             canonical_phi=np.array([e['canonical_phi'] for e in canonical_support]),
             label=np.array([e['label'] for e in canonical_support], dtype=object),
             source_idx=np.array([e['source_idx'] for e in canonical_support]),
             )
    print(f'Lookup JSON: {lookup_json}')
    print(f'Lookup NPZ: {lookup_npz}')

    def lookup_support(theta, phi):
        """查询支持域。返回(label, source_idx, nearest_dist)。"""
        canon_ph, tid = fold_to_canonical(phi)
        best_idx = -1; best_dist = 1e10
        for e in canonical_support:
            d = abs(e['theta'] - theta) + abs(e['canonical_phi'] - canon_ph)
            if d < best_dist:
                best_dist = d; best_idx = e['source_idx']
        if best_dist > 5.0:
            return 'unknown', -1, float(best_dist)
        return canonical_support[best_idx]['label'], best_idx, float(best_dist)

    # 测试查找表
    print(f'\nSupport domain lookup test:')
    test_cases = [
        (30, 0, 'valid'), (30, 90, 'valid'), (45, 0, 'degraded'),
        (60, 0, 'unsupported'), (14, 15, 'valid'),
    ]
    for th, ph, expected in test_cases:
        label, src, dist = lookup_support(th, ph)
        print(f'  th={th} ph={ph}: label={label} dist={dist:.1f} (expected~{expected})')

    # ============================================================
    # 6. 1440点360°测试
    # ============================================================
    print(f'\n{"="*70}')
    print('360° TEST (0.25° step, 1440 points)')
    print(f'{"="*70}')

    tid_counts = {tid: 0 for tid in range(8)}
    n_pass = 0

    for i in range(1440):
        ph0 = i * 0.25
        th0 = 30.0
        try:
            canon_ph, tid = fold_to_canonical(ph0)
            tid_counts[tid] += 1

            ph_restore = transform_phi(canon_ph, tid) % 360
            err = angular_phi_error(ph_restore, ph0)

            if err < 1e-10 and 0 <= canon_ph <= 45.0001:
                n_pass += 1
            else:
                print(f'  FAIL: phi={ph0} canon={canon_ph} tid={tid} err={err:.2e}')
        except RuntimeError as e:
            print(f'  FAIL: phi={ph0} {e}')

    print(f'  Total: 1440, Pass: {n_pass}, Fail: {1440-n_pass}')
    print(f'  TID distribution: {tid_counts}')
    print(f'  All 8 TIDs present: {len(tid_counts) == 8 and all(v > 0 for v in tid_counts.values())}')

    # ============================================================
    # 7. 全波验证清单
    # ============================================================
    print(f'\n{"="*70}')
    print('Fullwave Validation Manifest')
    print(f'{"="*70}')

    # 从safe方向中选代表
    safe_indices = [i for i in range(n) if safe_to_export[i]]
    manifest = []

    # 1. Canonical (tid=0)
    for i in safe_indices:
        if tid_arr[i] == 0 and theta_arr[i] >= 28 and theta_arr[i] <= 32:
            r = block_test[i]
            manifest.append({
                'category': 'canonical',
                'theta': float(r['theta0']), 'phi': float(r['target_phi']),
                'tid': int(r['d4_tid']), 'parent_id': int(r['parent_id']),
                'mode': modes[i], 'alpha': float(r['alpha']),
                'support_label': support_labels[i],
                'ai_sll': float(r['ai_sll']),
                'final_sll': float(r['final_sll']),
                'taylor_sll': float(r['taylor_sll']),
            })
            break

    # 2. 镜像 (tid=4-7)
    for i in safe_indices:
        if tid_arr[i] in [4, 5, 6, 7] and theta_arr[i] >= 28 and theta_arr[i] <= 32:
            r = block_test[i]
            manifest.append({
                'category': 'mirror',
                'theta': float(r['theta0']), 'phi': float(r['target_phi']),
                'tid': int(r['d4_tid']), 'parent_id': int(r['parent_id']),
                'mode': modes[i], 'alpha': float(r['alpha']),
            })
            break

    # 3. 旋转 (tid=1-3)
    for i in safe_indices:
        if tid_arr[i] in [1, 2, 3] and theta_arr[i] >= 28 and theta_arr[i] <= 32:
            r = block_test[i]
            manifest.append({
                'category': 'rotation',
                'theta': float(r['theta0']), 'phi': float(r['target_phi']),
                'tid': int(r['d4_tid']), 'parent_id': int(r['parent_id']),
                'mode': modes[i], 'alpha': float(r['alpha']),
            })
            break

    # 4. 高角度
    for i in safe_indices:
        if theta_arr[i] >= 50:
            r = block_test[i]
            manifest.append({
                'category': 'high_angle',
                'theta': float(r['theta0']), 'phi': float(r['target_phi']),
                'tid': int(r['d4_tid']), 'parent_id': int(r['parent_id']),
                'mode': modes[i], 'alpha': float(r['alpha']),
            })
            break

    # 5. 轻度alpha (0.7-0.9)
    for i in safe_indices:
        if 0.7 <= alpha_arr[i] <= 0.9:
            r = block_test[i]
            manifest.append({
                'category': 'alpha_mild',
                'theta': float(r['theta0']), 'phi': float(r['target_phi']),
                'tid': int(r['d4_tid']), 'parent_id': int(r['parent_id']),
                'mode': modes[i], 'alpha': float(r['alpha']),
            })
            break

    # 6. 较强alpha (0.3-0.6)
    for i in safe_indices:
        if 0.3 <= alpha_arr[i] <= 0.6:
            r = block_test[i]
            manifest.append({
                'category': 'alpha_strong',
                'theta': float(r['theta0']), 'phi': float(r['target_phi']),
                'tid': int(r['d4_tid']), 'parent_id': int(r['parent_id']),
                'mode': modes[i], 'alpha': float(r['alpha']),
            })
            break

    # 7. fallback_taylor
    for i in range(n):
        if support_labels[i] == 'fallback_taylor':
            r = block_test[i]
            manifest.append({
                'category': 'fallback_taylor_control',
                'theta': float(r['theta0']), 'phi': float(r['target_phi']),
                'tid': int(r['d4_tid']), 'parent_id': int(r['parent_id']),
                'mode': modes[i], 'alpha': float(r['alpha']),
                'safe_to_export': bool(safe_to_export[i]),
            })
            break

    # 8. degraded
    for i in range(n):
        if support_labels[i] == 'degraded':
            r = block_test[i]
            manifest.append({
                'category': 'degraded_control',
                'theta': float(r['theta0']), 'phi': float(r['target_phi']),
                'tid': int(r['d4_tid']), 'parent_id': int(r['parent_id']),
                'mode': modes[i], 'safe_to_export': bool(safe_to_export[i]),
                'note': 'MUST NOT export to HFSS',
            })
            break

    # 9. rejected_after_alpha
    for i in range(n):
        if not safe_to_export[i] and modes[i] == 'rejected_after_alpha':
            r = block_test[i]
            manifest.append({
                'category': 'rejected_control',
                'theta': float(r['theta0']), 'phi': float(r['target_phi']),
                'tid': int(r['d4_tid']), 'parent_id': int(r['parent_id']),
                'mode': modes[i], 'failure_reason': failure_reasons[i],
                'safe_to_export': False,
                'note': 'MUST NOT export to HFSS - rejected_after_alpha',
            })
            break

    # 计算权值SHA-256
    for m in manifest:
        idx = m.get('parent_id', 0)
        if 'safe_to_export' in m and not m['safe_to_export']:
            m['weight_sha256'] = 'N/A (not safe to export)'
        else:
            # 找对应的NPZ索引
            for i in range(n):
                if theta_arr[i] == m['theta'] and abs(target_phi_arr[i] - m['phi']) < 0.01:
                    w_bytes = (w_re_arr[i].tobytes() + w_im_arr[i].tobytes())
                    m['weight_sha256'] = hashlib.sha256(w_bytes).hexdigest()[:16]
                    break

    manifest_path = os.path.join(OUTPUT_DIR, 'fullwave_validation_manifest.json')
    with open(manifest_path, 'w') as f:
        json.dump(manifest, f, indent=2, default=str)
    print(f'Manifest: {manifest_path} ({len(manifest)} entries)')
    for m in manifest:
        print(f'  {m["category"]}: th={m["theta"]:.1f} ph={m["phi"]:.1f} '
              f'mode={m.get("mode","")} alpha={m.get("alpha","")} safe={m.get("safe_to_export",True)}')

    # ============================================================
    # SHA-256 SUMMARY
    # ============================================================
    print(f'\n{"="*70}')
    print('SHA-256 SUMMARY')
    print(f'{"="*70}')
    sha_list = {}
    for name, path in [
        ('predictions_v5_d4_v2_1.npz', out_npz),
        ('results_v5_d4_v2_1.json', out_json),
        ('support_domain_lookup.json', lookup_json),
        ('support_domain_lookup.npz', lookup_npz),
        ('fullwave_validation_manifest.json', manifest_path),
        ('export_safe_weights.py', exporter_path),
    ]:
        with open(path, 'rb') as f:
            sha = hashlib.sha256(f.read()).hexdigest()
        sha_list[name] = sha
        print(f'  {name}: {sha}')

    with open(os.path.join(OUTPUT_DIR, 'sha256_v5_d4_v2_1.txt'), 'w') as f:
        for name, sha in sha_list.items():
            f.write(f'{name}: {sha}\n')

    print(f'\n{"="*70}')
    print('DONE - AI weights frozen, ready for fullwave verification')
    print(f'{"="*70}')


if __name__ == '__main__':
    main()
