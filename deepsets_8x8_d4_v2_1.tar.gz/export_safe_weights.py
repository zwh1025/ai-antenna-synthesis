"""安全导出器: 只导出safe_to_export=true的权值。"""
import os, sys, json
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(BASE_DIR, 'output')


def export_weights(theta, phi, npz_path=None):
    """导出指定方向的权值。只允许safe_to_export=true。

    Returns:
        (w_re, w_im, metadata) 或 raise ValueError
    """
    if npz_path is None:
        npz_path = os.path.join(OUTPUT_DIR, 'predictions_v5_d4_v2_1.npz')
    data = np.load(npz_path, allow_pickle=True)

    thetas = data['theta']
    phis = data['target_phi']
    safe = data['safe_to_export']

    # 查找匹配方向
    best_idx = -1; best_dist = 1e10
    for i in range(len(thetas)):
        d = abs(float(thetas[i]) - theta) + abs(float(phis[i]) - phi)
        if d < best_dist:
            best_dist = d; best_idx = i

    if best_dist > 0.1:
        raise ValueError(f'No matching direction for theta={theta}, phi={phi}')

    if not bool(safe[best_idx]):
        mode = str(data['mode'][best_idx])
        reason = str(data['failure_reason'][best_idx])
        raise ValueError(
            f'Direction theta={theta}, phi={phi} is NOT safe to export.\n'
            f'  mode={mode}, failure_reason={reason}\n'
            f'  support_label={str(data["support_label"][best_idx])}\n'
            f'  This direction must not be used to excite HFSS.')

    w_re = data['w_re'][best_idx]
    w_im = data['w_im'][best_idx]
    meta = {
        'idx': int(best_idx),
        'theta': float(data['theta'][best_idx]),
        'phi': float(data['target_phi'][best_idx]),
        'mode': str(data['mode'][best_idx]),
        'alpha': float(data['alpha'][best_idx]),
        'tid': int(data['d4_tid'][best_idx]),
        'parent_id': int(data['canonical_parent_id'][best_idx]),
    }
    return w_re, w_im, meta


def list_safe_directions(npz_path=None):
    """列出所有可导出方向。"""
    if npz_path is None:
        npz_path = os.path.join(OUTPUT_DIR, 'predictions_v5_d4_v2_1.npz')
    data = np.load(npz_path, allow_pickle=True)
    safe = data['safe_to_export']
    results = []
    for i in range(len(safe)):
        if bool(safe[i]):
            results.append({
                'idx': i,
                'theta': float(data['theta'][i]),
                'phi': float(data['target_phi'][i]),
                'mode': str(data['mode'][i]),
                'alpha': float(data['alpha'][i]),
            })
    return results


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--theta', type=float, required=True)
    parser.add_argument('--phi', type=float, required=True)
    args = parser.parse_args()
    try:
        w_re, w_im, meta = export_weights(args.theta, args.phi)
        print(f'OK: {meta}')
        print(f'  w_re[:5]: {w_re[:5]}')
    except ValueError as e:
        print(f'REJECTED: {e}')
        sys.exit(1)
