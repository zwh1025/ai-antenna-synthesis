"""8×8 SOCP教师质检 v3.1

修改：
  1. np.rot90(k=-rot_times) + 坐标置换验证
  2. 无best_valid时一律检查Taylor（不论有无best_invalid）
  3. 第二部分：θ=45°/60° φ=0° 信赖域扫描
"""

import os, sys, time, json
import numpy as np
import cvxpy as cp

sys.path.insert(0, '/mnt/workspace/gitCode/cann/tiaozhansai/project')
from mylib.antenna_calc import taylor_2d_separable, angular_distance_deg
from run_8x8_teacher import (
    load_real_coordinates, steering_vec_3d, coordinate_taylor_3d,
    normalize_weights, uv_to_uvw, get_null_dirs,
)

OUTPUT_DIR = '/mnt/workspace/gitCode/cann/tiaozhansai/revision/results'
os.makedirs(OUTPUT_DIR, exist_ok=True)

LAMBDA_MM = 23.9834
NX = NY = 8
N_ELEM = 64
SLL_DESIGN = 30
FREQ_GHZ = 12.5
EPS_NULL = 0.0398
N_COARSE = 11
N_CUTTING_ITERS = 10
N_EVAL = 81
TRUST_RADIUS_FACTOR = 0.3
NORM_RATIO = 1.5

SCAN_DIRS = [(0.0, 0.0)]
for th in [15.0, 30.0, 45.0, 60.0]:
    for ph in [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0]:
        SCAN_DIRS.append((th, ph))


def angular_distance_uvw(q1, q2):
    q1 = np.asarray(q1, dtype=float)
    q2 = np.asarray(q2, dtype=float)
    n1 = np.linalg.norm(q1); n2 = np.linalg.norm(q2)
    if n1 < 1e-10 or n2 < 1e-10:
        return 180.0
    return float(np.degrees(np.arccos(np.clip(np.dot(q1, q2) / (n1 * n2), -1.0, 1.0))))


def solve_socp_with_trust(px, py, pz, u0, v0, w0,
                           sl_u, sl_v, sl_w,
                           null_u, null_v, null_w,
                           w_taylor_norm, trust_r, norm_max,
                           peak_constraints=None):
    n = len(px)
    w = cp.Variable(n, complex=True)
    t = cp.Variable()
    a_main = steering_vec_3d(px, py, pz, u0, v0, w0)
    constraints = [a_main.conj() @ w == 1.0 + 0j]
    for u_s, v_s, w_s in zip(sl_u, sl_v, sl_w):
        a_sl = steering_vec_3d(px, py, pz, u_s, v_s, w_s)
        constraints.append(cp.norm(a_sl.conj() @ w, 2) <= t)
    for u_n, v_n, w_n in zip(null_u, null_v, null_w):
        a_n = steering_vec_3d(px, py, pz, u_n, v_n, w_n)
        constraints.append(cp.norm(a_n.conj() @ w, 2) <= EPS_NULL)
    w_diff = w - (w_taylor_norm.real + 1j * w_taylor_norm.imag)
    constraints.append(cp.norm(w_diff, 2) <= trust_r)
    constraints.append(cp.norm(w, 2) <= norm_max)
    if peak_constraints:
        for u_p, v_p, w_p in peak_constraints:
            a_p = steering_vec_3d(px, py, pz, u_p, v_p, w_p)
            constraints.append(cp.norm(a_p.conj() @ w, 2) <= 1.0)
    prob = cp.Problem(cp.Minimize(t), constraints)
    try:
        prob.solve(solver=cp.SCS, verbose=False, max_iters=20000)
        if prob.status not in ['optimal', 'optimal_inaccurate']:
            return None, prob.status
    except Exception as e:
        return None, str(e)
    return w.value, prob.status


def eval_full_3d(w, px, py, pz, theta0, phi0, null_dirs, n_eval=N_EVAL):
    k = 2 * np.pi
    u0 = np.sin(np.deg2rad(theta0)) * np.cos(np.deg2rad(phi0))
    v0 = np.sin(np.deg2rad(theta0)) * np.sin(np.deg2rad(phi0))
    w0 = np.cos(np.deg2rad(theta0))
    u = np.linspace(-1, 1, n_eval)
    v = np.linspace(-1, 1, n_eval)
    ug, vg = np.meshgrid(u, v, indexing='ij')
    vis = (ug**2 + vg**2) <= 1.0
    wg = uv_to_uvw(ug, vg)
    bw = 0.886 * 2.0 / NX * 180 / np.pi
    exc_uv = np.sin(np.deg2rad(3.0 * bw / max(np.cos(np.deg2rad(theta0)), 0.1)))
    dist = np.sqrt((ug - u0)**2 + (vg - v0)**2)
    sl_mask = (dist >= exc_uv) & vis
    vis_flat = vis.ravel()
    ug_flat = ug.ravel()
    vg_flat = vg.ravel()
    wg_flat = wg.ravel()
    pat_all = np.zeros(len(ug_flat))
    for i in range(len(ug_flat)):
        if vis_flat[i]:
            psi = k * (px * ug_flat[i] + py * vg_flat[i] + pz * wg_flat[i])
            pat_all[i] = np.abs(np.sum(np.conj(w) * np.exp(1j * psi)))
    psi_main = k * (px * u0 + py * v0 + pz * w0)
    main_resp = np.abs(np.sum(np.conj(w) * np.exp(1j * psi_main)))
    peak_idx = np.argmax(pat_all)
    peak_u = ug_flat[peak_idx]; peak_v = vg_flat[peak_idx]; peak_w = wg_flat[peak_idx]
    peak_val = pat_all[peak_idx]
    peak_theta_c = np.degrees(np.arcsin(np.clip(np.sqrt(peak_u**2 + peak_v**2), 0, 1)))
    peak_phi_c = np.degrees(np.arctan2(peak_v, peak_u)) % 360
    refine_range = 2.0; refine_step = 0.25
    for rt in np.arange(max(0, peak_theta_c - refine_range),
                        min(90, peak_theta_c + refine_range) + refine_step, refine_step):
        for rp_uw in np.arange(peak_phi_c - refine_range,
                               peak_phi_c + refine_range + refine_step, refine_step):
            rp = rp_uw % 360.0
            ru = np.sin(np.deg2rad(rt)) * np.cos(np.deg2rad(rp))
            rv = np.sin(np.deg2rad(rt)) * np.sin(np.deg2rad(rp))
            rw = np.cos(np.deg2rad(rt))
            if ru**2 + rv**2 > 1.0: continue
            psi_r = k * (px * ru + py * rv + pz * rw)
            val_r = np.abs(np.sum(np.conj(w) * np.exp(1j * psi_r)))
            if val_r > peak_val:
                peak_val = val_r; peak_u = ru; peak_v = rv; peak_w = rw
    peak_ratio = peak_val / (main_resp + 1e-30)
    peak_theta = np.degrees(np.arcsin(np.clip(np.sqrt(peak_u**2 + peak_v**2), 0, 1)))
    peak_phi = np.degrees(np.arctan2(peak_v, peak_u)) % 360
    pt_err = angular_distance_deg(peak_theta, peak_phi, theta0, phi0)
    sl_flat = sl_mask.ravel()
    pat_sl = pat_all[sl_flat]
    sll = 20 * np.log10(np.max(pat_sl) / (main_resp + 1e-30)) if main_resp > 1e-10 else -300
    sl_u_f = ug_flat[sl_flat]; sl_v_f = vg_flat[sl_flat]; sl_w_f = wg_flat[sl_flat]
    sorted_idx = np.argsort(pat_sl)[::-1][:10]
    worst = [(sl_u_f[i], sl_v_f[i], sl_w_f[i]) for i in sorted_idx]
    null_results = []
    for tn, pn in null_dirs:
        un = np.sin(np.deg2rad(tn)) * np.cos(np.deg2rad(pn))
        vn = np.sin(np.deg2rad(tn)) * np.sin(np.deg2rad(pn))
        wn = np.cos(np.deg2rad(tn))
        psi_n = k * (px * un + py * vn + pz * wn)
        nd = 20 * np.log10(np.abs(np.sum(np.conj(w) * np.exp(1j * psi_n))) / (main_resp + 1e-30))
        null_results.append(float(nd))
    return {
        'sll': float(sll), 'pointing_err': float(pt_err),
        'main_resp': float(main_resp), 'peak_ratio': float(peak_ratio),
        'peak_u': float(peak_u), 'peak_v': float(peak_v), 'peak_w': float(peak_w),
        'worst_null': float(max(null_results)), 'null_depths': null_results,
        'worst_sidelobes': worst,
    }


def check_safety(ev, main_err, w_norm, t_norm):
    if main_err > 1e-3: return False, f'main_err={main_err:.2e}'
    if ev['pointing_err'] > 1.0: return False, f'pt={ev["pointing_err"]:.2f}'
    if ev['peak_ratio'] > 1.001: return False, f'peak={ev["peak_ratio"]:.4f}'
    if ev['worst_null'] > -28: return False, f'null={ev["worst_null"]:.1f}'
    nr = w_norm / (t_norm + 1e-30)
    if nr > NORM_RATIO: return False, f'norm={nr:.2f}'
    return True, ''

def check_teacher(ev, t_sll, main_err, w_norm, t_norm):
    ok, r = check_safety(ev, main_err, w_norm, t_norm)
    if not ok: return False, r
    imp = ev['sll'] - t_sll
    if imp > -0.5: return False, f'imp={imp:.1f}'
    return True, ''


def rotate_weight_90(w_2d, rot_times):
    """np.rot90(k=-rot_times) + 坐标置换验证。"""
    w_rot = np.rot90(w_2d, k=-rot_times)
    return w_rot


def verify_rotation(px_2d, py_2d, rot_times, target_delta_phi):
    """验证旋转后坐标满足物理旋转。"""
    # 90度旋转: (x,y) -> (y,-x) for k=1 (clockwise)
    # np.rot90 with k=-1 is clockwise
    px_rot = np.rot90(px_2d, k=-rot_times)
    py_rot = np.rot90(py_2d, k=-rot_times)
    # 验证: 旋转rot_times*90度后, 新坐标应为旧坐标旋转
    # 顺时针90度: (x,y)->(y,-x)
    if rot_times == 0:
        return True  # no rotation
    # 检查是否匹配
    if rot_times % 4 == 1:
        match = np.allclose(px_rot, py_2d, atol=1e-10) and np.allclose(py_rot, -px_2d, atol=1e-10)
    elif rot_times % 4 == 2:
        match = np.allclose(px_rot, -px_2d, atol=1e-10) and np.allclose(py_rot, -py_2d, atol=1e-10)
    elif rot_times % 4 == 3:
        match = np.allclose(px_rot, -py_2d, atol=1e-10) and np.allclose(py_rot, px_2d, atol=1e-10)
    else:
        match = True
    return bool(match)


def solve_direction(px, py, pz, amp_x, amp_y, theta0, phi0, null_dirs,
                    trust_r_factor=TRUST_RADIUS_FACTOR, norm_ratio=NORM_RATIO):
    u0 = np.sin(np.deg2rad(theta0)) * np.cos(np.deg2rad(phi0))
    v0 = np.sin(np.deg2rad(theta0)) * np.sin(np.deg2rad(phi0))
    w0 = np.cos(np.deg2rad(theta0))
    w_taylor = coordinate_taylor_3d(px, py, pz, amp_x, amp_y, theta0, phi0)
    w_taylor_n = normalize_weights(w_taylor, px, py, pz, u0, v0, w0)
    t_eval = eval_full_3d(w_taylor_n, px, py, pz, theta0, phi0, null_dirs)
    t_norm = np.linalg.norm(w_taylor_n)
    t_main_err = abs(abs(np.conj(steering_vec_3d(px, py, pz, u0, v0, w0)) @ w_taylor_n) - 1.0)
    null_u = [np.sin(np.deg2rad(tn)) * np.cos(np.deg2rad(pn)) for tn, pn in null_dirs]
    null_v = [np.sin(np.deg2rad(tn)) * np.sin(np.deg2rad(pn)) for tn, pn in null_dirs]
    null_w = [np.cos(np.deg2rad(tn)) for tn, pn in null_dirs]
    u_c = np.linspace(-1, 1, N_COARSE); v_c = np.linspace(-1, 1, N_COARSE)
    ug_c, vg_c = np.meshgrid(u_c, v_c, indexing='ij')
    vis_c = (ug_c**2 + vg_c**2) <= 1.0; wg_c = uv_to_uvw(ug_c, vg_c)
    bw = 0.886 * 2.0 / NX * 180 / np.pi
    exc_uv = np.sin(np.deg2rad(3.0 * bw / max(np.cos(np.deg2rad(theta0)), 0.1)))
    dist_c = np.sqrt((ug_c - u0)**2 + (vg_c - v0)**2)
    sl_mask_c = (dist_c >= exc_uv) & vis_c
    sl_u = list(ug_c[sl_mask_c]); sl_v = list(vg_c[sl_mask_c]); sl_w = list(wg_c[sl_mask_c])
    trust_r = trust_r_factor * t_norm
    norm_max = norm_ratio * t_norm
    best_valid = None; best_invalid = None
    peak_constraints = []; solver_status = 'not_attempted'; n_iters = 0
    for it in range(N_CUTTING_ITERS):
        w_opt, solver_status = solve_socp_with_trust(
            px, py, pz, u0, v0, w0, sl_u, sl_v, sl_w,
            null_u, null_v, null_w, w_taylor_n, trust_r, norm_max, peak_constraints)
        if w_opt is None: break
        w_opt_n = normalize_weights(w_opt, px, py, pz, u0, v0, w0)
        s_eval = eval_full_3d(w_opt_n, px, py, pz, theta0, phi0, null_dirs)
        n_iters = it + 1
        main_err = abs(abs(np.conj(steering_vec_3d(px, py, pz, u0, v0, w0)) @ w_opt_n) - 1.0)
        w_norm = np.linalg.norm(w_opt_n)
        is_t, reason = check_teacher(s_eval, t_eval['sll'], main_err, w_norm, t_norm)
        if is_t:
            if best_valid is None or s_eval['sll'] < best_valid['sll']:
                best_valid = {'sll': s_eval['sll'], 'w': w_opt_n.copy(), 'eval': s_eval,
                              'main_err': main_err, 'w_norm': w_norm}
        else:
            is_s, _ = check_safety(s_eval, main_err, w_norm, t_norm)
            if is_s:
                if best_invalid is None or s_eval['sll'] < best_invalid['sll']:
                    best_invalid = {'sll': s_eval['sll'], 'w': w_opt_n.copy(), 'eval': s_eval,
                                    'main_err': main_err, 'w_norm': w_norm, 'reason': reason}
        if s_eval['peak_ratio'] > 1.001 or s_eval['pointing_err'] > 1.0:
            new_peak = (s_eval['peak_u'], s_eval['peak_v'], s_eval['peak_w'])
            too_close = any(angular_distance_uvw(new_peak, pc) < 2.0 for pc in peak_constraints)
            if not too_close and len(peak_constraints) < 5:
                peak_constraints.append(new_peak)
        for u_w, v_w, w_w in s_eval['worst_sidelobes'][:2]:
            already = any(abs(su-u_w)<0.01 and abs(sv-v_w)<0.01 for su, sv in zip(sl_u, sl_v))
            if not already:
                sl_u.append(u_w); sl_v.append(v_w); sl_w.append(w_w)
    return {
        'best_valid': best_valid, 'best_invalid': best_invalid,
        'taylor_eval': t_eval, 'w_taylor': w_taylor_n, 't_norm': t_norm,
        't_main_err': t_main_err, 'solver_status': solver_status,
        'n_iters': n_iters, 'n_peaks': len(peak_constraints),
    }


def main():
    print('=' * 70)
    print('8x8 SOCP Teacher QC v3.1')
    print('=' * 70)

    coords, normals = load_real_coordinates()
    px, py, pz = coords[:, 0], coords[:, 1], coords[:, 2]
    amp_x, amp_y = taylor_2d_separable(NX, NY, SLL_DESIGN)

    # 8x8坐标矩阵用于旋转验证
    px_2d = px.reshape(NY, NX)
    py_2d = py.reshape(NY, NX)

    results = {}; weights = {}; statuses = {}
    t_start = time.time()

    # ============================================================
    # Phase 1: 33方向求解
    # ============================================================
    for i, (theta0, phi0) in enumerate(SCAN_DIRS):
        null_dirs = get_null_dirs(theta0, phi0)
        sol = solve_direction(px, py, pz, amp_x, amp_y, theta0, phi0, null_dirs)

        # 最终选择: 无best_valid时一律检查Taylor
        if sol['best_valid'] is not None:
            bv = sol['best_valid']
            final_w = bv['w']; final_eval = bv['eval']
            final_main_err = bv['main_err']; final_w_norm = bv['w_norm']
            status = 'valid'
        else:
            # 检查Taylor安全(不论是否有best_invalid)
            t_safe, _ = check_safety(sol['taylor_eval'], sol['t_main_err'],
                                     sol['t_norm'], sol['t_norm'])
            if t_safe:
                final_w = sol['w_taylor']; final_eval = sol['taylor_eval']
                final_main_err = sol['t_main_err']; final_w_norm = sol['t_norm']
                status = 'fallback_taylor'
            else:
                # Taylor也不安全
                if sol['best_invalid'] is not None:
                    bi = sol['best_invalid']
                    final_w = bi['w']; final_eval = bi['eval']
                    final_main_err = bi['main_err']; final_w_norm = bi['w_norm']
                else:
                    final_w = sol['w_taylor']; final_eval = sol['taylor_eval']
                    final_main_err = sol['t_main_err']; final_w_norm = sol['t_norm']
                status = 'unsupported_direction'

        improvement = final_eval['sll'] - sol['taylor_eval']['sll']
        norm_ratio = final_w_norm / (sol['t_norm'] + 1e-30)
        r = {
            'idx': i, 'theta0': float(theta0), 'phi0': float(phi0),
            'taylor_sll': float(sol['taylor_eval']['sll']),
            'final_sll': float(final_eval['sll']), 'improvement': float(improvement),
            'final_pt': float(final_eval['pointing_err']),
            'peak_ratio': float(final_eval['peak_ratio']),
            'worst_null': float(final_eval['worst_null']),
            'null_depths': final_eval['null_depths'],
            'w_norm': float(final_w_norm), 't_norm': float(sol['t_norm']),
            'norm_ratio': float(norm_ratio), 'max_amp': float(np.max(np.abs(final_w))),
            'main_err': float(final_main_err), 'solver_status': sol['solver_status'],
            'n_iters': sol['n_iters'], 'n_peaks': sol['n_peaks'],
            'status': status, 'rotation_applied': False,
        }
        results[i] = r; weights[i] = (final_w.real.copy(), final_w.imag.copy())
        statuses[i] = status
        print(f'  [{i+1:2d}/{len(SCAN_DIRS)}] th={theta0:.0f} ph={phi0:>3.0f} '
              f'T={sol["taylor_eval"]["sll"]:.1f} F={final_eval["sll"]:.1f} '
              f'd={improvement:+.1f} pt={final_eval["pointing_err"]:.2f} '
              f'peak={final_eval["peak_ratio"]:.4f} null={final_eval["worst_null"]:.1f} '
              f'norm={norm_ratio:.2f} [{status}]')

    # ============================================================
    # Phase 2: 旋转对称性
    # ============================================================
    print(f'\n{"="*70}\nPHASE 2: ROTATION SYMMETRY\n{"="*70}')
    symmetry_results = []; symmetry_failures = []

    for th in [15.0, 30.0, 45.0, 60.0]:
        for group_phis, gname in [([0, 90, 180, 270], 'axial'), ([45, 135, 225, 315], 'diagonal')]:
            gidx = [next(i for i, (t, p) in enumerate(SCAN_DIRS) if t == th and p == ph) for ph in group_phis]
            gstatus = [statuses[i] for i in gidx]
            n_valid = sum(1 for s in gstatus if s == 'valid')
            print(f'\n  theta={th:.0f} {gname}: {n_valid}/{len(group_phis)} valid')
            if n_valid == 0:
                symmetry_results.append({'theta': th, 'group': gname, 'action': 'no_valid', 'consistent': True})
                continue

            # 最优valid
            best_i = None; best_sll = 0
            for i in gidx:
                if statuses[i] == 'valid' and (best_i is None or results[i]['final_sll'] < best_sll):
                    best_sll = results[i]['final_sll']; best_i = i
            if best_i is None:
                for i in gidx:
                    if statuses[i] == 'valid':
                        best_i = i; best_sll = results[i]['final_sll']; break

            w_re_b, w_im_b = weights[best_i]
            w_2d_b = w_re_b.reshape(NY, NX) + 1j * w_im_b.reshape(NY, NX)
            base_phi = results[best_i]['phi0']
            print(f'    Base: idx={best_i} phi={base_phi:.0f} SLL={best_sll:.1f}dB')

            for ti in gidx:
                tp = results[ti]['phi0']
                if ti == best_i: continue
                rot_times = int(round((tp - base_phi) / 90.0)) % 4

                # 坐标验证
                coord_ok = verify_rotation(px_2d, py_2d, rot_times, (tp - base_phi))
                if not coord_ok:
                    print(f'    -> idx={ti} phi={tp:.0f}: COORD VERIFY FAILED, skip rotation')
                    continue

                w_2d_rot = rotate_weight_90(w_2d_b, rot_times)
                w_rot = w_2d_rot.ravel()
                th0 = results[ti]['theta0']; ph0 = results[ti]['phi0']
                u0 = np.sin(np.deg2rad(th0)) * np.cos(np.deg2rad(ph0))
                v0 = np.sin(np.deg2rad(th0)) * np.sin(np.deg2rad(ph0))
                w0 = np.cos(np.deg2rad(th0))
                w_rot_n = normalize_weights(w_rot, px, py, pz, u0, v0, w0)
                nd = get_null_dirs(th0, ph0)
                r_ev = eval_full_3d(w_rot_n, px, py, pz, th0, ph0, nd)
                r_me = abs(abs(np.conj(steering_vec_3d(px, py, pz, u0, v0, w0)) @ w_rot_n) - 1.0)
                r_wn = np.linalg.norm(w_rot_n); tn = results[ti]['t_norm']
                r_t, _ = check_teacher(r_ev, results[ti]['taylor_sll'], r_me, r_wn, tn)
                if r_t:
                    results[ti]['final_sll'] = float(r_ev['sll'])
                    results[ti]['improvement'] = float(r_ev['sll'] - results[ti]['taylor_sll'])
                    results[ti]['final_pt'] = float(r_ev['pointing_err'])
                    results[ti]['peak_ratio'] = float(r_ev['peak_ratio'])
                    results[ti]['worst_null'] = float(r_ev['worst_null'])
                    results[ti]['w_norm'] = float(r_wn)
                    results[ti]['norm_ratio'] = float(r_wn / (tn + 1e-30))
                    results[ti]['main_err'] = float(r_me)
                    results[ti]['status'] = 'valid'
                    results[ti]['rotation_applied'] = True
                    weights[ti] = (w_rot_n.real.copy(), w_rot_n.imag.copy())
                    statuses[ti] = 'valid'
                    print(f'    -> idx={ti} phi={tp:.0f}: rot={rot_times}*90 coord_ok SLL={r_ev["sll"]:.1f} [valid_rotated]')
                else:
                    print(f'    -> idx={ti} phi={tp:.0f}: rot={rot_times}*90 SLL={r_ev["sll"]:.1f} FAILED')

            # 一致性
            gf = [results[i] for i in gidx if statuses[i] == 'valid']
            if len(gf) >= 2:
                slls = [r['final_sll'] for r in gf]; pts = [r['final_pt'] for r in gf]
                pks = [r['peak_ratio'] for r in gf]; nrs = [r['norm_ratio'] for r in gf]
                sr = max(slls)-min(slls); pr = max(pts)-min(pts)
                pkr = max(pks)-min(pks); nrr = max(nrs)-min(nrs)
                ok = sr<=0.5 and pr<=0.2 and pkr<=2e-4 and nrr<=0.02
                sym = {'theta': th, 'group': gname, 'n_valid': len(gf),
                       'sll_range': float(sr), 'pt_range': float(pr),
                       'peak_range': float(pkr), 'norm_range': float(nrr), 'consistent': ok}
                symmetry_results.append(sym)
                if not ok:
                    symmetry_failures.append(sym)
                    print(f'    FAIL: SLL_r={sr:.2f} pt_r={pr:.3f} pk_r={pkr:.6f} nr_r={nrr:.4f}')
                else:
                    print(f'    OK: SLL_r={sr:.2f} pt_r={pr:.3f} pk_r={pkr:.6f} nr_r={nrr:.4f}')

    total_time = time.time() - t_start

    # ============================================================
    # Phase 1 汇总
    # ============================================================
    nv = sum(1 for s in statuses.values() if s == 'valid')
    nf = sum(1 for s in statuses.values() if s == 'fallback_taylor')
    nu = sum(1 for s in statuses.values() if s == 'unsupported_direction')
    nsf = sum(1 for s in statuses.values() if s == 'solver_failed')
    nrot = sum(1 for r in results.values() if r.get('rotation_applied', False))

    print(f'\n{"="*70}')
    print(f'PHASE 1 SUMMARY: {len(SCAN_DIRS)} dirs, {total_time:.1f}s')
    print(f'  Valid: {nv} (rotated: {nrot}), Fallback: {nf}, Unsupported: {nu}, Solver: {nsf}')
    print(f'  Symmetry failures: {len(symmetry_failures)}')
    print(f'{"="*70}')
    print(f'\n{"th":>4} {"ph":>5} {"T":>6} {"F":>6} {"d":>6} {"pt":>5} {"peak":>7} {"null":>6} {"norm":>5} {"rot":>4} {"status":>20}')
    print('-' * 85)
    for i in range(len(SCAN_DIRS)):
        r = results[i]
        print(f'{r["theta0"]:>4.0f} {r["phi0"]:>5.0f} {r["taylor_sll"]:>6.1f} {r["final_sll"]:>6.1f} '
              f'{r["improvement"]:>+6.1f} {r["final_pt"]:>5.2f} {r["peak_ratio"]:>7.4f} '
              f'{r["worst_null"]:>6.1f} {r["norm_ratio"]:>5.2f} {"Y" if r.get("rotation_applied") else "N":>4} {r["status"]:>20}')

    # ============================================================
    # Phase 2: 信赖域扫描(仅θ=45°/60° φ=0°)
    # ============================================================
    print(f'\n{"="*70}')
    print('PHASE 2: TRUST RADIUS SCAN (theta=45/60, phi=0)')
    print(f'{"="*70}')

    trust_results = []
    for theta0, phi0 in [(45.0, 0.0), (60.0, 0.0)]:
        null_dirs = get_null_dirs(theta0, phi0)
        print(f'\n--- theta={theta0:.0f} phi={phi0:.0f} ---')

        for trf in [0.3, 0.5, 0.8, 1.0]:
            for nrm in [1.5, 2.0] if trf == 1.0 else [1.5]:
                print(f'  trust={trf} norm={nrm}...', end=' ', flush=True)
                sol = solve_direction(px, py, pz, amp_x, amp_y, theta0, phi0, null_dirs,
                                      trust_r_factor=trf, norm_ratio=nrm)
                if sol['best_valid']:
                    bv = sol['best_valid']
                    sll = bv['sll']; ev = bv['eval']
                    st = 'valid'
                    print(f'SLL={sll:.1f} pt={ev["pointing_err"]:.2f} peak={ev["peak_ratio"]:.4f} null={ev["worst_null"]:.1f} [VALID]')
                elif sol['best_invalid']:
                    bi = sol['best_invalid']
                    sll = bi['sll']; ev = bi['eval']
                    st = 'invalid'
                    print(f'SLL={sll:.1f} pt={ev["pointing_err"]:.2f} peak={ev["peak_ratio"]:.4f} null={ev["worst_null"]:.1f} norm={bi["w_norm"]/sol["t_norm"]:.2f} [{bi["reason"]}]')
                else:
                    t_safe, _ = check_safety(sol['taylor_eval'], sol['t_main_err'], sol['t_norm'], sol['t_norm'])
                    st = 'fallback_taylor' if t_safe else 'unsupported'
                    print(f'no_solution taylor_safe={t_safe}')

                trust_results.append({
                    'theta': theta0, 'phi': phi0, 'trust': trf, 'norm': nrm,
                    'status': st,
                    'taylor_sll': float(sol['taylor_eval']['sll']),
                    'best_sll': float(sll) if sol['best_valid'] or sol['best_invalid'] else float(sol['taylor_eval']['sll']),
                    'iters': sol['n_iters'], 'peaks': sol['n_peaks'],
                })

    # ============================================================
    # 重点方向报告
    # ============================================================
    print(f'\n{"="*70}')
    print('KEY DIRECTIONS')
    print(f'{"="*70}')
    for theta0, phi0 in [(45.0, 0.0), (60.0, 0.0)]:
        idx = next(i for i, (t, p) in enumerate(SCAN_DIRS) if t == theta0 and p == phi0)
        r = results[idx]
        print(f'  theta={theta0:.0f} phi={phi0:.0f}: Taylor={r["taylor_sll"]:.1f} Final={r["final_sll"]:.1f} '
              f'd={r["improvement"]:+.1f} pt={r["final_pt"]:.2f} peak={r["peak_ratio"]:.4f} '
              f'null={r["worst_null"]:.1f} norm={r["norm_ratio"]:.2f} [{r["status"]}]')

    print(f'\nTrust radius scan summary:')
    print(f'{"theta":>6} {"trust":>6} {"norm":>5} {"status":>15} {"T_sll":>7} {"best":>7}')
    print('-' * 50)
    for tr in trust_results:
        print(f'{tr["theta"]:>6.0f} {tr["trust"]:>6.1f} {tr["norm"]:>5.1f} {tr["status"]:>15} {tr["taylor_sll"]:>7.1f} {tr["best_sll"]:>7.1f}')

    # 保存
    out_json = os.path.join(OUTPUT_DIR, 'teacher_8x8_qc_v3_1.json')
    with open(out_json, 'w') as f:
        json.dump({
            'results': list(results.values()),
            'n_valid': nv, 'n_fallback': nf, 'n_unsupported': nu, 'n_solver_failed': nsf,
            'n_rotated': nrot, 'symmetry_results': symmetry_results,
            'symmetry_failures': symmetry_failures,
            'trust_scan': trust_results,
            'total_time_s': total_time,
            'config': {'trust_radius': TRUST_RADIUS_FACTOR, 'norm_ratio': NORM_RATIO,
                       'n_iters': N_CUTTING_ITERS, 'n_eval': N_EVAL, 'refine_step': 0.25},
        }, f, indent=2, default=str)
    print(f'\nJSON: {out_json}')

    n = len(SCAN_DIRS)
    w_re = np.zeros((n, N_ELEM)); w_im = np.zeros((n, N_ELEM))
    for idx in range(n):
        w_re[idx] = weights[idx][0]; w_im[idx] = weights[idx][1]
    vm = np.array([i for i in range(n) if statuses[i] == 'valid'])
    fm = np.array([i for i in range(n) if statuses[i] == 'fallback_taylor'])
    um = np.array([i for i in range(n) if statuses[i] == 'unsupported_direction'])
    sfm = np.array([i for i in range(n) if statuses[i] == 'solver_failed'])
    rm = np.array([i for i in range(n) if results[i].get('rotation_applied', False)])

    out_npz = os.path.join(OUTPUT_DIR, 'teacher_8x8_qc_weights_v3_1.npz')
    np.savez(out_npz, w_re=w_re, w_im=w_im, px=px, py=py, pz=pz,
             valid_mask=vm, fallback_mask=fm, unsupported_mask=um,
             solver_failed_mask=sfm, rotated_mask=rm, scan_dirs=np.array(SCAN_DIRS))
    print(f'Weights: {out_npz}')
    print('=' * 70)


if __name__ == '__main__':
    main()
