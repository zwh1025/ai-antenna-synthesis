"""v4.1: 重新划分 + 补算20个random test方向

1. 按θ×5°和φ×10°组成group_id, 同组+旋转同集合
2. 1°球面保护带
3. block_val=32, block_test=32, 覆盖不同θ/φ区间和A/B
4. 补算20个random test方向
5. 输出完整JSON/NPZ/SHA256
"""

import os, sys, time, json, hashlib
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(BASE_DIR, 'mylib'))
OUTPUT_DIR = os.path.join(BASE_DIR, 'output')

N_ELEM = 64
LAMBDA_MM = 23.9834

# 导入v4教师数据
v4_npz = os.path.join(OUTPUT_DIR, 'teacher_dataset_v4.npz')
v4_json = os.path.join(OUTPUT_DIR, 'teacher_dataset_v4.json')

data = np.load(v4_npz, allow_pickle=True)
with open(v4_json) as f:
    v4 = json.load(f)

samples = v4['samples']
n_total = len(samples)

# 原始数据
w_re = data['w_re']; w_im = data['w_im']
px = data['px']; py = data['py']; pz = data['pz']
labels = data['labels']  # 1=valid
qualities = data['qualities']  # 1=A, 2=B
thetas = data['thetas']; phis = data['phis']
t_slls = data['taylor_sll']; f_slls = data['final_sll']

# ============================================================
# 1. 构建group_id
# ============================================================
def get_group_id(theta, phi):
    th_block = int(theta // 5)
    ph_block = int(phi // 10)
    return f'th{th_block:02d}_ph{ph_block:02d}'

group_ids = [get_group_id(thetas[i], phis[i]) for i in range(n_total)]
unique_groups = sorted(set(group_ids))
print(f'Total groups: {len(unique_groups)}')

# ============================================================
# 2. 按group划分, 只从valid样本中选
# ============================================================
valid_indices = [i for i in range(n_total) if labels[i] == 1]
print(f'Valid samples: {len(valid_indices)}')

# 按group聚合valid样本
from collections import defaultdict
group_valid = defaultdict(list)
for i in valid_indices:
    group_valid[group_ids[i]].append(i)

# 选block_val和block_test: 覆盖不同θ/φ区间, 包含A和B
rng = np.random.RandomState(999)
available_groups = [g for g in sorted(group_valid.keys())]
rng.shuffle(available_groups)

# 目标: val=32, test=32, 覆盖不同区间
block_val = []
block_test = []
val_groups = []
test_groups = []
used_groups = set()

# 交替分配group到val和test, 确保覆盖
for g in available_groups:
    if len(block_val) >= 32 and len(block_test) >= 32:
        break
    if g in used_groups:
        continue
    candidates = group_valid[g]
    if len(candidates) == 0:
        continue

    # 检查该group是否有A和B
    has_a = any(qualities[i] == 1 for i in candidates)
    has_b = any(qualities[i] == 2 for i in candidates)

    # 交替分配
    if len(block_val) < 32:
        # 取该group中最多2个样本
        take = min(2, len(candidates), 32 - len(block_val))
        selected = candidates[:take]
        block_val.extend(selected)
        val_groups.append(g)
        used_groups.add(g)
    elif len(block_test) < 32:
        take = min(2, len(candidates), 32 - len(block_test))
        selected = candidates[:take]
        block_test.extend(selected)
        test_groups.append(g)
        used_groups.add(g)

print(f'Block val: {len(block_val)} samples, {len(val_groups)} groups')
print(f'Block test: {len(block_test)} samples, {len(test_groups)} groups')

# ============================================================
# 3. 1°球面保护带
# ============================================================
def angular_dist_deg(th1, ph1, th2, ph2):
    t1, p1 = np.deg2rad(th1), np.deg2rad(ph1)
    t2, p2 = np.deg2rad(th2), np.deg2rad(ph2)
    cos_d = np.cos(t1)*np.cos(t2) + np.sin(t1)*np.sin(t2)*np.cos(p1-p2)
    return np.rad2deg(np.arccos(np.clip(cos_d, -1, 1)))

guard_indices = []
test_val_set = set(block_val + block_test)

for i in valid_indices:
    if i in test_val_set:
        continue
    th_i = thetas[i]; ph_i = phis[i]
    too_close = False
    for j in block_val + block_test:
        d = angular_dist_deg(th_i, ph_i, thetas[j], phis[j])
        if d <= 1.0:
            too_close = True; break
    if too_close:
        guard_indices.append(i)

guard_set = set(guard_indices)
train_indices = [i for i in valid_indices if i not in test_val_set and i not in guard_set]

print(f'Guard/excluded: {len(guard_indices)}')
print(f'Train: {len(train_indices)}')

# 统计Quality A/B
train_a = sum(1 for i in train_indices if qualities[i] == 1)
train_b = sum(1 for i in train_indices if qualities[i] == 2)
val_a = sum(1 for i in block_val if qualities[i] == 1)
val_b = sum(1 for i in block_val if qualities[i] == 2)
test_a = sum(1 for i in block_test if qualities[i] == 1)
test_b = sum(1 for i in block_test if qualities[i] == 2)

print(f'  Train: {len(train_indices)} (A={train_a}, B={train_b})')
print(f'  Val: {len(block_val)} (A={val_a}, B={val_b})')
print(f'  Test: {len(block_test)} (A={test_a}, B={test_b})')

# θ分布
def theta_dist(indices):
    ths = [thetas[i] for i in indices]
    ranges = {}
    for th in ths:
        b = int(th // 10) * 10
        ranges[b] = ranges.get(b, 0) + 1
    return ranges

print(f'\nTheta distribution:')
print(f'  Train: {theta_dist(train_indices)}')
print(f'  Val: {theta_dist(block_val)}')
print(f'  Test: {theta_dist(block_test)}')

# 每个val/test到最近train的距离
def nearest_train_dist(indices, train_idx):
    results = []
    for i in indices:
        min_d = 999
        for j in train_idx:
            d = angular_dist_deg(thetas[i], phis[i], thetas[j], phis[j])
            if d < min_d: min_d = d
        results.append(min_d)
    return results

val_dists = nearest_train_dist(block_val, train_indices)
test_dists = nearest_train_dist(block_test, train_indices)

print(f'\nVal nearest train distance: min={min(val_dists):.2f} med={np.median(val_dists):.2f} max={max(val_dists):.2f}')
print(f'Test nearest train distance: min={min(test_dists):.2f} med={np.median(test_dists):.2f} max={max(test_dists):.2f}')

# ============================================================
# 4. 保存划分
# ============================================================
# split数组: 0=train, 1=val, 2=test, 3=guard, -1=invalid
split_arr = np.full(n_total, -1, dtype=np.int32)
for i in train_indices: split_arr[i] = 0
for i in block_val: split_arr[i] = 1
for i in block_test: split_arr[i] = 2
for i in guard_indices: split_arr[i] = 3

# JSON
split_info = {
    'n_total': n_total,
    'n_valid': len(valid_indices),
    'splits': {
        'train': {'n': len(train_indices), 'A': train_a, 'B': train_b,
                  'theta_dist': theta_dist(train_indices),
                  'indices': train_indices},
        'block_val': {'n': len(block_val), 'A': val_a, 'B': val_b,
                      'theta_dist': theta_dist(block_val),
                      'indices': block_val,
                      'nearest_train_dist': {
                          'min': float(min(val_dists)),
                          'median': float(np.median(val_dists)),
                          'max': float(max(val_dists)),
                          'all': [float(d) for d in val_dists],
                      }},
        'block_test': {'n': len(block_test), 'A': test_a, 'B': test_b,
                       'theta_dist': theta_dist(block_test),
                       'indices': block_test,
                       'nearest_train_dist': {
                           'min': float(min(test_dists)),
                           'median': float(np.median(test_dists)),
                           'max': float(max(test_dists)),
                           'all': [float(d) for d in test_dists],
                       }},
        'guard': {'n': len(guard_indices), 'indices': guard_indices},
    },
    'group_ids': group_ids,
    'val_groups': val_groups,
    'test_groups': test_groups,
}

# 每个样本的group_id
sample_info = []
for i in range(n_total):
    sample_info.append({
        'idx': i,
        'theta0': float(thetas[i]),
        'phi0': float(phis[i]),
        'group_id': group_ids[i],
        'split': int(split_arr[i]),
        'label': 'valid' if labels[i] == 1 else ('degraded' if t_slls[i] > -15 else 'other'),
        'quality': 'A' if qualities[i] == 1 else ('B' if qualities[i] == 2 else ''),
        'taylor_sll': float(t_slls[i]),
        'final_sll': float(f_slls[i]),
    })

split_info['samples'] = sample_info

out_json = os.path.join(OUTPUT_DIR, 'split_v4_1.json')
with open(out_json, 'w') as f:
    json.dump(split_info, f, indent=2, default=str)
print(f'\nJSON: {out_json}')

# NPZ
out_npz = os.path.join(OUTPUT_DIR, 'split_v4_1.npz')
np.savez(out_npz,
         w_re=w_re, w_im=w_im,
         px=px, py=py, pz=pz,
         labels=labels, qualities=qualities,
         thetas=thetas, phis=phis,
         taylor_sll=t_slls, final_sll=f_slls,
         split=split_arr,
         group_ids=np.array(group_ids),
         train_idx=np.array(train_indices),
         val_idx=np.array(block_val),
         test_idx=np.array(block_test),
         guard_idx=np.array(guard_indices),
         )

with open(out_npz, 'rb') as f:
    npz_sha = hashlib.sha256(f.read()).hexdigest()
print(f'NPZ: {out_npz}')
print(f'NPZ SHA-256: {npz_sha}')

with open(out_json, 'rb') as f:
    json_sha = hashlib.sha256(f.read()).hexdigest()
print(f'JSON SHA-256: {json_sha}')

# ============================================================
# 5. 补算20个random test方向
# ============================================================
print(f'\n{"="*70}')
print('Random Test Directions (20)')
print(f'{"="*70}')

# 用v4已有的random_test_dirs
random_dirs = v4.get('splits', {}).get('random_test_dirs', [])
if len(random_dirs) < 20:
    rng2 = np.random.RandomState(42)
    while len(random_dirs) < 20:
        th = rng2.uniform(0, 55)
        ph = rng2.uniform(0, 45)
        random_dirs.append((float(th), float(ph)))

# 导入求解函数(复用v4脚本)
sys.path.insert(0, BASE_DIR)
from run_teacher_v4 import (
    solve_dir, get_null_dirs, check_safety, check_teacher, check_quality_A,
    eval_full, steering_vec, taylor_2d, N_COARSE, N_CUTTING_ITERS,
    TRUST_RADIUS_FACTOR, NORM_RATIO, EPS_NULL, EPS_NULL_CHECK_DB, NX, SLL_DESIGN,
)

ax2, ay2 = taylor_2d(NX, NX, SLL_DESIGN)
random_results = []
random_weights = []

for i, (th, ph) in enumerate(random_dirs[:20]):
    sol = solve_dir(px, py, pz, ax2, ay2, th, ph)
    nd = get_null_dirs(th, ph)

    if sol['bv']:
        bv = sol['bv']
        w_final = bv['w']; ev = bv['ev']
        me = bv['me']; wn = bv['wn']
        label = 'valid'
        qa = check_quality_A(ev, sol['te']['sll'], me, wn, sol['tn'])
        quality = 'A' if qa else 'B'
    else:
        t_safe, _ = check_safety(sol['te'], sol['tme'], sol['tn'], sol['tn'])
        if t_safe:
            w_final = sol['wtn']; ev = sol['te']
            me = sol['tme']; wn = sol['tn']
            if sol['te']['sll'] > -15:
                label = 'degraded'; quality = ''
            else:
                label = 'fallback_taylor'; quality = ''
        else:
            w_final = sol['wtn']; ev = sol['te']
            me = sol['tme']; wn = sol['tn']
            label = 'unsupported'; quality = ''

    imp = ev['sll'] - sol['te']['sll']
    nr = wn / (sol['tn'] + 1e-30)
    u0 = np.sin(np.deg2rad(th))*np.cos(np.deg2rad(ph))
    v0 = np.sin(np.deg2rad(th))*np.sin(np.deg2rad(ph))
    w0 = np.cos(np.deg2rad(th))

    r = {
        'idx': i, 'theta0': float(th), 'phi0': float(ph),
        'label': label, 'quality': quality,
        'taylor_sll': float(sol['te']['sll']),
        'final_sll': float(ev['sll']),
        'improvement': float(imp),
        'pt': float(ev['pt']), 'peak': float(ev['pr']),
        'worst_null': float(ev['wn']),
        'null_depths': ev['nulls'],
        'w_norm': float(wn), 't_norm': float(sol['tn']),
        'norm_ratio': float(nr), 'main_err': float(me),
        'n_iters': sol['ni'],
        'u0': float(u0), 'v0': float(v0), 'w0': float(w0),
    }
    random_results.append(r)
    random_weights.append((w_final.real.copy(), w_final.imag.copy()))

    print(f'  [{i+1}/20] th={th:.1f} ph={ph:.1f}: T={sol["te"]["sll"]:.1f} '
          f'F={ev["sll"]:.1f} d={imp:+.1f} pt={ev["pt"]:.2f} '
          f'peak={ev["pr"]:.4f} null={ev["wn"]:.1f} [{label}/{quality}]')

# 保存random test
rt_json = os.path.join(OUTPUT_DIR, 'random_test_v4_1.json')
with open(rt_json, 'w') as f:
    json.dump({'results': random_results}, f, indent=2, default=str)

rt_npz = os.path.join(OUTPUT_DIR, 'random_test_v4_1.npz')
rw_re = np.array([w[0] for w in random_weights])
rw_im = np.array([w[1] for w in random_weights])
np.savez(rt_npz, w_re=rw_re, w_im=rw_im, px=px, py=py, pz=pz,
         thetas=np.array([r['theta0'] for r in random_results]),
         phis=np.array([r['phi0'] for r in random_results]),
         labels=np.array([1 if r['label']=='valid' else 0 for r in random_results]))

with open(rt_json, 'rb') as f:
    rt_json_sha = hashlib.sha256(f.read()).hexdigest()
with open(rt_npz, 'rb') as f:
    rt_npz_sha = hashlib.sha256(f.read()).hexdigest()

print(f'\nRandom test JSON: {rt_json} (SHA: {rt_json_sha})')
print(f'Random test NPZ: {rt_npz} (SHA: {rt_npz_sha})')

# 汇总
n_rt_valid = sum(1 for r in random_results if r['label'] == 'valid')
n_rt_qa = sum(1 for r in random_results if r.get('quality') == 'A')
print(f'\nRandom test: {n_rt_valid} valid, {n_rt_qa} quality_A')

print(f'\n{"="*70}')
print('SHA-256 SUMMARY')
print(f'{"="*70}')
print(f'split_v4_1.json:    {json_sha}')
print(f'split_v4_1.npz:     {npz_sha}')
print(f'random_test_v4_1.json: {rt_json_sha}')
print(f'random_test_v4_1.npz:  {rt_npz_sha}')
print(f'{"="*70}')
