"""D4 Canonical包装器修复 v2

修复:
  1. fold_to_canonical: 用INVERSE_TID + transform_phi逆变换
  2. 权值恢复: w_target = w_canonical[perms[tid]] (不用inv_perm)
  3. 包装器单元测试: phi=0-359.75 step 0.25
  4. D4扩展评估: 每个Canonical×8个真实方向
  5. 加强D4测试: SLL/pt/peak/null/norm不变量
  6. 支持域门控说明
"""

import os, sys, time, json, hashlib, math
import numpy as np
import torch
import torch.nn as nn

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(BASE_DIR, 'mylib'))
OUTPUT_DIR = os.path.join(BASE_DIR, 'output')

N_ELEM = 64
NX = NY = 8
WEIGHT_SCALE = 64.0

D4_TRANSFORMS = [
    (0, 'identity'), (1, 'rot90'), (2, 'rot180'), (3, 'rot270'),
    (4, 'mirror_x'), (5, 'mirror_y'), (6, 'mirror_diag'), (7, 'mirror_anti'),
]

INVERSE_TID = {0:0, 1:3, 2:2, 3:1, 4:4, 5:5, 6:6, 7:7}


def load_coords():
    import csv
    csv_path = os.path.join(BASE_DIR, 'element_port_map.csv')
    coords = []
    with open(csv_path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            coords.append((
                float(row['x_mm']) / 23.9834,
                float(row['y_mm']) / 23.9834,
                float(row['z_mm']) / 23.9834,
            ))
    return np.array(coords)


def apply_d4_transform(x, y, z, tid):
    if tid == 0: return x, y, z
    elif tid == 1: return y, -x, z
    elif tid == 2: return -x, -y, z
    elif tid == 3: return -y, x, z
    elif tid == 4: return -x, y, z
    elif tid == 5: return x, -y, z
    elif tid == 6: return y, x, z
    elif tid == 7: return -y, -x, z
    return x, y, z


def build_permutation(coords, tid):
    n = len(coords)
    px = coords[:, 0]; py = coords[:, 1]; pz = coords[:, 2]
    perm = np.zeros(n, dtype=np.int32)
    for i in range(n):
        tx, ty, tz = apply_d4_transform(px[i], py[i], pz[i], tid)
        best_j = 0; best_d = 1e10
        for j in range(n):
            d = (px[j]-tx)**2 + (py[j]-ty)**2 + (pz[j]-tz)**2
            if d < best_d: best_d = d; best_j = j
        perm[i] = best_j
    return perm


def transform_phi(phi, tid):
    """正向变换: canonical phi -> target phi。"""
    if tid == 0: return phi % 360
    elif tid == 1: return (phi + 90) % 360
    elif tid == 2: return (phi + 180) % 360
    elif tid == 3: return (phi + 270) % 360
    elif tid == 4: return (180 - phi) % 360
    elif tid == 5: return (360 - phi) % 360
    elif tid == 6: return (90 - phi) % 360
    elif tid == 7: return (270 - phi) % 360
    return phi % 360


def angular_phi_error(p1, p2):
    d = abs(p1 % 360 - p2 % 360)
    return min(d, 360 - d)


def fold_to_canonical(phi_target):
    """目标phi -> canonical phi + tid。用INVERSE_TID逆变换。"""
    phi_target = phi_target % 360
    for tid in range(8):
        inv_tid = INVERSE_TID[tid]
        phi_c = transform_phi(phi_target, inv_tid) % 360
        if 0 <= phi_c <= 45 + 1e-10:
            phi_restore = transform_phi(phi_c, tid) % 360
            if angular_phi_error(phi_restore, phi_target) < 1e-10:
                return phi_c, tid
    raise RuntimeError(f"No valid D4 canonical mapping for phi={phi_target}")


# ============================================================
# 物理函数
# ============================================================
def steering_vec(px, py, pz, u, v, w):
    k = 2 * np.pi
    return np.exp(1j * k * (px * u + py * v + pz * w))

def normalize_mainlobe(w, px, py, pz, u0, v0, w0):
    a = steering_vec(px, py, pz, u0, v0, w0)
    resp = np.conj(a) @ w
    if np.abs(resp) < 1e-12: return w
    return w / resp

def angular_dist_deg(th1, ph1, th2, ph2):
    t1, p1 = np.deg2rad(th1), np.deg2rad(ph1)
    t2, p2 = np.deg2rad(th2), np.deg2rad(ph2)
    cos_d = np.cos(t1)*np.cos(t2) + np.sin(t1)*np.sin(t2)*np.cos(p1-p2)
    return float(np.rad2deg(np.arccos(np.clip(cos_d, -1, 1))))

def get_null_dirs(theta0, phi0):
    if theta0 < 10:
        return [(30, 0), (30, 90), (30, 180), (30, 270)]
    return [
        (theta0, (phi0 + 90) % 360),
        (theta0, (phi0 + 180) % 360),
        (theta0, (phi0 + 270) % 360),
        (min(theta0 + 25, 85), (phi0 + 45) % 360),
    ]


def eval_full_81(w, px, py, pz, th0, ph0, null_dirs):
    k = 2 * np.pi
    u0 = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph0))
    v0 = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph0))
    w0 = np.cos(np.deg2rad(th0))
    n_eval = 81
    u = np.linspace(-1, 1, n_eval); v = np.linspace(-1, 1, n_eval)
    ug, vg = np.meshgrid(u, v, indexing='ij')
    vis = (ug**2 + vg**2) <= 1.0; wg = np.sqrt(np.maximum(1-ug**2-vg**2, 0))
    bw = 0.886 * 2.0 / NX * 180 / np.pi
    exc = np.sin(np.deg2rad(3.0 * bw / max(np.cos(np.deg2rad(th0)), 0.1)))
    dist = np.sqrt((ug-u0)**2 + (vg-v0)**2)
    sl_mask = (dist >= exc) & vis
    vf = vis.ravel(); uf = ug.ravel(); vf2 = vg.ravel(); wf = wg.ravel()
    pat = np.zeros(len(uf))
    for i in range(len(uf)):
        if vf[i]:
            psi = k * (px*uf[i] + py*vf2[i] + pz*wf[i])
            pat[i] = np.abs(np.sum(np.conj(w) * np.exp(1j * psi)))
    psi_m = k * (px*u0 + py*v0 + pz*w0)
    mr = np.abs(np.sum(np.conj(w) * np.exp(1j * psi_m)))
    pi2 = np.argmax(pat)
    pval = pat[pi2]
    pu = uf[pi2]; pv = vf2[pi2]; pw = wf[pi2]
    pt_c = np.degrees(np.arcsin(np.clip(np.sqrt(pu**2+pv**2), 0, 1)))
    pp_c = np.degrees(np.arctan2(pv, pu)) % 360
    for rt in np.arange(max(0, pt_c-2.0), min(90, pt_c+2.0)+0.25, 0.25):
        for rpw in np.arange(pp_c-2.0, pp_c+2.0+0.25, 0.25):
            rp = rpw % 360.0
            ru = np.sin(np.deg2rad(rt))*np.cos(np.deg2rad(rp))
            rv = np.sin(np.deg2rad(rt))*np.sin(np.deg2rad(rp))
            rw = np.cos(np.deg2rad(rt))
            if ru**2+rv**2 > 1.0: continue
            vr = np.abs(np.sum(np.conj(w)*np.exp(1j*k*(px*ru+py*rv+pz*rw))))
            if vr > pval: pval=vr; pu=ru; pv=rv; pw=rw
    pr = pval / (mr + 1e-30)
    pth = np.degrees(np.arcsin(np.clip(np.sqrt(pu**2+pv**2), 0, 1)))
    pph = np.degrees(np.arctan2(pv, pu)) % 360
    pte = angular_dist_deg(pth, pph, th0, ph0)
    sf = sl_mask.ravel(); ps = pat[sf]
    sll = 20*np.log10(np.max(ps)/(mr+1e-30)) if mr > 1e-10 else -300
    nulls = []
    for tn, pn in null_dirs:
        un = np.sin(np.deg2rad(tn))*np.cos(np.deg2rad(pn))
        vn = np.sin(np.deg2rad(tn))*np.sin(np.deg2rad(pn))
        wn = np.cos(np.deg2rad(tn))
        nd = 20*np.log10(np.abs(np.sum(np.conj(w)*np.exp(1j*k*(px*un+py*vn+pz*wn))))/(mr+1e-30))
        nulls.append(float(nd))
    return {'sll': float(sll), 'pt': float(pte), 'pr': float(pr),
            'mr': float(mr), 'wn': float(max(nulls)), 'nulls': nulls}


def taylor_2d(Nx, Ny, SLL):
    posx = (np.arange(1, Nx + 1) - (Nx / 2 + 0.5)) * 0.5
    posy = (np.arange(1, Ny + 1) - (Ny / 2 + 0.5)) * 0.5
    def taylor_1d(N, pos, RdB):
        R0 = 10 ** (RdB / 20)
        A = np.arccosh(R0) / np.pi
        n_bar = max(int(np.ceil(2 * A ** 2 + 0.5)), 2)
        m = np.arange(1, n_bar).reshape(-1, 1)
        n = np.arange(1, n_bar).reshape(1, -1)
        def fact(x):
            return np.array([math.factorial(int(v)) for v in np.asarray(x).ravel()]).reshape(np.asarray(x).shape)
        sigma = n_bar / (A ** 2 + (n_bar - 0.5) ** 2) ** 0.5
        Sm1 = (fact(n_bar - 1) ** 2) / fact(n_bar + m - 1) / fact(n_bar - m - 1)
        Sm2 = np.prod(1 - (m ** 2 / sigma ** 2 / (A ** 2 + (n - 0.5) ** 2)), axis=1).reshape(-1, 1)
        Sm = Sm1 * Sm2
        pos = np.asarray(pos).reshape(1, -1)
        exc = 1 + 2 * np.sum(Sm * np.cos(m * pos * 2 * np.pi / (N * 0.5)), axis=0)
        exc = exc / np.max(exc)
        return exc.ravel()
    ax = taylor_1d(Nx, posx, SLL)
    ay = taylor_1d(Ny, posy, SLL)
    return ax, ay


# ============================================================
# DeepSets模型
# ============================================================
class DeepSetsV2(nn.Module):
    def __init__(self, input_dim=9, hidden_dim=256, output_dim=2):
        super().__init__()
        self.phi = nn.Sequential(
            nn.Linear(input_dim, hidden_dim), nn.LayerNorm(hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim), nn.LayerNorm(hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim), nn.LayerNorm(hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.rho = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim), nn.LayerNorm(hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.output_net = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim), nn.LayerNorm(hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, output_dim),
        )

    def forward(self, x):
        h = self.phi(x)
        mean_p = h.mean(dim=1)
        max_p = h.max(dim=1)[0]
        pooled = torch.cat([mean_p, max_p], dim=-1)
        g = self.rho(pooled)
        g_exp = g.unsqueeze(1).expand(-1, h.size(1), -1)
        combined = torch.cat([h, g_exp], dim=-1)
        return self.output_net(combined)


# ============================================================
# Canonical包装器 (v2修复版)
# ============================================================
class CanonicalWrapper:
    """D4 Canonical推理包装器。

    工作流:
      1. fold_to_canonical(phi_target) -> (phi_canonical, tid)
      2. 在canonical方向计算Taylor基线
      3. DeepSets推理得到canonical方向的AI残差
      4. w_target = w_canonical[perms[tid]]  (直接正向置换, 不用inv_perm)
      5. 在目标方向归一化主瓣

    支持域门控:
      - 调用方必须传入support_label
      - 实际推理时support_label来自支持域查找表
      - 不得描述为模型自主拒识
    """

    def __init__(self, model, coords, perms, mean_stats, std_stats):
        self.model = model
        self.coords = coords
        self.perms = perms
        self.px = coords[:, 0]; self.py = coords[:, 1]; self.pz = coords[:, 2]
        self.mean_stats = mean_stats
        self.std_stats = std_stats
        self.ax, self.ay = taylor_2d(NX, NY, 30)

    def compute_taylor(self, th0, ph0):
        k = 2 * np.pi
        u0 = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph0))
        v0 = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph0))
        w0 = np.cos(np.deg2rad(th0))
        wt = np.outer(self.ay, self.ax).ravel() * np.exp(1j * k*(self.px*u0 + self.py*v0 + self.pz*w0))
        return normalize_mainlobe(wt, self.px, self.py, self.pz, u0, v0, w0)

    def predict(self, th0, ph0, support_label='valid'):
        """带支持域门控的推理。

        Args:
            support_label: 'valid'/'fallback_taylor'/'degraded'/'unsupported'
                          测试时使用已知真值标签; 实际推理时来自支持域查找表。

        Returns:
            (w_final, mode, canon_ph, tid)
        """
        if support_label in ('degraded', 'unsupported'):
            wt = self.compute_taylor(th0, ph0)
            return wt, 'rejected', 0.0, 0

        if support_label == 'fallback_taylor':
            wt = self.compute_taylor(th0, ph0)
            return wt, 'taylor', 0.0, 0

        # valid: Canonical推理
        canon_ph, tid = fold_to_canonical(ph0)

        # Taylor在canonical方向
        wt_canon = self.compute_taylor(th0, canon_ph)

        # 构建输入特征
        u0c = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(canon_ph))
        v0c = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(canon_ph))
        w0c = np.cos(np.deg2rad(th0))

        px_n = (self.px - self.mean_stats['px_mean']) / (self.std_stats['px_std'] + 1e-8)
        py_n = (self.py - self.mean_stats['py_mean']) / (self.std_stats['py_std'] + 1e-8)
        pz_n = (self.pz - self.mean_stats['pz_mean']) / (self.std_stats['pz_std'] + 1e-8)

        feat = np.stack([
            px_n, py_n, pz_n,
            wt_canon.real * WEIGHT_SCALE, wt_canon.imag * WEIGHT_SCALE,
            np.full(N_ELEM, u0c), np.full(N_ELEM, v0c),
            np.full(N_ELEM, w0c), np.full(N_ELEM, 0.6, dtype=np.float32),
        ], axis=-1).astype(np.float32)

        x = torch.as_tensor(feat[None], dtype=torch.float32)
        with torch.no_grad():
            delta = self.model(x)[0].numpy()

        # AI权值在canonical方向
        w_ai_canon = (wt_canon.real + delta[:, 0] / WEIGHT_SCALE) + \
                     1j * (wt_canon.imag + delta[:, 1] / WEIGHT_SCALE)
        w_ai_canon = normalize_mainlobe(w_ai_canon, self.px, self.py, self.pz, u0c, v0c, w0c)

        # 权值恢复: w_target = w_canonical[perms[tid]]
        # perms[tid][i] = j: 变换后位置i对应原始阵元j
        # 所以 w_target[i] = w_canonical[j] = w_canonical[perms[tid][i]]
        w_ai_target = w_ai_canon[self.perms[tid]]

        # 在目标方向归一化
        u0 = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph0))
        v0 = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph0))
        w0 = np.cos(np.deg2rad(th0))
        w_ai_target = normalize_mainlobe(w_ai_target, self.px, self.py, self.pz, u0, v0, w0)

        return w_ai_target, 'ai', float(canon_ph), int(tid)


# ============================================================
# 包装器单元测试
# ============================================================
def test_wrapper_360(wrapper):
    """phi=0-359.75 step 0.25 全360°包装器测试。"""
    print('\n' + '='*70)
    print('WRAPPER 360° TEST (phi=0-359.75 step 0.25)')
    print('='*70)

    px = wrapper.px; py = wrapper.py; pz = wrapper.pz
    tid_seen = set()
    n_pass = 0; n_fail = 0
    failures = []

    for phi_x10 in range(0, 3600, 25):  # 0.25度步长
        ph0 = phi_x10 / 10.0
        th0 = 30.0

        # 1. fold_to_canonical
        try:
            canon_ph, tid = fold_to_canonical(ph0)
        except RuntimeError:
            failures.append((th0, ph0, 'NO_CANONICAL_MAPPING'))
            n_fail += 1
            continue

        # 2. canonical范围
        if not (0 <= canon_ph <= 45.0001):
            failures.append((th0, ph0, f'CANON_PH={canon_ph}'))
            n_fail += 1
            continue

        # 3. 恢复检查
        ph_restore = transform_phi(canon_ph, tid) % 360
        if angular_phi_error(ph_restore, ph0) >= 1e-10:
            failures.append((th0, ph0, f'RESTORE_ERR={angular_phi_error(ph_restore, ph0):.2e}'))
            n_fail += 1
            continue

        tid_seen.add(tid)

        # 4. 主瓣指向
        wt_canon = wrapper.compute_taylor(th0, canon_ph)
        w_target = wt_canon[wrapper.perms[tid]]

        u0 = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph0))
        v0 = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph0))
        w0 = np.cos(np.deg2rad(th0))
        w_target_n = normalize_mainlobe(w_target, px, py, pz, u0, v0, w0)

        # 5. main response (归一化后应=1)
        mr = abs(np.conj(steering_vec(px,py,pz,u0,v0,w0)) @ w_target_n)
        main_err = abs(mr - 1.0)
        if main_err > 1e-10:
            failures.append((th0, ph0, f'MAIN_ERR={main_err:.2e}'))
            n_fail += 1
            continue

        n_pass += 1

    # 检查8个tid都出现
    missing_tids = set(range(8)) - tid_seen

    print(f'  Total: {n_pass + n_fail}, Pass: {n_pass}, Fail: {n_fail}')
    print(f'  TIDs seen: {sorted(tid_seen)}')
    print(f'  Missing TIDs: {sorted(missing_tids) if missing_tids else "NONE"}')

    if failures:
        print(f'  Failures (first 10):')
        for th, ph, reason in failures[:10]:
            print(f'    th={th} ph={ph}: {reason}')

    all_pass = (n_fail == 0 and len(missing_tids) == 0)
    print(f'  Result: {"ALL PASS" if all_pass else "FAILED"}')
    return all_pass


def test_wrapper_specific(wrapper):
    """特定phi值测试。"""
    print('\n--- Specific phi test ---')
    test_phis = [0, 30, 45, 60, 89, 90, 120, 135, 150, 179,
                 180, 225, 270, 315, 330, 359]

    for ph0 in test_phis:
        th0 = 30.0
        canon_ph, tid = fold_to_canonical(float(ph0))
        ph_restore = transform_phi(canon_ph, tid) % 360
        err = angular_phi_error(ph_restore, ph0)

        wt_canon = wrapper.compute_taylor(th0, canon_ph)
        w_target = wt_canon[wrapper.perms[tid]]
        u0 = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph0))
        v0 = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph0))
        w0 = np.cos(np.deg2rad(th0))
        w_target_n = normalize_mainlobe(w_target, wrapper.px, wrapper.py, wrapper.pz, u0, v0, w0)
        mr = abs(np.conj(steering_vec(wrapper.px, wrapper.py, wrapper.pz, u0, v0, w0)) @ w_target_n)
        main_err = abs(mr - 1.0)

        print(f'  phi={ph0:>3}: canon={canon_ph:.1f} tid={tid} restore={ph_restore:.1f} '
              f'err={err:.1e} main_err={main_err:.2e} {"OK" if err < 1e-10 and main_err < 1e-10 else "FAIL"}')


# ============================================================
# 加强D4不变量测试 (多theta/phi + SOCP权值)
# ============================================================
def test_d4_invariants(coords, perms, wrapper):
    """在多组theta/phi和SOCP教师权值上测试D4不变量。"""
    print('\n' + '='*70)
    print('D4 INVARIANT TESTS (multi-direction, SOCP weights)')
    print('='*70)

    px = coords[:, 0]; py = coords[:, 1]; pz = coords[:, 2]

    # 加载教师权值
    npz = np.load(os.path.join(OUTPUT_DIR, 'split_v4_2.npz'), allow_pickle=True)
    labels = npz['labels']; thetas = npz['thetas']; phis = npz['phis']
    w_re = npz['w_re']; w_im = npz['w_im']
    t_sll = npz['taylor_sll']

    # 选5个valid样本
    valid_idx = [i for i in range(len(labels)) if labels[i] == 1][:5]

    all_pass = True
    for idx in valid_idx:
        th0 = float(thetas[idx]); ph0 = float(phis[idx])
        w_socp = w_re[idx] + 1j * w_im[idx]
        print(f'  Testing idx={idx} th={th0} ph={ph0} w_norm={np.linalg.norm(w_socp):.6f}')
        wt = wrapper.compute_taylor(th0, ph0)
        w_socp_n = normalize_mainlobe(w_socp, px, py, pz,
                                       np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph0)),
                                       np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph0)),
                                       np.cos(np.deg2rad(th0)))
        nd_orig = get_null_dirs(th0, ph0)
        ev_orig = eval_full_81(w_socp_n, px, py, pz, th0, ph0, nd_orig)
        w_norm = np.linalg.norm(w_socp_n)
        t_norm = np.linalg.norm(wt)

        for tid, name in D4_TRANSFORMS[1:]:
            ph_t = transform_phi(ph0, tid) % 360
            w_perm = w_socp_n[perms[tid]]
            u0t = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph_t))
            v0t = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph_t))
            w0t = np.cos(np.deg2rad(th0))
            w_perm_n = normalize_mainlobe(w_perm, px, py, pz, u0t, v0t, w0t)
            nd_t = get_null_dirs(th0, ph_t)
            ev_t = eval_full_81(w_perm_n, px, py, pz, th0, ph_t, nd_t)
            if idx == valid_idx[0] and tid == 1:
                print(f'    DEBUG ev_t: sll={ev_t["sll"]:.2f} pt={ev_t["pt"]:.4f} '
                      f'peak={ev_t["pr"]:.6f} mr={ev_t["mr"]:.6f} '
                      f'wn={ev_t["wn"]:.2f} norm={np.linalg.norm(w_perm_n):.6f}')
                print(f'    DEBUG ev_orig: sll={ev_orig["sll"]:.2f} pt={ev_orig["pt"]:.4f}')

            # 不变量检查: 零陷比较排序后的集合(因为D4变换后零陷顺序变化)
            sll_diff = abs(ev_orig['sll'] - ev_t['sll'])
            pt_diff = abs(ev_orig['pt'] - ev_t['pt'])
            peak_diff = abs(ev_orig['pr'] - ev_t['pr'])
            null_orig_sorted = sorted(ev_orig['nulls'])
            null_perm_sorted = sorted(ev_t['nulls'])
            null_diffs = [abs(a - b) for a, b in zip(null_orig_sorted, null_perm_sorted)]
            norm_diff = abs(np.linalg.norm(w_perm_n) - w_norm)

            ok = (sll_diff < 0.1 and pt_diff < 0.01 and peak_diff < 1e-6 and
                  max(null_diffs) < 0.1 and norm_diff < 1e-10)

            if not ok:
                print(f'  th={th0} ph={ph0} {name}: FAIL sll_diff={sll_diff:.3f} pt_diff={pt_diff:.4f} '
                      f'peak_diff={peak_diff:.2e} null_max={max(null_diffs):.3f} norm_diff={norm_diff:.2e}')
                if max(null_diffs) >= 0.1:
                    print(f'    null_orig={[f"{x:.2f}" for x in ev_orig["nulls"]]}')
                    print(f'    null_perm={[f"{x:.2f}" for x in ev_t["nulls"]]}')
                    print(f'    null_diffs={[f"{x:.3f}" for x in null_diffs]}')
                all_pass = False

    if all_pass:
        print(f'  All {len(valid_idx)} samples × 7 transforms = {len(valid_idx)*7} tests: ALL PASS')
    return all_pass


# ============================================================
# D4扩展评估 (每个Canonical×8方向)
# ============================================================
def evaluate_d4_expanded(wrapper, thetas, phis, t_slls, support_labels,
                          px, py, pz, parent_ids=None):
    """对每个Canonical方向生成8个真实目标方向, 全部调用包装器。"""
    all_results = []

    for i in range(len(thetas)):
        th0 = float(thetas[i]); ph0 = float(phis[i])
        sl = support_labels[i] if i < len(support_labels) else 'valid'
        t_sll = float(t_slls[i])

        for tid in range(8):
            ph_target = transform_phi(ph0, tid) % 360

            w_ai, mode, canon_ph, used_tid = wrapper.predict(th0, ph_target, sl)

            wt = wrapper.compute_taylor(th0, ph_target)
            nd = get_null_dirs(th0, ph_target)

            u0 = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph_target))
            v0 = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph_target))
            w0 = np.cos(np.deg2rad(th0))

            ev_ai = eval_full_81(w_ai, px, py, pz, th0, ph_target, nd)

            # Taylor SLL在目标方向
            ev_taylor = eval_full_81(wt, px, py, pz, th0, ph_target, nd)
            t_sll_target = float(ev_taylor['sll'])

            ai_pass = (ev_ai['pt'] <= 1.0 and ev_ai['pr'] <= 1.001 and
                       ev_ai['wn'] <= -28.0 and ev_ai['sll'] - t_sll_target <= -0.5 and
                       np.linalg.norm(w_ai) / (np.linalg.norm(wt) + 1e-30) <= 1.5)

            # alpha回退
            alpha_best = 1.0; w_final = w_ai; ev_final = ev_ai
            final_pass = ai_pass; used_alpha = False

            if not ai_pass and mode == 'ai':
                for alpha in [0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1, 0.0]:
                    w_mix = alpha * w_ai + (1 - alpha) * wt
                    w_mix = normalize_mainlobe(w_mix, px, py, pz, u0, v0, w0)
                    ev_mix = eval_full_81(w_mix, px, py, pz, th0, ph_target, nd)
                    mix_pass = (ev_mix['pt'] <= 1.0 and ev_mix['pr'] <= 1.001 and
                               ev_mix['wn'] <= -28.0 and ev_mix['sll'] - t_sll_target <= -0.5 and
                               np.linalg.norm(w_mix) / (np.linalg.norm(wt) + 1e-30) <= 1.5)
                    if mix_pass:
                        alpha_best = alpha; w_final = w_mix; ev_final = ev_mix
                        final_pass = True; used_alpha = True; break
                if not final_pass:
                    w_final = wt; ev_final = ev_taylor
                    alpha_best = 0.0; used_alpha = True

            all_results.append({
                'parent_id': int(i) if parent_ids is None else int(parent_ids[i]),
                'theta0': th0, 'target_phi': float(ph_target),
                'canonical_phi': float(canon_ph), 'd4_tid': int(tid),
                'support_label': sl, 'mode': mode,
                'taylor_sll': t_sll_target,
                'ai_sll': float(ev_ai['sll']),
                'final_sll': float(ev_final['sll']),
                'improvement': float(ev_final['sll'] - t_sll_target),
                'pt': float(ev_final['pt']), 'peak': float(ev_final['pr']),
                'worst_null': float(ev_final['wn']),
                'null_depths': ev_final['nulls'],
                'norm_ratio': float(np.linalg.norm(w_final) / (np.linalg.norm(wt) + 1e-30)),
                'main_err': float(abs(ev_final['mr'] - 1.0)),
                'ai_pass': bool(ai_pass), 'final_pass': bool(final_pass),
                'alpha': float(alpha_best), 'used_alpha': bool(used_alpha),
                'w_re': w_final.real.tolist(), 'w_im': w_final.imag.tolist(),
            })

    return all_results


def main():
    print('='*70)
    print('D4 Canonical Wrapper Fix v2')
    print('='*70)

    coords = load_coords()
    px = coords[:, 0]; py = coords[:, 1]; pz = coords[:, 2]

    # 构建D4置换
    perms = {}
    for tid, name in D4_TRANSFORMS:
        perms[tid] = build_permutation(coords, tid)
        is_perm = len(set(perms[tid].tolist())) == N_ELEM
        print(f'  {name}: permutation={is_perm}')

    # 加载模型
    model = DeepSetsV2(9, 256, 2)
    model.load_state_dict(torch.load(os.path.join(OUTPUT_DIR, 'deepsets_8x8_v5_best.pt'), map_location='cpu'))
    model.eval()

    with open(os.path.join(OUTPUT_DIR, 'config_v5.json')) as f:
        config = json.load(f)

    wrapper = CanonicalWrapper(model, coords, perms, config['mean_stats'], config['std_stats'])

    # ============================================================
    # 1. 包装器360°单元测试
    # ============================================================
    test_360_pass = test_wrapper_360(wrapper)
    test_wrapper_specific(wrapper)

    # ============================================================
    # 2. D4不变量测试
    # ============================================================
    invariant_pass = test_d4_invariants(coords, perms, wrapper)

    if not (test_360_pass and invariant_pass):
        print(f'\n*** UNIT TESTS FAILED - STOP ***')
        return

    # ============================================================
    # 3. D4扩展评估
    # ============================================================
    npz = np.load(os.path.join(OUTPUT_DIR, 'split_v4_2.npz'), allow_pickle=True)
    labels = npz['labels']; thetas = npz['thetas']; phis = npz['phis']
    split = npz['split']; t_sll = npz['taylor_sll']

    support_labels = []
    for i in range(len(thetas)):
        if labels[i] == 1:
            support_labels.append('valid')
        elif t_sll[i] > -15:
            support_labels.append('degraded')
        else:
            support_labels.append('fallback_taylor')

    # Block Val
    val_idx = np.where(split == 1)[0]
    print(f'\n--- Block Val D4 Expanded ({len(val_idx)}×8={len(val_idx)*8}) ---')
    val_results = evaluate_d4_expanded(
        wrapper, thetas[val_idx], phis[val_idx], t_sll[val_idx],
        [support_labels[i] for i in val_idx], px, py, pz)

    # 逐tid统计
    print(f'  Per-tid:')
    for tid in range(8):
        tid_results = [r for r in val_results if r['d4_tid'] == tid]
        n_ai = sum(1 for r in tid_results if r['ai_pass'])
        n_final = sum(1 for r in tid_results if r['final_pass'])
        n_alpha = sum(1 for r in tid_results if r['used_alpha'] and r['alpha'] > 0)
        n_taylor = sum(1 for r in tid_results if r['alpha'] == 0.0)
        mean_imp = np.mean([r['improvement'] for r in tid_results])
        print(f'    tid={tid}: n={len(tid_results)} ai={n_ai} final={n_final} '
              f'alpha={n_alpha} taylor={n_taylor} imp={mean_imp:+.2f}dB')

    # Block Test
    test_idx = np.where(split == 2)[0]
    print(f'\n--- Block Test D4 Expanded ({len(test_idx)}×8={len(test_idx)*8}) ---')
    test_results = evaluate_d4_expanded(
        wrapper, thetas[test_idx], phis[test_idx], t_sll[test_idx],
        [support_labels[i] for i in test_idx], px, py, pz)

    print(f'  Per-tid:')
    for tid in range(8):
        tid_results = [r for r in test_results if r['d4_tid'] == tid]
        n_ai = sum(1 for r in tid_results if r['ai_pass'])
        n_final = sum(1 for r in tid_results if r['final_pass'])
        n_alpha = sum(1 for r in tid_results if r['used_alpha'] and r['alpha'] > 0)
        n_taylor = sum(1 for r in tid_results if r['alpha'] == 0.0)
        mean_imp = np.mean([r['improvement'] for r in tid_results])
        print(f'    tid={tid}: n={len(tid_results)} ai={n_ai} final={n_final} '
              f'alpha={n_alpha} taylor={n_taylor} imp={mean_imp:+.2f}dB')

    # 总体
    n_test_total = len(test_results)
    n_test_ai = sum(1 for r in test_results if r['ai_pass'])
    n_test_final = sum(1 for r in test_results if r['final_pass'])
    n_test_taylor = sum(1 for r in test_results if r['alpha'] == 0.0)
    test_pass_rate = n_test_final / n_test_total * 100
    print(f'\n  Total: ai={n_test_ai}/{n_test_total} ({n_test_ai/n_test_total*100:.0f}%)')
    print(f'  Final: {n_test_final}/{n_test_total} ({test_pass_rate:.0f}%)')
    print(f'  Taylor fallback: {n_test_taylor}/{n_test_total}')

    # 高角度
    high_angle = [r for r in test_results if r['theta0'] >= 50]
    if high_angle:
        ha_pass = sum(1 for r in high_angle if r['final_pass'])
        print(f'  High angle (>=50°): {ha_pass}/{len(high_angle)} pass')

    # SLL diff vs SOCP
    socp_slls = npz['final_sll'][test_idx]
    # 每个parent的SOCP SLL (canonical), D4变换后SLL应相同
    sll_diffs = []
    for r in test_results:
        parent = r['parent_id']
        if parent < len(socp_slls):
            sll_diffs.append(r['final_sll'] - float(socp_slls[parent]))
    print(f'  SLL diff (AI-SOCP) median: {np.median(sll_diffs):.2f} dB')

    # Random IID
    rt_npz = np.load(os.path.join(OUTPUT_DIR, 'random_iid_test_v4_2.npz'), allow_pickle=True)
    rt_th = rt_npz['thetas']; rt_ph = rt_npz['phis']
    rt_labels = rt_npz['labels']; rt_t_sll = rt_npz['taylor_sll']
    rt_support = ['valid' if l == 1 else ('degraded' if s > -15 else 'fallback_taylor')
                  for l, s in zip(rt_labels, rt_t_sll)]

    print(f'\n--- Random IID D4 Expanded ({len(rt_th)}×8={len(rt_th)*8}) ---')
    rt_results = evaluate_d4_expanded(
        wrapper, rt_th, rt_ph, rt_t_sll, rt_support, px, py, pz)

    rt_valid = [r for r in rt_results if r['support_label'] == 'valid']
    rt_invalid = [r for r in rt_results if r['support_label'] != 'valid']
    rt_v_pass = sum(1 for r in rt_valid if r['final_pass'])
    print(f'  Valid: {len(rt_valid)}, Pass: {rt_v_pass} ({rt_v_pass/len(rt_valid)*100:.0f}%)')
    print(f'  Invalid: {len(rt_invalid)} (rejected/taylor)')
    rt_reject_modes = {}
    for r in rt_invalid:
        m = r['mode']
        rt_reject_modes[m] = rt_reject_modes.get(m, 0) + 1
    print(f'  Reject modes: {rt_reject_modes}')

    # ============================================================
    # 门槛
    # ============================================================
    print(f'\n{"="*70}')
    print('GATE CHECK')
    print(f'{"="*70}')
    print(f'  D4 360° test: {"PASS" if test_360_pass else "FAIL"}')
    print(f'  D4 invariants: {"PASS" if invariant_pass else "FAIL"}')
    print(f'  Block Test final pass: {test_pass_rate:.0f}% (>=80%): {"PASS" if test_pass_rate >= 80 else "FAIL"}')
    print(f'  Random IID valid pass: {rt_v_pass/len(rt_valid)*100:.0f}% (>=85%): {"PASS" if rt_v_pass/len(rt_valid)*100 >= 85 else "FAIL"}')
    print(f'  SLL diff median: {np.median(sll_diffs):.2f} dB (<=2dB): {"PASS" if abs(np.median(sll_diffs)) <= 2 else "FAIL"}')

    # ============================================================
    # 保存
    # ============================================================
    # 权值NPZ (Block Test 544方向)
    pred_w_re = np.array([[r['w_re'][j] for j in range(N_ELEM)] for r in test_results])
    pred_w_im = np.array([[r['w_im'][j] for j in range(N_ELEM)] for r in test_results])
    pred_npz = os.path.join(OUTPUT_DIR, 'predictions_v5_d4_v2.npz')
    np.savez(pred_npz,
             w_re=pred_w_re, w_im=pred_w_im,
             theta=np.array([r['theta0'] for r in test_results]),
             target_phi=np.array([r['target_phi'] for r in test_results]),
             canonical_phi=np.array([r['canonical_phi'] for r in test_results]),
             d4_tid=np.array([r['d4_tid'] for r in test_results]),
             mode=np.array([r['mode'] for r in test_results]),
             alpha=np.array([r['alpha'] for r in test_results]),
             canonical_parent_id=np.array([r['parent_id'] for r in test_results]),
             )

    # JSON
    results = {
        'wrapper_360_pass': test_360_pass,
        'd4_invariants_pass': invariant_pass,
        'block_val': val_results,
        'block_test': test_results,
        'random_iid': rt_results,
        'gate': {
            'block_test_pass': float(test_pass_rate),
            'random_iid_pass': float(rt_v_pass / len(rt_valid) * 100),
            'sll_diff_median': float(np.median(sll_diffs)),
        },
        'support_domain_note': '测试时使用已知真值标签; 实际推理时support_label来自支持域查找表(非模型自主拒识)',
        'perms': {str(tid): perms[tid].tolist() for tid in range(8)},
        'inverse_tid': INVERSE_TID,
    }
    res_path = os.path.join(OUTPUT_DIR, 'results_v5_d4_v2.json')
    with open(res_path, 'w') as f:
        json.dump(results, f, indent=2, default=str)

    # SHA-256
    sha_list = {}
    for name, path in [('results_v5_d4_v2.json', res_path),
                        ('predictions_v5_d4_v2.npz', pred_npz)]:
        with open(path, 'rb') as f:
            sha = hashlib.sha256(f.read()).hexdigest()
        sha_list[name] = sha
        print(f'  {name}: {sha}')

    with open(os.path.join(OUTPUT_DIR, 'sha256_v5_d4_v2.txt'), 'w') as f:
        for name, sha in sha_list.items():
            f.write(f'{name}: {sha}\n')

    print(f'\n{"="*70}')
    print('DONE')
    print(f'{"="*70}')


if __name__ == '__main__':
    main()
