"""8×8全扫描锥教师数据集生成 v4.0

1. θ=0°单方向; θ=1-34°补充网格+抖动; θ=35-60°只在valid区域生成
2. φ折叠到canonical 0-45°, 旋转扩增后覆盖全360°
3. quality_A/B分层
4. 先划分train/val/test再旋转扩增
5. 纯NumPy物理库, 无torch依赖
"""

import os, sys, time, json, csv
import numpy as np
import cvxpy as cp
import scipy
import scs

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(BASE_DIR, 'mylib'))
OUTPUT_DIR = os.path.join(BASE_DIR, 'output')
os.makedirs(OUTPUT_DIR, exist_ok=True)

LAMBDA_MM = 23.9834
NX = NY = 8
N_ELEM = 64
SLL_DESIGN = 30
FREQ_GHZ = 12.5
EPS_NULL = 0.0316
EPS_NULL_CHECK_DB = 28.0
N_COARSE = 11
N_CUTTING_ITERS = 10
N_EVAL = 81
TRUST_RADIUS_FACTOR = 0.3
NORM_RATIO = 1.5

# 版本记录
VERSIONS = {
    'python': sys.version.split()[0],
    'numpy': np.__version__,
    'scipy': scipy.__version__,
    'cvxpy': cp.__version__,
    'scs': scs.__version__,
}
with open(os.path.join(OUTPUT_DIR, 'versions.txt'), 'w') as f:
    for k, v in VERSIONS.items():
        f.write(f'{k}: {v}\n')


def load_coords():
    csv_path = os.path.join(BASE_DIR, 'element_port_map.csv')
    coords = []
    with open(csv_path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            coords.append((
                float(row['x_mm']) / LAMBDA_MM,
                float(row['y_mm']) / LAMBDA_MM,
                float(row['z_mm']) / LAMBDA_MM,
            ))
    return np.array(coords)


def steering_vec(px, py, pz, u, v, w):
    k = 2 * np.pi
    return np.exp(1j * k * (px * u + py * v + pz * w))

def taylor_1d(N, pos, RdB):
    R0 = 10 ** (RdB / 20)
    A = np.arccosh(R0) / np.pi
    n_bar = max(int(np.ceil(2 * A ** 2 + 0.5)), 2)
    m = np.arange(1, n_bar).reshape(-1, 1)
    n = np.arange(1, n_bar).reshape(1, -1)
    def fact(x):
        import math
        return np.array([math.factorial(int(v)) for v in np.asarray(x).ravel()]).reshape(np.asarray(x).shape)
    sigma = n_bar / (A ** 2 + (n_bar - 0.5) ** 2) ** 0.5
    Sm1 = (fact(n_bar - 1) ** 2) / fact(n_bar + m - 1) / fact(n_bar - m - 1)
    Sm2 = np.prod(1 - (m ** 2 / sigma ** 2 / (A ** 2 + (n - 0.5) ** 2)), axis=1).reshape(-1, 1)
    Sm = Sm1 * Sm2
    pos = np.asarray(pos).reshape(1, -1)
    exc = 1 + 2 * np.sum(Sm * np.cos(m * pos * 2 * np.pi / (N * 0.5)), axis=0)
    exc = exc / np.max(exc)
    return exc.ravel()

def taylor_2d(Nx, Ny, SLL):
    posx = (np.arange(1, Nx + 1) - (Nx / 2 + 0.5)) * 0.5
    posy = (np.arange(1, Ny + 1) - (Ny / 2 + 0.5)) * 0.5
    ax = taylor_1d(Nx, posx, SLL)
    ay = taylor_1d(Ny, posy, SLL)
    return ax, ay

def angular_distance_deg(theta1, phi1, theta2, phi2):
    t1, p1 = np.deg2rad(theta1), np.deg2rad(phi1)
    t2, p2 = np.deg2rad(theta2), np.deg2rad(phi2)
    cos_d = np.cos(t1) * np.cos(t2) + np.sin(t1) * np.sin(t2) * np.cos(p1 - p2)
    return np.rad2deg(np.arccos(np.clip(cos_d, -1, 1)))

def uv_to_w(u, v):
    return np.sqrt(np.maximum(1 - u**2 - v**2, 0))

def get_null_dirs(theta0, phi0):
    if theta0 < 10:
        return [(30, 0), (30, 90), (30, 180), (30, 270)]
    return [
        (theta0, (phi0 + 90) % 360),
        (theta0, (phi0 + 180) % 360),
        (theta0, (phi0 + 270) % 360),
        (min(theta0 + 25, 85), (phi0 + 45) % 360),
    ]


def solve_socp(px, py, pz, u0, v0, w0, sl_u, sl_v, sl_w,
               nu, nv, nw, wtn, trust_r, norm_max, peaks=None):
    n = len(px)
    w = cp.Variable(n, complex=True)
    t = cp.Variable()
    a_main = steering_vec(px, py, pz, u0, v0, w0)
    cons = [a_main.conj() @ w == 1.0 + 0j]
    for us, vs, ws in zip(sl_u, sl_v, sl_w):
        cons.append(cp.norm(steering_vec(px, py, pz, us, vs, ws).conj() @ w, 2) <= t)
    for un, vn, wn in zip(nu, nv, nw):
        cons.append(cp.norm(steering_vec(px, py, pz, un, vn, wn).conj() @ w, 2) <= EPS_NULL)
    cons.append(cp.norm(w - (wtn.real + 1j * wtn.imag), 2) <= trust_r)
    cons.append(cp.norm(w, 2) <= norm_max)
    if peaks:
        for up, vp, wp in peaks:
            cons.append(cp.norm(steering_vec(px, py, pz, up, vp, wp).conj() @ w, 2) <= 1.0)
    prob = cp.Problem(cp.Minimize(t), cons)
    try:
        prob.solve(solver=cp.SCS, verbose=False, max_iters=20000)
        if prob.status not in ['optimal', 'optimal_inaccurate']:
            return None
    except:
        return None
    return w.value


def eval_full(w, px, py, pz, th0, ph0, null_dirs, n_eval=N_EVAL):
    k = 2 * np.pi
    u0 = np.sin(np.deg2rad(th0)) * np.cos(np.deg2rad(ph0))
    v0 = np.sin(np.deg2rad(th0)) * np.sin(np.deg2rad(ph0))
    w0 = np.cos(np.deg2rad(th0))
    u = np.linspace(-1, 1, n_eval); v = np.linspace(-1, 1, n_eval)
    ug, vg = np.meshgrid(u, v, indexing='ij')
    vis = (ug**2 + vg**2) <= 1.0; wg = uv_to_w(ug, vg)
    bw = 0.886 * 2.0 / NX * 180 / np.pi
    exc = np.sin(np.deg2rad(3.0 * bw / max(np.cos(np.deg2rad(th0)), 0.1)))
    dist = np.sqrt((ug - u0)**2 + (vg - v0)**2)
    sl_mask = (dist >= exc) & vis
    vf = vis.ravel(); uf = ug.ravel(); vf2 = vg.ravel(); wf = wg.ravel()
    pat = np.zeros(len(uf))
    for i in range(len(uf)):
        if vf[i]:
            psi = k * (px * uf[i] + py * vf2[i] + pz * wf[i])
            pat[i] = np.abs(np.sum(np.conj(w) * np.exp(1j * psi)))
    psi_m = k * (px * u0 + py * v0 + pz * w0)
    mr = np.abs(np.sum(np.conj(w) * np.exp(1j * psi_m)))
    pi2 = np.argmax(pat)
    pu = uf[pi2]; pv = vf2[pi2]; pw = wf[pi2]; pval = pat[pi2]
    # refine
    pt_c = np.degrees(np.arcsin(np.clip(np.sqrt(pu**2+pv**2), 0, 1)))
    pp_c = np.degrees(np.arctan2(pv, pu)) % 360
    for rt in np.arange(max(0, pt_c-2.0), min(90, pt_c+2.0)+0.25, 0.25):
        for rpw in np.arange(pp_c-2.0, pp_c+2.0+0.25, 0.25):
            rp = rpw % 360.0
            ru = np.sin(np.deg2rad(rt))*np.cos(np.deg2rad(rp))
            rv = np.sin(np.deg2rad(rt))*np.sin(np.deg2rad(rp))
            rw = np.cos(np.deg2rad(rt))
            if ru**2+rv**2 > 1.0: continue
            vr = np.abs(np.sum(np.conj(w)*np.exp(1j*k*(px*ru+py*rv+pz*rw))))
            if vr > pval: pval=vr; pu=ru; pv=rv; pw=rw
    pr = pval / (mr + 1e-30)
    pth = np.degrees(np.arcsin(np.clip(np.sqrt(pu**2+pv**2), 0, 1)))
    pph = np.degrees(np.arctan2(pv, pu)) % 360
    pte = angular_distance_deg(pth, pph, th0, ph0)
    sf = sl_mask.ravel(); ps = pat[sf]
    sll = 20*np.log10(np.max(ps)/(mr+1e-30)) if mr > 1e-10 else -300
    suf = uf[sf]; svf = vf2[sf]; swf = wf[sf]
    si = np.argsort(ps)[::-1][:10]
    worst = [(suf[i], svf[i], swf[i]) for i in si]
    nulls = []
    for tn, pn in null_dirs:
        un = np.sin(np.deg2rad(tn))*np.cos(np.deg2rad(pn))
        vn = np.sin(np.deg2rad(tn))*np.sin(np.deg2rad(pn))
        wn = np.cos(np.deg2rad(tn))
        nd = 20*np.log10(np.abs(np.sum(np.conj(w)*np.exp(1j*k*(px*un+py*vn+pz*wn))))/(mr+1e-30))
        nulls.append(float(nd))
    return {'sll': float(sll), 'pt': float(pte), 'mr': float(mr),
            'pr': float(pr), 'pu': float(pu), 'pv': float(pv), 'pw': float(pw),
            'wn': float(max(nulls)), 'nulls': nulls, 'worst': worst}


def check_safety(ev, me, wn, tn):
    if me > 1e-3: return False, 'main_err'
    if ev['pt'] > 1.0: return False, 'pt'
    if ev['pr'] > 1.001: return False, 'peak'
    if ev['wn'] > -EPS_NULL_CHECK_DB: return False, 'null'
    if wn / (tn + 1e-30) > NORM_RATIO: return False, 'norm'
    return True, ''

def check_teacher(ev, ts, me, wn, tn):
    ok, r = check_safety(ev, me, wn, tn)
    if not ok: return False, r
    if ev['sll'] - ts > -0.5: return False, 'imp'
    return True, ''

def check_quality_A(ev, ts, me, wn, tn):
    if ev['sll'] - ts > -1.0: return False
    if ev['pt'] > 0.8: return False
    if ev['pr'] > 1.0008: return False
    if ev['wn'] > -30: return False
    if wn / (tn + 1e-30) > 1.3: return False
    return True


def solve_dir(px, py, pz, ax, ay, th0, ph0):
    nd = get_null_dirs(th0, ph0)
    u0 = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph0))
    v0 = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph0))
    w0 = np.cos(np.deg2rad(th0))
    wt = np.outer(ay, ax).ravel() * np.exp(1j * 2*np.pi*(px*u0+py*v0+pz*w0))
    wtn = wt / (np.conj(steering_vec(px,py,pz,u0,v0,w0)) @ wt + 1e-30)
    te = eval_full(wtn, px, py, pz, th0, ph0, nd)
    tn = np.linalg.norm(wtn)
    tme = abs(abs(np.conj(steering_vec(px,py,pz,u0,v0,w0)) @ wtn) - 1.0)
    nu = [np.sin(np.deg2rad(t))*np.cos(np.deg2rad(p)) for t,p in nd]
    nv = [np.sin(np.deg2rad(t))*np.sin(np.deg2rad(p)) for t,p in nd]
    nw = [np.cos(np.deg2rad(t)) for t,p in nd]
    uc = np.linspace(-1,1,N_COARSE); vc = np.linspace(-1,1,N_COARSE)
    ugc,vgc = np.meshgrid(uc,vc,indexing='ij')
    visc = (ugc**2+vgc**2)<=1.0; wgc = uv_to_w(ugc,vgc)
    bw = 0.886*2.0/NX*180/np.pi
    exc = np.sin(np.deg2rad(3.0*bw/max(np.cos(np.deg2rad(th0)),0.1)))
    dc = np.sqrt((ugc-u0)**2+(vgc-v0)**2)
    smc = (dc>=exc)&visc
    slu = list(ugc[smc]); slv = list(vgc[smc]); slw = list(wgc[smc])
    tr = TRUST_RADIUS_FACTOR*tn; nm = NORM_RATIO*tn
    bv = None; br = None; pc = []; ni = 0
    for it in range(N_CUTTING_ITERS):
        wo = solve_socp(px,py,pz,u0,v0,w0,slu,slv,slw,nu,nv,nw,wtn,tr,nm,pc)
        if wo is None: break
        won = wo / (np.conj(steering_vec(px,py,pz,u0,v0,w0)) @ wo + 1e-30)
        se = eval_full(won, px, py, pz, th0, ph0, nd)
        ni = it+1
        me = abs(abs(np.conj(steering_vec(px,py,pz,u0,v0,w0)) @ won) - 1.0)
        wn = np.linalg.norm(won)
        it_ok, _ = check_teacher(se, te['sll'], me, wn, tn)
        if it_ok:
            qa = check_quality_A(se, te['sll'], me, wn, tn)
            if bv is None or se['sll'] < bv['sll']:
                bv = {'sll': se['sll'], 'w': won.copy(), 'ev': se, 'me': me, 'wn': wn, 'qa': qa}
        else:
            is_s, _ = check_safety(se, me, wn, tn)
            if is_s:
                if br is None or se['sll'] < br['sll']:
                    br = {'sll': se['sll'], 'w': won.copy(), 'ev': se, 'me': me, 'wn': wn}
        if se['pr'] > 1.001 or se['pt'] > 1.0:
            npk = (se['pu'], se['pv'], se['pw'])
            q1 = np.array(npk)
            too_close = False
            for existing_pc in pc:
                q2 = np.array(existing_pc)
                n1 = np.linalg.norm(q1); n2 = np.linalg.norm(q2)
                if n1 < 1e-10 or n2 < 1e-10:
                    too_close = True; break
                cos_a = np.clip(np.dot(q1, q2) / (n1 * n2), -1, 1)
                if np.degrees(np.arccos(cos_a)) < 2.0:
                    too_close = True; break
            if not too_close and len(pc) < 5:
                pc.append(npk)
        for uw,vw,ww in se['worst'][:2]:
            al = any(abs(s-uw)<0.01 and abs(sv-vw)<0.01 for s,sv in zip(slu,slv))
            if not al: slu.append(uw); slv.append(vw); slw.append(ww)
    return {'bv': bv, 'br': br, 'te': te, 'wtn': wtn, 'tn': tn, 'tme': tme, 'ni': ni}


def main():
    print('='*70)
    print('8x8 Full Teacher Dataset v4.0')
    print('='*70)

    coords = load_coords()
    px, py, pz = coords[:,0], coords[:,1], coords[:,2]
    ax, ay = taylor_2d(NX, NY, SLL_DESIGN)

    # ============================================================
    # 生成canonical方向列表
    # ============================================================
    rng = np.random.RandomState(42)
    canonical_dirs = []

    # θ=0°: 1个方向
    canonical_dirs.append((0.0, 0.0, 'grid'))

    # θ=1-34°: 网格 + 抖动
    for th in range(1, 35):
        for ph in range(0, 46, 5):
            canonical_dirs.append((float(th), float(ph), 'grid'))
        # 随机抖动
        for _ in range(3):
            ph_r = rng.uniform(0, 45)
            canonical_dirs.append((float(th), float(ph_r), 'jitter'))

    # θ=35-60°: 只在valid区域(φ≥20°的多数方向valid)
    for th in range(35, 61):
        for ph in [0, 5, 10, 15, 20, 25, 30, 35, 40, 43, 44, 45]:
            canonical_dirs.append((float(th), float(ph), 'support'))
        # 随机抖动在valid区域
        for _ in range(2):
            ph_r = rng.uniform(20, 45)
            canonical_dirs.append((float(th), float(ph_r), 'jitter'))

    print(f'Canonical directions: {len(canonical_dirs)}')

    # ============================================================
    # 求解每个canonical方向
    # ============================================================
    samples = []
    t_start = time.time()

    for i, (th, ph, src) in enumerate(canonical_dirs):
        sol = solve_dir(px, py, pz, ax, ay, th, ph)
        nd = get_null_dirs(th, ph)

        if sol['bv']:
            bv = sol['bv']
            w_final = bv['w']; ev = bv['ev']
            me = bv['me']; wn = bv['wn']
            label = 'valid'
            qa = bv.get('qa', False)
            quality = 'A' if qa else 'B'
        else:
            t_safe, _ = check_safety(sol['te'], sol['tme'], sol['tn'], sol['tn'])
            if t_safe:
                w_final = sol['wtn']; ev = sol['te']
                me = sol['tme']; wn = sol['tn']
                if sol['te']['sll'] > -15:
                    label = 'degraded'; quality = ''
                else:
                    label = 'fallback_taylor'; quality = ''
            else:
                w_final = sol['wtn']; ev = sol['te']
                me = sol['tme']; wn = sol['tn']
                label = 'unsupported'; quality = ''

        imp = ev['sll'] - sol['te']['sll']
        nr = wn / (sol['tn'] + 1e-30)

        u0 = np.sin(np.deg2rad(th))*np.cos(np.deg2rad(ph))
        v0 = np.sin(np.deg2rad(th))*np.sin(np.deg2rad(ph))
        w0 = np.cos(np.deg2rad(th))

        s = {
            'idx': i, 'theta0': float(th), 'phi0': float(ph),
            'source': src, 'label': label, 'quality': quality,
            'taylor_sll': float(sol['te']['sll']),
            'final_sll': float(ev['sll']),
            'improvement': float(imp),
            'pt': float(ev['pt']), 'peak': float(ev['pr']),
            'worst_null': float(ev['wn']),
            'null_depths': ev['nulls'],
            'w_norm': float(wn), 't_norm': float(sol['tn']),
            'norm_ratio': float(nr),
            'main_err': float(me),
            'n_iters': sol['ni'],
            'u0': float(u0), 'v0': float(v0), 'w0': float(w0),
            'w_re': w_final.real.tolist(),
            'w_im': w_final.imag.tolist(),
        }
        samples.append(s)

        if (i+1) % 50 == 0:
            elapsed = time.time() - t_start
            eta = (len(canonical_dirs) - i - 1) * (elapsed / (i + 1))
            n_v = sum(1 for x in samples if x['label'] == 'valid')
            print(f'  [{i+1}/{len(canonical_dirs)}] valid={n_v} ETA={eta:.0f}s')

    total_time = time.time() - t_start

    # ============================================================
    # 统计
    # ============================================================
    n_valid = sum(1 for s in samples if s['label'] == 'valid')
    n_degraded = sum(1 for s in samples if s['label'] == 'degraded')
    n_fallback = sum(1 for s in samples if s['label'] == 'fallback_taylor')
    n_unsupported = sum(1 for s in samples if s['label'] == 'unsupported')
    n_qa = sum(1 for s in samples if s.get('quality') == 'A')
    n_qb = sum(1 for s in samples if s.get('quality') == 'B')

    print(f'\n{"="*70}')
    print(f'DATASET SUMMARY: {len(samples)} canonical, {total_time:.0f}s')
    print(f'  Valid: {n_valid} (A={n_qa}, B={n_qb})')
    print(f'  Degraded: {n_degraded}, Fallback: {n_fallback}, Unsupported: {n_unsupported}')
    print(f'  Rotated total: ~{n_valid * 4}')
    print(f'{"="*70}')

    # ============================================================
    # 划分train/val/test (按canonical方向块, 旋转前)
    # ============================================================
    valid_indices = [i for i, s in enumerate(samples) if s['label'] == 'valid']
    rng2 = np.random.RandomState(123)
    perm = rng2.permutation(len(valid_indices))
    n_v = len(valid_indices)
    n_test = max(20, n_v // 8)  # ~12.5%
    n_val = max(15, n_v // 8)
    test_canon = [valid_indices[perm[i]] for i in range(n_test)]
    val_canon = [valid_indices[perm[n_test + i]] for i in range(n_val)]
    train_canon = [valid_indices[perm[n_test + n_val + i]] for i in range(n_v - n_test - n_val)]

    # 随机角度测试集(不与训练重叠)
    random_test = []
    for _ in range(20):
        th = rng2.uniform(0, 55)
        ph = rng2.uniform(0, 45)
        random_test.append((float(th), float(ph)))

    splits = {
        'train_canon': train_canon,
        'val_canon': val_canon,
        'test_canon': test_canon,
        'random_test_dirs': random_test,
    }

    print(f'\nSplit (before rotation):')
    print(f'  Train: {len(train_canon)} canonical')
    print(f'  Val: {len(val_canon)} canonical')
    print(f'  Test: {len(test_canon)} canonical')
    print(f'  Random test: {len(random_test)} directions')
    print(f'  After rotation: train~{len(train_canon)*4}, val~{len(val_canon)*4}, test~{len(test_canon)*4}')

    # ============================================================
    # 保存
    # ============================================================
    # JSON
    out_json = os.path.join(OUTPUT_DIR, 'teacher_dataset_v4.json')
    with open(out_json, 'w') as f:
        json.dump({
            'samples': [{k: v for k, v in s.items() if k not in ('w_re', 'w_im')} for s in samples],
            'splits': splits,
            'stats': {
                'n_canonical': len(samples), 'n_valid': n_valid,
                'n_qa': n_qa, 'n_qb': n_qb,
                'n_degraded': n_degraded, 'n_fallback': n_fallback,
                'n_unsupported': n_unsupported,
                'total_time_s': total_time,
            },
            'versions': VERSIONS,
            'config': {
                'freq_ghz': FREQ_GHZ, 'lambda_mm': LAMBDA_MM,
                'nx': NX, 'ny': NY, 'sll': SLL_DESIGN,
                'eps_null': EPS_NULL, 'trust': TRUST_RADIUS_FACTOR,
                'norm': NORM_RATIO, 'n_iters': N_CUTTING_ITERS,
            },
        }, f, indent=2, default=str)
    print(f'\nJSON: {out_json}')

    # NPZ (权值 + 元数据)
    n = len(samples)
    w_re = np.zeros((n, N_ELEM))
    w_im = np.zeros((n, N_ELEM))
    for i, s in enumerate(samples):
        w_re[i] = s['w_re']
        w_im[i] = s['w_im']

    labels = np.array([1 if s['label']=='valid' else 0 for s in samples])
    qualities = np.array([1 if s.get('quality')=='A' else (2 if s.get('quality')=='B' else 0) for s in samples])
    thetas = np.array([s['theta0'] for s in samples])
    phis = np.array([s['phi0'] for s in samples])
    t_slls = np.array([s['taylor_sll'] for s in samples])
    f_slls = np.array([s['final_sll'] for s in samples])

    out_npz = os.path.join(OUTPUT_DIR, 'teacher_dataset_v4.npz')
    np.savez(out_npz,
             w_re=w_re, w_im=w_im,
             px=px, py=py, pz=pz,
             labels=labels, qualities=qualities,
             thetas=thetas, phis=phis,
             taylor_sll=t_slls, final_sll=f_slls,
             train_idx=np.array(train_canon),
             val_idx=np.array(val_canon),
             test_idx=np.array(test_canon),
             split=np.array([0 if i in train_canon else (1 if i in val_canon else (2 if i in test_canon else -1)) for i in range(n)]),
             )
    print(f'NPZ: {out_npz}')

    # SHA256
    import hashlib
    with open(out_npz, 'rb') as f:
        sha = hashlib.sha256(f.read()).hexdigest()
    print(f'NPZ SHA-256: {sha}')
    print('='*70)


if __name__ == '__main__':
    main()
