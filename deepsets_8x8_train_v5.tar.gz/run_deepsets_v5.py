"""8×8 DeepSets正式训练 v5.0

严格遵守:
  1. 固定split_v4_2.npz, Train标准化参数
  2. 0/90/180/270旋转扩增, 继承parent split
  3. Taylor基线+残差, LayerNorm, hidden=256
  4. Quality A权重1.0, B权重0.7
  5. AdamW lr=3e-4, wd=1e-5, 300epoch, patience=40
  6. 3个种子, Block Val选模型
  7. Block Test只评估一次
  8. 物理验收+alpha回退+支持域控制
"""

import os, sys, time, json, hashlib, math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(BASE_DIR, 'mylib'))
OUTPUT_DIR = os.path.join(BASE_DIR, 'output')
os.makedirs(OUTPUT_DIR, exist_ok=True)

N_ELEM = 64
NX = NY = 8
HIDDEN_DIM = 256
EPOCHS = 300
BATCH_SIZE = 16
LR = 3e-4
WEIGHT_DECAY = 1e-5
PATIENCE = 40
N_SEEDS = 3
WEIGHT_SCALE = 64.0
COORD_NORM = 4.0  # px范围约-1.75~1.75

EPS_NULL_CHECK_DB = 28.0


# ============================================================
# 数据加载与扩增
# ============================================================
def load_data():
    npz = np.load(os.path.join(OUTPUT_DIR, 'split_v4_2.npz'), allow_pickle=True)
    w_re = npz['w_re']; w_im = npz['w_im']
    px = npz['px']; py = npz['py']; pz = npz['pz']
    labels = npz['labels']; qualities = npz['qualities']
    thetas = npz['thetas']; phis = npz['phis']
    split = npz['split']
    t_sll = npz['taylor_sll']; f_sll = npz['final_sll']
    return w_re, w_im, px, py, pz, labels, qualities, thetas, phis, split, t_sll, f_sll


def rotate_90_2d(arr_2d, k):
    return np.rot90(arr_2d, k=-k)


def expand_rotation(w_re, w_im, thetas, phis, qualities, split, t_sll, f_sll,
                    px, py, pz, parent_ids):
    """0/90/180/270旋转扩增。继承parent split。"""
    n = len(w_re)
    all_w_re = []; all_w_im = []
    all_th = []; all_ph = []; all_q = []; all_sp = []
    all_tsll = []; all_fsll = []; all_pid = []
    all_px = []; all_py = []; all_pz = []

    for i in range(n):
        if split[i] not in [0, 1, 2]:  # 只扩增train/val/test
            continue
        wr_2d = w_re[i].reshape(NY, NX)
        wi_2d = w_im[i].reshape(NY, NX)
        px_2d = px.reshape(NY, NX)
        py_2d = py.reshape(NY, NX)
        pz_2d = pz.reshape(NY, NX)

        for rot in range(4):
            wr_rot = rotate_90_2d(wr_2d, rot).ravel()
            wi_rot = rotate_90_2d(wi_2d, rot).ravel()
            px_rot = rotate_90_2d(px_2d, rot).ravel()
            py_rot = rotate_90_2d(py_2d, rot).ravel()
            pz_rot = rotate_90_2d(pz_2d, rot).ravel()

            new_ph = (float(phis[i]) + rot * 90.0) % 360.0
            # canonical折叠
            canon_ph = new_ph
            if canon_ph > 45:
                # 不折叠, 保持实际方向
                pass

            all_w_re.append(wr_rot); all_w_im.append(wi_rot)
            all_th.append(float(thetas[i])); all_ph.append(new_ph)
            all_q.append(int(qualities[i])); all_sp.append(int(split[i]))
            all_tsll.append(float(t_sll[i])); all_fsll.append(float(f_sll[i]))
            all_pid.append(i)
            all_px.append(px_rot); all_py.append(py_rot); all_pz.append(pz_rot)

    return (np.array(all_w_re), np.array(all_w_im),
            np.array(all_th), np.array(all_ph),
            np.array(all_q), np.array(all_sp),
            np.array(all_tsll), np.array(all_fsll),
            np.array(all_pid),
            np.array(all_px), np.array(all_py), np.array(all_pz))


def make_features(w_re, w_im, thetas, phis, px, py, pz, mean_stats, std_stats):
    """构建输入特征, 用train统计量标准化。"""
    u0 = np.sin(np.deg2rad(thetas)) * np.cos(np.deg2rad(phis))
    v0 = np.sin(np.deg2rad(thetas)) * np.sin(np.deg2rad(phis))
    w0 = np.cos(np.deg2rad(thetas))

    n = len(w_re); ne = w_re.shape[1]
    # 坐标标准化
    px_n = (px - mean_stats['px_mean']) / (std_stats['px_std'] + 1e-8)
    py_n = (py - mean_stats['py_mean']) / (std_stats['py_std'] + 1e-8)
    pz_n = (pz - mean_stats['pz_mean']) / (std_stats['pz_std'] + 1e-8)

    feat = np.stack([
        px_n, py_n, pz_n,
        w_re * WEIGHT_SCALE, w_im * WEIGHT_SCALE,
        np.broadcast_to(u0[:, None], (n, ne)),
        np.broadcast_to(v0[:, None], (n, ne)),
        np.broadcast_to(w0[:, None], (n, ne)),
        np.full((n, ne), 0.6, dtype=np.float32),
    ], axis=-1).astype(np.float32)
    return feat


def make_targets(w_re_taylor, w_im_taylor, w_re_socp, w_im_socp):
    """残差目标 = (SOCP - Taylor) * SCALE"""
    dr = (w_re_socp - w_re_taylor) * WEIGHT_SCALE
    di = (w_im_socp - w_im_taylor) * WEIGHT_SCALE
    return np.stack([dr, di], axis=-1).astype(np.float32)


# ============================================================
# DeepSets模型 (LayerNorm + hidden=256)
# ============================================================
class DeepSetsV2(nn.Module):
    def __init__(self, input_dim=9, hidden_dim=256, output_dim=2):
        super().__init__()
        self.phi = nn.Sequential(
            nn.Linear(input_dim, hidden_dim), nn.LayerNorm(hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim), nn.LayerNorm(hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim), nn.LayerNorm(hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.rho = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim), nn.LayerNorm(hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.output_net = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim), nn.LayerNorm(hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, output_dim),
        )

    def forward(self, x):
        h = self.phi(x)
        mean_p = h.mean(dim=1)
        max_p = h.max(dim=1)[0]
        pooled = torch.cat([mean_p, max_p], dim=-1)
        g = self.rho(pooled)
        g_exp = g.unsqueeze(1).expand(-1, h.size(1), -1)
        combined = torch.cat([h, g_exp], dim=-1)
        return self.output_net(combined)


def count_params(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


# ============================================================
# 训练
# ============================================================
def train_one_seed(seed, train_feat, train_target, train_weights_q,
                   val_feat, val_target, val_weights_q,
                   device):
    torch.manual_seed(seed)
    np.random.seed(seed)

    model = DeepSetsV2(9, HIDDEN_DIM, 2).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', factor=0.5, patience=15)

    # 加权MSE
    def weighted_mse(pred, target, weights):
        w = weights.unsqueeze(-1).unsqueeze(-1)  # (B, 1, 1)
        return ((pred - target) ** 2 * w).mean()

    best_val_loss = float('inf')
    best_state = None
    patience_counter = 0
    history = {'loss': [], 'val_loss': []}

    n_train = len(train_feat)
    indices = np.arange(n_train)

    for epoch in range(EPOCHS):
        model.train()
        np.random.shuffle(indices)
        epoch_loss = 0.0
        n_batches = 0

        for start in range(0, n_train, BATCH_SIZE):
            idx = indices[start:start + BATCH_SIZE]
            bx = torch.as_tensor(train_feat[idx], dtype=torch.float32, device=device)
            by = torch.as_tensor(train_target[idx], dtype=torch.float32, device=device)
            bw = torch.as_tensor(train_weights_q[idx], dtype=torch.float32, device=device)

            optimizer.zero_grad()
            pred = model(bx)
            loss = weighted_mse(pred, by, bw)
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item()
            n_batches += 1

        avg_loss = epoch_loss / n_batches

        model.eval()
        with torch.no_grad():
            vx = torch.as_tensor(val_feat, dtype=torch.float32, device=device)
            vy = torch.as_tensor(val_target, dtype=torch.float32, device=device)
            vw = torch.as_tensor(val_weights_q, dtype=torch.float32, device=device)
            vp = model(vx)
            val_loss = weighted_mse(vp, vy, vw).item()

        scheduler.step(val_loss)
        history['loss'].append(avg_loss)
        history['val_loss'].append(val_loss)

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
            patience_counter = 0
        else:
            patience_counter += 1

        if (epoch + 1) % 50 == 0:
            print(f'    Seed {seed} Epoch {epoch+1}: loss={avg_loss:.6f} val={val_loss:.6f} best={best_val_loss:.6f}')

        if patience_counter >= PATIENCE:
            print(f'    Seed {seed} Early stop at epoch {epoch+1}')
            break

    if best_state:
        model.load_state_dict(best_state)
    return model, best_val_loss, history, epoch + 1


# ============================================================
# 物理评估
# ============================================================
def steering_vec(px, py, pz, u, v, w):
    k = 2 * np.pi
    return np.exp(1j * k * (px * u + py * v + pz * w))

def normalize_mainlobe(w, px, py, pz, u0, v0, w0):
    a = steering_vec(px, py, pz, u0, v0, w0)
    resp = np.conj(a) @ w
    if np.abs(resp) < 1e-12: return w
    return w / resp

def angular_dist_deg(th1, ph1, th2, ph2):
    t1, p1 = np.deg2rad(th1), np.deg2rad(ph1)
    t2, p2 = np.deg2rad(th2), np.deg2rad(ph2)
    cos_d = np.cos(t1)*np.cos(t2) + np.sin(t1)*np.sin(t2)*np.cos(p1-p2)
    return float(np.rad2deg(np.arccos(np.clip(cos_d, -1, 1))))


def eval_pattern(w, px, py, pz, th0, ph0, null_dirs, n_eval=61):
    k = 2 * np.pi
    u0 = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph0))
    v0 = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph0))
    w0 = np.cos(np.deg2rad(th0))
    u = np.linspace(-1, 1, n_eval); v = np.linspace(-1, 1, n_eval)
    ug, vg = np.meshgrid(u, v, indexing='ij')
    vis = (ug**2 + vg**2) <= 1.0; wg = np.sqrt(np.maximum(1-ug**2-vg**2, 0))
    bw = 0.886 * 2.0 / NX * 180 / np.pi
    exc = np.sin(np.deg2rad(3.0 * bw / max(np.cos(np.deg2rad(th0)), 0.1)))
    dist = np.sqrt((ug-u0)**2 + (vg-v0)**2)
    sl_mask = (dist >= exc) & vis

    vf = vis.ravel(); uf = ug.ravel(); vf2 = vg.ravel(); wf = wg.ravel()
    pat = np.zeros(len(uf))
    for i in range(len(uf)):
        if vf[i]:
            psi = k * (px*uf[i] + py*vf2[i] + pz*wf[i])
            pat[i] = np.abs(np.sum(np.conj(w) * np.exp(1j * psi)))

    psi_m = k * (px*u0 + py*v0 + pz*w0)
    mr = np.abs(np.sum(np.conj(w) * np.exp(1j * psi_m)))
    pi2 = np.argmax(pat)
    pval = pat[pi2]
    # 局部细化
    pt_c = np.degrees(np.arcsin(np.clip(np.sqrt(uf[pi2]**2+vf2[pi2]**2), 0, 1)))
    pp_c = np.degrees(np.arctan2(vf2[pi2], uf[pi2])) % 360
    pu, pv, pw = uf[pi2], vf2[pi2], wf[pi2]
    for rt in np.arange(max(0, pt_c-2.0), min(90, pt_c+2.0)+0.25, 0.25):
        for rpw in np.arange(pp_c-2.0, pp_c+2.0+0.25, 0.25):
            rp = rpw % 360.0
            ru = np.sin(np.deg2rad(rt))*np.cos(np.deg2rad(rp))
            rv = np.sin(np.deg2rad(rt))*np.sin(np.deg2rad(rp))
            rw = np.cos(np.deg2rad(rt))
            if ru**2+rv**2 > 1.0: continue
            vr = np.abs(np.sum(np.conj(w)*np.exp(1j*k*(px*ru+py*rv+pz*rw))))
            if vr > pval: pval=vr; pu=ru; pv=rv; pw=rw

    pr = pval / (mr + 1e-30)
    pth = np.degrees(np.arcsin(np.clip(np.sqrt(pu**2+pv**2), 0, 1)))
    pph = np.degrees(np.arctan2(pv, pu)) % 360
    pte = angular_dist_deg(pth, pph, th0, ph0)
    sf = sl_mask.ravel(); ps = pat[sf]
    sll = 20*np.log10(np.max(ps)/(mr+1e-30)) if mr > 1e-10 else -300

    nulls = []
    for tn, pn in null_dirs:
        un = np.sin(np.deg2rad(tn))*np.cos(np.deg2rad(pn))
        vn = np.sin(np.deg2rad(tn))*np.sin(np.deg2rad(pn))
        wn = np.cos(np.deg2rad(tn))
        nd = 20*np.log10(np.abs(np.sum(np.conj(w)*np.exp(1j*k*(px*un+py*vn+pz*wn))))/(mr+1e-30))
        nulls.append(float(nd))

    return {'sll': float(sll), 'pt': float(pte), 'pr': float(pr),
            'mr': float(mr), 'wn': float(max(nulls)), 'nulls': nulls}


def get_null_dirs(theta0, phi0):
    if theta0 < 10:
        return [(30, 0), (30, 90), (30, 180), (30, 270)]
    return [
        (theta0, (phi0 + 90) % 360),
        (theta0, (phi0 + 180) % 360),
        (theta0, (phi0 + 270) % 360),
        (min(theta0 + 25, 85), (phi0 + 45) % 360),
    ]


def evaluate_model(model, feat, w_re_taylor, w_im_taylor, thetas, phis,
                   px_list, py_list, pz_list, t_slls, device):
    """评估模型: AI权值 + alpha回退 + 物理验收。"""
    model.eval()
    results = []

    for i in range(len(feat)):
        x = torch.as_tensor(feat[i:i+1], dtype=torch.float32, device=device)
        with torch.no_grad():
            delta = model(x)[0].cpu().numpy()

        th0 = float(thetas[i]); ph0 = float(phis[i])
        u0 = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph0))
        v0 = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph0))
        w0 = np.cos(np.deg2rad(th0))

        w_taylor = w_re_taylor[i] + 1j * w_im_taylor[i]
        w_ai = (w_re_taylor[i] + delta[:, 0] / WEIGHT_SCALE) + \
               1j * (w_im_taylor[i] + delta[:, 1] / WEIGHT_SCALE)
        w_ai = normalize_mainlobe(w_ai, px_list[i], py_list[i], pz_list[i], u0, v0, w0)

        nd = get_null_dirs(th0, ph0)

        # 评估AI
        ev_ai = eval_pattern(w_ai, px_list[i], py_list[i], pz_list[i], th0, ph0, nd)

        # 物理验收
        ai_pass = (ev_ai['pt'] <= 1.0 and ev_ai['pr'] <= 1.001 and
                   ev_ai['wn'] <= -EPS_NULL_CHECK_DB and
                   ev_ai['sll'] - t_slls[i] <= -0.5 and
                   np.linalg.norm(w_ai) / (np.linalg.norm(w_taylor) + 1e-30) <= 1.5)

        # alpha回退
        alpha_best = 1.0
        w_final = w_ai
        ev_final = ev_ai
        final_pass = ai_pass
        used_alpha = False

        if not ai_pass:
            # 搜索alpha: w = alpha*w_ai + (1-alpha)*w_taylor
            for alpha in [0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1, 0.0]:
                w_mix = alpha * w_ai + (1 - alpha) * w_taylor
                w_mix = normalize_mainlobe(w_mix, px_list[i], py_list[i], pz_list[i], u0, v0, w0)
                ev_mix = eval_pattern(w_mix, px_list[i], py_list[i], pz_list[i], th0, ph0, nd)
                mix_pass = (ev_mix['pt'] <= 1.0 and ev_mix['pr'] <= 1.001 and
                           ev_mix['wn'] <= -EPS_NULL_CHECK_DB and
                           ev_mix['sll'] - t_slls[i] <= -0.5 and
                           np.linalg.norm(w_mix) / (np.linalg.norm(w_taylor) + 1e-30) <= 1.5)
                if mix_pass:
                    alpha_best = alpha
                    w_final = w_mix
                    ev_final = ev_mix
                    final_pass = True
                    used_alpha = True
                    break
            if not final_pass:
                # 回退Taylor
                w_final = w_taylor
                ev_final = eval_pattern(w_taylor, px_list[i], py_list[i], pz_list[i], th0, ph0, nd)
                alpha_best = 0.0
                used_alpha = True

        results.append({
            'idx': i, 'theta0': th0, 'phi0': ph0,
            'taylor_sll': float(t_slls[i]),
            'ai_sll': float(ev_ai['sll']),
            'final_sll': float(ev_final['sll']),
            'improvement': float(ev_final['sll'] - t_slls[i]),
            'pt': float(ev_final['pt']), 'peak': float(ev_final['pr']),
            'worst_null': float(ev_final['wn']),
            'norm_ratio': float(np.linalg.norm(w_final) / (np.linalg.norm(w_taylor) + 1e-30)),
            'main_err': float(abs(ev_final['mr'] - 1.0)),
            'ai_pass': bool(ai_pass), 'final_pass': bool(final_pass),
            'alpha': float(alpha_best), 'used_alpha': bool(used_alpha),
            'w_re': w_final.real.tolist(),
            'w_im': w_final.imag.tolist(),
        })

    return results


# ============================================================
# 主函数
# ============================================================
def main():
    print('='*70)
    print('8x8 DeepSets Training v5.0')
    print(f'  Hidden={HIDDEN_DIM}, Epochs={EPOCHS}, LR={LR}, Seeds={N_SEEDS}')
    print(f'  AdamW wd={WEIGHT_DECAY}, Patience={PATIENCE}')
    print('='*70)

    device = torch.device('cpu')

    # 加载数据
    w_re, w_im, px_base, py_base, pz_base, labels, qualities, \
        thetas, phis, split, t_sll, f_sll = load_data()

    # 只用valid样本
    valid_mask = labels == 1
    w_re_v = w_re[valid_mask]; w_im_v = w_im[valid_mask]
    th_v = thetas[valid_mask]; ph_v = phis[valid_mask]
    q_v = qualities[valid_mask]; sp_v = split[valid_mask]
    ts_v = t_sll[valid_mask]; fs_v = f_sll[valid_mask]
    parent_ids = np.arange(len(thetas))[valid_mask]

    # 旋转扩增
    (exp_w_re, exp_w_im, exp_th, exp_ph, exp_q, exp_sp,
     exp_ts, exp_fs, exp_pid, exp_px, exp_py, exp_pz) = expand_rotation(
        w_re_v, w_im_v, th_v, ph_v, q_v, sp_v, ts_v, fs_v,
        px_base, py_base, pz_base, parent_ids)

    print(f'After rotation: {len(exp_w_re)} total')
    n_train = np.sum(exp_sp == 0)
    n_val = np.sum(exp_sp == 1)
    n_test = np.sum(exp_sp == 2)
    print(f'  Train: {n_train}, Val: {n_val}, Test: {n_test}')

    # Train标准化参数
    train_mask = exp_sp == 0
    mean_stats = {
        'px_mean': float(exp_px[train_mask].mean()),
        'py_mean': float(exp_py[train_mask].mean()),
        'pz_mean': float(exp_pz[train_mask].mean()),
    }
    std_stats = {
        'px_std': float(exp_px[train_mask].std() + 1e-8),
        'py_std': float(exp_py[train_mask].std() + 1e-8),
        'pz_std': float(exp_pz[train_mask].std() + 1e-8),
    }
    print(f'  Coord mean: {mean_stats}')
    print(f'  Coord std: {std_stats}')

    # 构建特征和目标
    # 注意: Taylor权值 = 原始w_re/w_im (已归一化), SOCP权值在exp_w_re/exp_w_im
    # 残差 = SOCP - Taylor = exp_w - w_taylor
    # 但exp_w_re是SOCP权值(从teacher标签), 需要Taylor基线
    # Taylor基线 = 每个旋转后的坐标对应的Taylor激励
    # 简化: 用exp_w_re作为SOCP, 重新计算Taylor
    from run_teacher_v4 import taylor_2d
    ax, ay = taylor_2d(NX, NY, 30)

    # 为每个扩增样本计算Taylor基线
    taylor_re = np.zeros_like(exp_w_re)
    taylor_im = np.zeros_like(exp_w_im)
    for i in range(len(exp_w_re)):
        px_i = exp_px[i]; py_i = exp_py[i]; pz_i = exp_pz[i]
        th = exp_th[i]; ph = exp_ph[i]
        k = 2 * np.pi
        u0 = np.sin(np.deg2rad(th))*np.cos(np.deg2rad(ph))
        v0 = np.sin(np.deg2rad(th))*np.sin(np.deg2rad(ph))
        w0 = np.cos(np.deg2rad(th))
        amp = np.outer(ay, ax).ravel()
        phase = k * (px_i*u0 + py_i*v0 + pz_i*w0)
        wt = amp * np.exp(1j * phase)
        # 归一化
        a_main = np.exp(1j * k * (px_i*u0 + py_i*v0 + pz_i*w0))
        resp = np.conj(a_main) @ wt
        if np.abs(resp) > 1e-12:
            wt = wt / resp
        taylor_re[i] = wt.real
        taylor_im[i] = wt.imag

    # 特征: 用Taylor权值作为基线输入
    feat = make_features(taylor_re, taylor_im, exp_th, exp_ph,
                         exp_px, exp_py, exp_pz, mean_stats, std_stats)
    # 目标: SOCP - Taylor
    target = make_targets(taylor_re, taylor_im, exp_w_re, exp_w_im)
    # Quality权重
    q_weights = np.where(exp_q == 1, 1.0, 0.7).astype(np.float32)

    # 分割
    train_idx = np.where(exp_sp == 0)[0]
    val_idx = np.where(exp_sp == 1)[0]
    test_idx = np.where(exp_sp == 2)[0]

    train_feat = feat[train_idx]; train_target = target[train_idx]
    train_qw = q_weights[train_idx]
    val_feat = feat[val_idx]; val_target = target[val_idx]
    val_qw = q_weights[val_idx]
    test_feat = feat[test_idx]

    print(f'\nTrain: {len(train_feat)}, Val: {len(val_feat)}, Test: {len(test_feat)}')

    # ============================================================
    # 训练3个种子
    # ============================================================
    all_results = {}
    best_seed = None
    best_val_loss = float('inf')

    for seed in [42, 123, 777]:
        print(f'\n{"="*50}')
        print(f'Training seed={seed}')
        print(f'{"="*50}')

        t0 = time.perf_counter()
        model, val_loss, history, n_ep = train_one_seed(
            seed, train_feat, train_target, train_qw,
            val_feat, val_target, val_qw, device)
        train_time = time.perf_counter() - t0

        print(f'  Seed {seed}: {n_ep} epochs, {train_time:.1f}s, val_loss={val_loss:.6f}')

        # 保存模型
        model_path = os.path.join(OUTPUT_DIR, f'deepsets_8x8_v5_seed{seed}.pt')
        torch.save(model.state_dict(), model_path)

        all_results[seed] = {
            'val_loss': float(val_loss), 'train_time': float(train_time),
            'epochs': n_ep, 'model_path': model_path,
            'history': history,
        }

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_seed = seed

    print(f'\nBest seed: {best_seed} (val_loss={best_val_loss:.6f})')

    # ============================================================
    # 用最优种子评估
    # ============================================================
    print(f'\n{"="*70}')
    print(f'Evaluation with best seed={best_seed}')
    print(f'{"="*70}')

    best_model = DeepSetsV2(9, HIDDEN_DIM, 2).to(device)
    best_model.load_state_dict(torch.load(all_results[best_seed]['model_path'], map_location='cpu'))
    best_model.eval()

    # Block Val评估
    print('\n--- Block Val ---')
    val_results = evaluate_model(
        best_model, val_feat, taylor_re[val_idx], taylor_im[val_idx],
        exp_th[val_idx], exp_ph[val_idx],
        exp_px[val_idx], exp_py[val_idx], exp_pz[val_idx],
        exp_ts[val_idx], device)

    n_pass = sum(1 for r in val_results if r['final_pass'])
    print(f'  Pass: {n_pass}/{len(val_results)} ({n_pass/len(val_results)*100:.0f}%)')
    print(f'  Mean improvement: {np.mean([r["improvement"] for r in val_results]):+.2f} dB')
    print(f'  Alpha fallback: {sum(1 for r in val_results if r["used_alpha"])}/{len(val_results)}')

    # Block Test评估(只评估一次)
    print('\n--- Block Test ---')
    test_results = evaluate_model(
        best_model, test_feat, taylor_re[test_idx], taylor_im[test_idx],
        exp_th[test_idx], exp_ph[test_idx],
        exp_px[test_idx], exp_py[test_idx], exp_pz[test_idx],
        exp_ts[test_idx], device)

    n_test_pass = sum(1 for r in test_results if r['final_pass'])
    test_pass_rate = n_test_pass / len(test_results) * 100
    print(f'  Pass: {n_test_pass}/{len(test_results)} ({test_pass_rate:.0f}%)')
    print(f'  Mean improvement: {np.mean([r["improvement"] for r in test_results]):+.2f} dB')
    print(f'  Alpha fallback: {sum(1 for r in test_results if r["used_alpha"])}/{len(test_results)}')

    # 高角度报告
    high_angle = [r for r in test_results if r['theta0'] >= 50]
    if high_angle:
        ha_pass = sum(1 for r in high_angle if r['final_pass'])
        print(f'  High angle (>=50°): {ha_pass}/{len(high_angle)} pass')

    # SLL差值中位数
    # 需要SOCP SLL作为参考
    socp_slls = exp_fs[test_idx]
    ai_slls = [r['final_sll'] for r in test_results]
    sll_diffs = [a - s for a, s in zip(ai_slls, socp_slls)]
    print(f'  SLL diff (AI-SOCP) median: {np.median(sll_diffs):.2f} dB')

    # Random IID test
    print('\n--- Random IID Test ---')
    rt_npz = np.load(os.path.join(OUTPUT_DIR, 'random_iid_test_v4_2.npz'), allow_pickle=True)
    rt_w_re = rt_npz['w_re']; rt_w_im = rt_npz['w_im']
    rt_th = rt_npz['thetas']; rt_ph = rt_npz['phis']
    rt_labels = rt_npz['labels']
    rt_t_sll = rt_npz['taylor_sll']
    rt_px = rt_npz['px']; rt_py = rt_npz['py']; rt_pz = rt_npz['pz']

    # 计算random test的Taylor基线
    rt_taylor_re = np.zeros_like(rt_w_re)
    rt_taylor_im = np.zeros_like(rt_w_im)
    for i in range(len(rt_w_re)):
        px_i = rt_px[i] if rt_px.ndim > 1 else rt_px
        py_i = rt_py[i] if rt_py.ndim > 1 else rt_py
        pz_i = rt_pz[i] if rt_pz.ndim > 1 else rt_pz
        th = float(rt_th[i]); ph = float(rt_ph[i])
        k = 2 * np.pi
        u0 = np.sin(np.deg2rad(th))*np.cos(np.deg2rad(ph))
        v0 = np.sin(np.deg2rad(th))*np.sin(np.deg2rad(ph))
        w0 = np.cos(np.deg2rad(th))
        amp = np.outer(ay, ax).ravel()
        phase = k * (px_i*u0 + py_i*v0 + pz_i*w0)
        wt = amp * np.exp(1j * phase)
        a_main = np.exp(1j * k * (px_i*u0 + py_i*v0 + pz_i*w0))
        resp = np.conj(a_main) @ wt
        if np.abs(resp) > 1e-12: wt = wt / resp
        rt_taylor_re[i] = wt.real
        rt_taylor_im[i] = wt.imag

    rt_feat = make_features(rt_taylor_re, rt_taylor_im, rt_th, rt_ph,
                            np.broadcast_to(rt_px, (len(rt_th), N_ELEM)),
                            np.broadcast_to(rt_py, (len(rt_th), N_ELEM)),
                            np.broadcast_to(rt_pz, (len(rt_th), N_ELEM)),
                            mean_stats, std_stats)

    rt_results = evaluate_model(
        best_model, rt_feat, rt_taylor_re, rt_taylor_im,
        rt_th, rt_ph,
        np.broadcast_to(rt_px, (len(rt_th), N_ELEM)),
        np.broadcast_to(rt_py, (len(rt_th), N_ELEM)),
        np.broadcast_to(rt_pz, (len(rt_th), N_ELEM)),
        rt_t_sll, device)

    # 只在valid方向统计
    rt_valid = [r for r, l in zip(rt_results, rt_labels) if l == 1]
    rt_pass = sum(1 for r in rt_valid if r['final_pass'])
    rt_pass_rate = rt_pass / len(rt_valid) * 100 if rt_valid else 0
    print(f'  Valid: {len(rt_valid)}, Pass: {rt_pass} ({rt_pass_rate:.0f}%)')
    print(f'  Mean improvement: {np.mean([r["improvement"] for r in rt_valid]):+.2f} dB')

    # 非valid方向拒识检查
    rt_invalid = [r for r, l in zip(rt_results, rt_labels) if l != 1]
    print(f'  Invalid directions (should fallback): {len(rt_invalid)}')
    n_fb = sum(1 for r in rt_invalid if r['alpha'] == 0.0)
    print(f'  Taylor fallback: {n_fb}/{len(rt_invalid)}')

    # ============================================================
    # 门槛检查
    # ============================================================
    print(f'\n{"="*70}')
    print('GATE CHECK')
    print(f'{"="*70}')
    print(f'  Block Test pass rate: {test_pass_rate:.0f}% (target >=80%): {"PASS" if test_pass_rate >= 80 else "FAIL"}')
    print(f'  Random IID valid pass rate: {rt_pass_rate:.0f}% (target >=85%): {"PASS" if rt_pass_rate >= 85 else "FAIL"}')
    print(f'  SLL diff median: {np.median(sll_diffs):.2f} dB (target <=2dB): {"PASS" if abs(np.median(sll_diffs)) <= 2 else "FAIL"}')

    # ============================================================
    # 保存
    # ============================================================
    # 最优模型
    best_path = os.path.join(OUTPUT_DIR, 'deepsets_8x8_v5_best.pt')
    torch.save(best_model.state_dict(), best_path)

    # 配置
    config = {
        'hidden_dim': HIDDEN_DIM, 'epochs': EPOCHS, 'batch_size': BATCH_SIZE,
        'lr': LR, 'weight_decay': WEIGHT_DECAY, 'patience': PATIENCE,
        'n_seeds': N_SEEDS, 'best_seed': best_seed,
        'weight_scale': WEIGHT_SCALE, 'coord_norm': COORD_NORM,
        'mean_stats': mean_stats, 'std_stats': std_stats,
        'versions': {
            'python': sys.version.split()[0],
            'pytorch': torch.__version__,
            'numpy': np.__version__,
        },
    }
    config_path = os.path.join(OUTPUT_DIR, 'config_v5.json')
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)

    # 结果JSON
    results_json = {
        'seeds': {str(k): {kk: vv for kk, vv in v.items() if kk != 'history'}
                  for k, v in all_results.items()},
        'best_seed': best_seed,
        'block_val': val_results,
        'block_test': test_results,
        'random_iid': rt_results,
        'gate': {
            'block_test_pass': float(test_pass_rate),
            'random_iid_pass': float(rt_pass_rate),
            'sll_diff_median': float(np.median(sll_diffs)),
        },
    }
    res_path = os.path.join(OUTPUT_DIR, 'results_v5.json')
    with open(res_path, 'w') as f:
        json.dump(results_json, f, indent=2, default=str)

    # 预测权值NPZ
    pred_w_re = np.array([[r['w_re'][j] for j in range(N_ELEM)] for r in test_results])
    pred_w_im = np.array([[r['w_im'][j] for j in range(N_ELEM)] for r in test_results])
    pred_npz = os.path.join(OUTPUT_DIR, 'predictions_v5.npz')
    np.savez(pred_npz, w_re=pred_w_re, w_im=pred_w_im,
             thetas=exp_th[test_idx], phis=exp_ph[test_idx])

    # SHA-256
    import hashlib
    sha_list = {}
    for name, path in [('deepsets_8x8_v5_best.pt', best_path),
                        ('config_v5.json', config_path),
                        ('results_v5.json', res_path),
                        ('predictions_v5.npz', pred_npz)]:
        with open(path, 'rb') as f:
            sha = hashlib.sha256(f.read()).hexdigest()
        sha_list[name] = sha
        print(f'  {name}: {sha}')

    with open(os.path.join(OUTPUT_DIR, 'sha256_v5.txt'), 'w') as f:
        for name, sha in sha_list.items():
            f.write(f'{name}: {sha}\n')

    print(f'\n{"="*70}')
    print('DONE')
    print(f'{"="*70}')


if __name__ == '__main__':
    main()
