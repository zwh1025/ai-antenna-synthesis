"""v4.2: 修正block划分 + 补全random test

修复:
  1. group不可拆分: 整组分配Train/Val/Test/Guard
  2. group集合两两不相交
  3. 保护带用d<=1.000001°
  4. 从split_v4_1.npz直接读取(不重算教师)
  5. random test补全label/quality/指标
  6. 原20随机方向保持不变, 命名random_iid_test
"""

import os, sys, time, json, hashlib
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(BASE_DIR, 'mylib'))
OUTPUT_DIR = os.path.join(BASE_DIR, 'output')

N_ELEM = 64


def angular_dist_deg(th1, ph1, th2, ph2):
    t1, p1 = np.deg2rad(th1), np.deg2rad(ph1)
    t2, p2 = np.deg2rad(th2), np.deg2rad(ph2)
    cos_d = np.cos(t1)*np.cos(t2) + np.sin(t1)*np.sin(t2)*np.cos(p1-p2)
    return float(np.rad2deg(np.arccos(np.clip(cos_d, -1, 1))))


def get_group_id(theta, phi):
    return f'th{int(theta // 5):02d}_ph{int(phi // 10):02d}'


def main():
    print('='*70)
    print('v4.2: Block Split Fix')
    print('='*70)

    # ============================================================
    # 加载v4.1数据(含权值和元数据)
    # ============================================================
    npz_path = os.path.join(OUTPUT_DIR, 'split_v4_1.npz')
    data = np.load(npz_path, allow_pickle=True)

    w_re = data['w_re']; w_im = data['w_im']
    px = data['px']; py = data['py']; pz = data['pz']
    labels = data['labels']  # 1=valid
    qualities = data['qualities']  # 1=A, 2=B
    thetas = data['thetas']; phis = data['phis']
    t_slls = data['taylor_sll']; f_slls = data['final_sll']

    n_total = len(thetas)
    print(f'Loaded {n_total} samples from split_v4_1.npz')

    # 加载v4.1 JSON获取完整样本信息
    with open(os.path.join(OUTPUT_DIR, 'split_v4_1.json')) as f:
        v4_1 = json.load(f)

    # 加载random test
    with open(os.path.join(OUTPUT_DIR, 'random_test_v4_1.json')) as f:
        rt_data = json.load(f)
    rt_npz = np.load(os.path.join(OUTPUT_DIR, 'random_test_v4_1.npz'), allow_pickle=True)

    # ============================================================
    # 1. 构建group (整组不可拆分)
    # ============================================================
    valid_indices = [i for i in range(n_total) if labels[i] == 1]
    print(f'Valid samples: {len(valid_indices)}')

    from collections import defaultdict
    group_valid = defaultdict(list)
    for i in valid_indices:
        gid = get_group_id(float(thetas[i]), float(phis[i]))
        group_valid[gid].append(i)

    # 每个group的质量统计
    group_info = {}
    for gid, indices in group_valid.items():
        n_a = sum(1 for i in indices if qualities[i] == 1)
        n_b = sum(1 for i in indices if qualities[i] == 2)
        th_range = (min(thetas[i] for i in indices), max(thetas[i] for i in indices))
        ph_range = (min(phis[i] for i in indices), max(phis[i] for i in indices))
        group_info[gid] = {
            'n': len(indices), 'A': n_a, 'B': n_b,
            'th_range': th_range, 'ph_range': ph_range,
            'indices': indices,
        }

    print(f'Total groups: {len(group_info)}')

    # ============================================================
    # 2. 整组分配: Val/Test各约32-64, 覆盖不同θ/φ和A/B
    # ============================================================
    rng = np.random.RandomState(777)
    all_groups = sorted(group_info.keys())
    rng.shuffle(all_groups)

    # 分配策略: 交替分配整组到val和test
    val_groups = []
    test_groups = []
    val_samples = []
    test_samples = []
    used_groups = set()

    for g in all_groups:
        n_in_group = group_info[g]['n']
        has_a = group_info[g]['A'] > 0
        has_b = group_info[g]['B'] > 0

        # 目标: val 32-64, test 32-64
        if len(val_samples) < 32:
            val_groups.append(g)
            val_samples.extend(group_info[g]['indices'])
            used_groups.add(g)
        elif len(test_samples) < 32:
            test_groups.append(g)
            test_samples.extend(group_info[g]['indices'])
            used_groups.add(g)
        elif len(val_samples) < 64 and len(test_samples) >= 32:
            # 继续补充val到64
            val_groups.append(g)
            val_samples.extend(group_info[g]['indices'])
            used_groups.add(g)
        elif len(test_samples) < 64 and len(val_samples) >= 32:
            test_groups.append(g)
            test_samples.extend(group_info[g]['indices'])
            used_groups.add(g)

    # 剩余group的valid样本为train候选
    train_candidates = []
    train_groups = []
    for g in all_groups:
        if g not in used_groups:
            train_groups.append(g)
            train_candidates.extend(group_info[g]['indices'])

    print(f'\nGroup allocation:')
    print(f'  Val groups: {len(val_groups)}, samples: {len(val_samples)}')
    print(f'  Test groups: {len(test_groups)}, samples: {len(test_samples)}')
    print(f'  Train candidate groups: {len(train_groups)}, samples: {len(train_candidates)}')

    # ============================================================
    # 3. 验证group集合不相交
    # ============================================================
    val_g_set = set(val_groups)
    test_g_set = set(test_groups)
    train_g_set = set(train_groups)

    vt_intersect = val_g_set & test_g_set
    vtr_intersect = val_g_set & train_g_set
    ttr_intersect = test_g_set & train_g_set

    print(f'\nGroup intersection check:')
    print(f'  Val ∩ Test: {vt_intersect if vt_intersect else "EMPTY"}')
    print(f'  Val ∩ Train: {vtr_intersect if vtr_intersect else "EMPTY"}')
    print(f'  Test ∩ Train: {ttr_intersect if ttr_intersect else "EMPTY"}')

    assert not vt_intersect, 'Val-Test group intersection!'
    assert not vtr_intersect, 'Val-Train group intersection!'
    assert not ttr_intersect, 'Test-Train group intersection!'

    # ============================================================
    # 4. 保护带: d <= 1.000001° 的train候选进入Guard
    # ============================================================
    holdout = val_samples + test_samples
    guard_samples = []

    for i in train_candidates:
        th_i = float(thetas[i]); ph_i = float(phis[i])
        for j in holdout:
            d = angular_dist_deg(th_i, ph_i, float(thetas[j]), float(phis[j]))
            if d <= 1.000001:
                guard_samples.append(i)
                break

    guard_set = set(guard_samples)
    train_samples = [i for i in train_candidates if i not in guard_set]

    print(f'\nProtection band (d <= 1.000001 deg):')
    print(f'  Guard: {len(guard_samples)}')
    print(f'  Train: {len(train_samples)}')

    # 验证所有val/test到train距离 > 1°
    min_val_dist = min(
        min(angular_dist_deg(float(thetas[i]), float(phis[i]),
                             float(thetas[j]), float(phis[j]))
            for j in train_samples)
        for i in val_samples)
    min_test_dist = min(
        min(angular_dist_deg(float(thetas[i]), float(phis[i]),
                             float(thetas[j]), float(phis[j]))
            for j in train_samples)
        for i in test_samples)

    print(f'  Val min dist to train: {min_val_dist:.6f}° (>1°: {"YES" if min_val_dist > 1.0 else "NO"})')
    print(f'  Test min dist to train: {min_test_dist:.6f}° (>1°: {"YES" if min_test_dist > 1.0 else "NO"})')

    # ============================================================
    # 5. 统计
    # ============================================================
    def stats(indices):
        n_a = sum(1 for i in indices if qualities[i] == 1)
        n_b = sum(1 for i in indices if qualities[i] == 2)
        ths = [float(thetas[i]) for i in indices]
        th_dist = {}
        for th in ths:
            b = int(th // 10) * 10
            th_dist[b] = th_dist.get(b, 0) + 1
        return {'n': len(indices), 'A': n_a, 'B': n_b, 'theta_dist': th_dist}

    train_stats = stats(train_samples)
    val_stats = stats(val_samples)
    test_stats = stats(test_samples)
    guard_stats = stats(guard_samples)

    print(f'\nSplit statistics:')
    print(f'  Train: {train_stats["n"]} (A={train_stats["A"]}, B={train_stats["B"]}) θ={train_stats["theta_dist"]}')
    print(f'  Val:   {val_stats["n"]} (A={val_stats["A"]}, B={val_stats["B"]}) θ={val_stats["theta_dist"]}')
    print(f'  Test:  {test_stats["n"]} (A={test_stats["A"]}, B={test_stats["B"]}) θ={test_stats["theta_dist"]}')
    print(f'  Guard: {guard_stats["n"]}')
    print(f'  After rotation: train~{train_stats["n"]*4}, val~{val_stats["n"]*4}, test~{test_stats["n"]*4}')

    # 每个val/test到最近train的距离
    val_dists = []
    for i in val_samples:
        min_d = min(angular_dist_deg(float(thetas[i]), float(phis[i]),
                                      float(thetas[j]), float(phis[j]))
                    for j in train_samples)
        val_dists.append(min_d)

    test_dists = []
    for i in test_samples:
        min_d = min(angular_dist_deg(float(thetas[i]), float(phis[i]),
                                      float(thetas[j]), float(phis[j]))
                    for j in train_samples)
        test_dists.append(min_d)

    print(f'\nVal nearest train: min={min(val_dists):.4f} med={np.median(val_dists):.4f} max={max(val_dists):.4f}')
    print(f'Test nearest train: min={min(test_dists):.4f} med={np.median(test_dists):.4f} max={max(test_dists):.4f}')

    # ============================================================
    # 6. 保存划分
    # ============================================================
    # split数组: 0=train, 1=block_val, 2=block_test, 3=guard, -1=invalid
    split_arr = np.full(n_total, -1, dtype=np.int32)
    for i in train_samples: split_arr[i] = 0
    for i in val_samples: split_arr[i] = 1
    for i in test_samples: split_arr[i] = 2
    for i in guard_samples: split_arr[i] = 3

    # group_ids
    group_ids = [get_group_id(float(thetas[i]), float(phis[i])) for i in range(n_total)]

    # JSON
    split_info = {
        'version': 'v4.2',
        'n_total': n_total,
        'n_valid': len(valid_indices),
        'splits': {
            'train': {**train_stats, 'groups': train_groups, 'indices': train_samples},
            'block_val': {**val_stats, 'groups': val_groups, 'indices': val_samples,
                          'nearest_train_dist': {
                              'min': float(min(val_dists)),
                              'median': float(np.median(val_dists)),
                              'max': float(max(val_dists)),
                              'all': [float(d) for d in val_dists],
                          }},
            'block_test': {**test_stats, 'groups': test_groups, 'indices': test_samples,
                           'nearest_train_dist': {
                               'min': float(min(test_dists)),
                               'median': float(np.median(test_dists)),
                               'max': float(max(test_dists)),
                               'all': [float(d) for d in test_dists],
                           }},
            'guard': {**guard_stats, 'indices': guard_samples},
        },
        'group_intersection': {
            'val_test': list(vt_intersect),
            'val_train': list(vtr_intersect),
            'test_train': list(ttr_intersect),
        },
        'protection_band_deg': 1.000001,
        'val_min_dist_to_train': float(min_val_dist),
        'test_min_dist_to_train': float(min_test_dist),
    }

    # 每个样本信息
    sample_list = []
    for i in range(n_total):
        sample_list.append({
            'idx': i,
            'theta0': float(thetas[i]),
            'phi0': float(phis[i]),
            'group_id': group_ids[i],
            'split': int(split_arr[i]),
            'label': 'valid' if labels[i] == 1 else 'invalid',
            'quality': 'A' if qualities[i] == 1 else ('B' if qualities[i] == 2 else ''),
            'taylor_sll': float(t_slls[i]),
            'final_sll': float(f_slls[i]),
        })
    split_info['samples'] = sample_list

    out_json = os.path.join(OUTPUT_DIR, 'split_v4_2.json')
    with open(out_json, 'w') as f:
        json.dump(split_info, f, indent=2, default=str)

    # NPZ
    out_npz = os.path.join(OUTPUT_DIR, 'split_v4_2.npz')
    np.savez(out_npz,
             w_re=w_re, w_im=w_im,
             px=px, py=py, pz=pz,
             labels=labels, qualities=qualities,
             thetas=thetas, phis=phis,
             taylor_sll=t_slls, final_sll=f_slls,
             split=split_arr,
             group_ids=np.array(group_ids),
             train_idx=np.array(train_samples),
             val_idx=np.array(val_samples),
             test_idx=np.array(test_samples),
             guard_idx=np.array(guard_samples),
             )

    with open(out_json, 'rb') as f:
        json_sha = hashlib.sha256(f.read()).hexdigest()
    with open(out_npz, 'rb') as f:
        npz_sha = hashlib.sha256(f.read()).hexdigest()

    print(f'\nJSON: {out_json} (SHA: {json_sha})')
    print(f'NPZ: {out_npz} (SHA: {npz_sha})')

    # ============================================================
    # 7. 补全random test (命名random_iid_test)
    # ============================================================
    print(f'\n{"="*70}')
    print('Random IID Test (20 directions, from v4.1)')
    print(f'{"="*70}')

    # 补全label/quality/指标到NPZ
    rt_results = rt_data['results']
    rt_labels = np.array([1 if r['label'] == 'valid' else 0 for r in rt_results])
    rt_qualities = np.array([1 if r.get('quality') == 'A' else (2 if r.get('quality') == 'B' else 0) for r in rt_results])
    rt_thetas = np.array([r['theta0'] for r in rt_results])
    rt_phis = np.array([r['phi0'] for r in rt_results])
    rt_t_sll = np.array([r['taylor_sll'] for r in rt_results])
    rt_f_sll = np.array([r['final_sll'] for r in rt_results])
    rt_pt = np.array([r['pt'] for r in rt_results])
    rt_peak = np.array([r['peak'] for r in rt_results])
    rt_null = np.array([r['worst_null'] for r in rt_results])
    rt_imp = np.array([r['improvement'] for r in rt_results])
    rt_nr = np.array([r['norm_ratio'] for r in rt_results])
    rt_me = np.array([r['main_err'] for r in rt_results])

    # 保存完整NPZ
    rt_npz_out = os.path.join(OUTPUT_DIR, 'random_iid_test_v4_2.npz')
    np.savez(rt_npz_out,
             w_re=rt_npz['w_re'], w_im=rt_npz['w_im'],
             px=px, py=py, pz=pz,
             thetas=rt_thetas, phis=rt_phis,
             labels=rt_labels, qualities=rt_qualities,
             taylor_sll=rt_t_sll, final_sll=rt_f_sll,
             pointing_err=rt_pt, peak_ratio=rt_peak,
             worst_null=rt_null, improvement=rt_imp,
             norm_ratio=rt_nr, main_err=rt_me,
             )

    # JSON重命名
    rt_json_out = os.path.join(OUTPUT_DIR, 'random_iid_test_v4_2.json')
    with open(rt_json_out, 'w') as f:
        json.dump({'results': rt_results, 'name': 'random_iid_test'}, f, indent=2, default=str)

    with open(rt_json_out, 'rb') as f:
        rt_json_sha = hashlib.sha256(f.read()).hexdigest()
    with open(rt_npz_out, 'rb') as f:
        rt_npz_sha = hashlib.sha256(f.read()).hexdigest()

    n_rt_valid = sum(rt_labels)
    n_rt_a = sum(1 for q in rt_qualities if q == 1)
    print(f'Random IID test: {n_rt_valid} valid, {n_rt_a} quality_A')
    print(f'JSON: {rt_json_out} (SHA: {rt_json_sha})')
    print(f'NPZ: {rt_npz_out} (SHA: {rt_npz_sha})')

    # ============================================================
    # SHA-256 SUMMARY
    # ============================================================
    print(f'\n{"="*70}')
    print('SHA-256 SUMMARY')
    print(f'{"="*70}')
    print(f'split_v4_2.json:           {json_sha}')
    print(f'split_v4_2.npz:            {npz_sha}')
    print(f'random_iid_test_v4_2.json: {rt_json_sha}')
    print(f'random_iid_test_v4_2.npz:  {rt_npz_sha}')
    print(f'{"="*70}')


if __name__ == '__main__':
    main()
