"""8×8曲面阵列 SOCP教师标签生成（严格质检版）。

修改点：
  1. 33个唯一扫描方向：θ=0°只用φ=0°，其余θ用8个φ
  2. 信赖域约束：||w - w_taylor|| <= r 且 ||w|| <= 1.5*||w_taylor||
  3. 密集验证+峰值抑制：全局峰值偏移>1°或超主瓣1.001倍时加约束
  4. 标签验收：主瓣误差<1e-3、指向≤1°、零陷≤-28dB、范数≤1.5x、改善≥0.5dB
  5. 不合格标记为invalid/fallback_taylor
  6. 输出完整诊断（不训练DeepSets）
"""

import os, sys, time, json, csv
import numpy as np
import cvxpy as cp

sys.path.insert(0, '/mnt/workspace/gitCode/cann/tiaozhansai/project')
from mylib.antenna_calc import taylor_2d_separable, angular_distance_deg
from run_8x8_teacher import (
    load_real_coordinates, steering_vec_3d, coordinate_taylor_3d,
    normalize_weights, uv_to_uvw, get_null_dirs,
)

OUTPUT_DIR = '/mnt/workspace/gitCode/cann/tiaozhansai/revision/results'
os.makedirs(OUTPUT_DIR, exist_ok=True)

LAMBDA_MM = 23.9834
NX = NY = 8
N_ELEM = 64
SLL_DESIGN = 30
FREQ_GHZ = 12.5
EPS_NULL = 0.0398  # -28dB
N_COARSE = 11
N_CUTTING_ITERS = 10
N_EVAL = 81

# 信赖域参数
NORM_RATIO = 1.5  # ||w|| <= 1.5 * ||w_taylor||
TRUST_RADIUS_FACTOR = 0.3  # ||w - w_taylor|| <= 0.3 * ||w_taylor||


# 33个唯一扫描方向
SCAN_DIRS = [(0.0, 0.0)]
for th in [15.0, 30.0, 45.0, 60.0]:
    for ph in [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0]:
        SCAN_DIRS.append((th, ph))


def solve_socp_with_trust(px, py, pz, u0, v0, w0,
                           sl_u, sl_v, sl_w,
                           null_u, null_v, null_w,
                           w_taylor, w_taylor_norm,
                           peak_constraints=None):
    """带信赖域和峰值约束的SOCP求解。"""
    n = len(px)
    w = cp.Variable(n, complex=True)
    t = cp.Variable()

    a_main = steering_vec_3d(px, py, pz, u0, v0, w0)
    constraints = [a_main.conj() @ w == 1.0 + 0j]

    for u_s, v_s, w_s in zip(sl_u, sl_v, sl_w):
        a_sl = steering_vec_3d(px, py, pz, u_s, v_s, w_s)
        constraints.append(cp.norm(a_sl.conj() @ w, 2) <= t)

    for u_n, v_n, w_n in zip(null_u, null_v, null_w):
        a_n = steering_vec_3d(px, py, pz, u_n, v_n, w_n)
        constraints.append(cp.norm(a_n.conj() @ w, 2) <= EPS_NULL)

    # 信赖域
    w_taylor_re = w_taylor_norm.real
    w_taylor_im = w_taylor_norm.imag
    trust_r = TRUST_RADIUS_FACTOR * np.linalg.norm(w_taylor_norm)
    norm_max = NORM_RATIO * np.linalg.norm(w_taylor_norm)

    # ||w - w_taylor|| <= trust_r (用实部虚部分解)
    w_diff = w - (w_taylor_re + 1j * w_taylor_im)
    constraints.append(cp.norm(w_diff, 2) <= trust_r)
    constraints.append(cp.norm(w, 2) <= norm_max)

    # 峰值抑制约束
    if peak_constraints:
        for u_p, v_p, w_p in peak_constraints:
            a_p = steering_vec_3d(px, py, pz, u_p, v_p, w_p)
            constraints.append(cp.norm(a_p.conj() @ w, 2) <= 1.0)

    prob = cp.Problem(cp.Minimize(t), constraints)
    try:
        prob.solve(solver=cp.SCS, verbose=False, max_iters=20000)
        if prob.status not in ['optimal', 'optimal_inaccurate']:
            return None, prob.status
    except Exception as e:
        return None, str(e)
    return w.value, prob.status


def eval_full_3d(w, px, py, pz, theta0, phi0, null_dirs, n_eval=N_EVAL):
    """81×81全可见域评估，返回SLL/指向误差/主瓣响应/峰值倍率/零陷。"""
    k = 2 * np.pi
    u0 = np.sin(np.deg2rad(theta0)) * np.cos(np.deg2rad(phi0))
    v0 = np.sin(np.deg2rad(theta0)) * np.sin(np.deg2rad(phi0))
    w0 = np.cos(np.deg2rad(theta0))

    u = np.linspace(-1, 1, n_eval)
    v = np.linspace(-1, 1, n_eval)
    ug, vg = np.meshgrid(u, v, indexing='ij')
    vis = (ug**2 + vg**2) <= 1.0
    wg = uv_to_uvw(ug, vg)

    bw = 0.886 * 2.0 / NX * 180 / np.pi
    exc_uv = np.sin(np.deg2rad(3.0 * bw / max(np.cos(np.deg2rad(theta0)), 0.1)))
    dist = np.sqrt((ug - u0)**2 + (vg - v0)**2)
    sl_mask = (dist >= exc_uv) & vis

    vis_flat = vis.ravel()
    ug_flat = ug.ravel()
    vg_flat = vg.ravel()
    wg_flat = wg.ravel()
    pat_all = np.zeros(len(ug_flat))
    for i in range(len(ug_flat)):
        if vis_flat[i]:
            psi = k * (px * ug_flat[i] + py * vg_flat[i] + pz * wg_flat[i])
            pat_all[i] = np.abs(np.sum(np.conj(w) * np.exp(1j * psi)))

    # 主瓣响应
    psi_main = k * (px * u0 + py * v0 + pz * w0)
    main_resp = np.abs(np.sum(np.conj(w) * np.exp(1j * psi_main)))

    # 全局峰值
    peak_idx = np.argmax(pat_all)
    peak_u = ug_flat[peak_idx]
    peak_v = vg_flat[peak_idx]
    peak_val = pat_all[peak_idx]
    peak_ratio = peak_val / (main_resp + 1e-30)

    peak_theta = np.degrees(np.arcsin(np.clip(np.sqrt(peak_u**2 + peak_v**2), 0, 1)))
    peak_phi = np.degrees(np.arctan2(peak_v, peak_u)) % 360
    pt_err = angular_distance_deg(peak_theta, peak_phi, theta0, phi0)

    # SLL
    sl_flat = sl_mask.ravel()
    pat_sl = pat_all[sl_flat]
    sll = 20 * np.log10(np.max(pat_sl) / (main_resp + 1e-30)) if main_resp > 1e-10 else -300

    # 副瓣最差点
    sl_u_flat = ug_flat[sl_flat]
    sl_v_flat = vg_flat[sl_flat]
    sl_w_flat = wg_flat[sl_flat]
    sorted_idx = np.argsort(pat_sl)[::-1][:10]
    worst = [(sl_u_flat[i], sl_v_flat[i], sl_w_flat[i]) for i in sorted_idx]

    # 零陷
    null_results = []
    for tn, pn in null_dirs:
        un = np.sin(np.deg2rad(tn)) * np.cos(np.deg2rad(pn))
        vn = np.sin(np.deg2rad(tn)) * np.sin(np.deg2rad(pn))
        wn = np.cos(np.deg2rad(tn))
        psi_n = k * (px * un + py * vn + pz * wn)
        nd = 20 * np.log10(np.abs(np.sum(np.conj(w) * np.exp(1j * psi_n))) / (main_resp + 1e-30))
        null_results.append(float(nd))

    return {
        'sll': float(sll),
        'pointing_err': float(pt_err),
        'main_resp': float(main_resp),
        'peak_ratio': float(peak_ratio),
        'peak_theta': float(peak_theta),
        'peak_phi': float(peak_phi),
        'worst_null': float(max(null_results)),
        'null_depths': null_results,
        'worst_sidelobes': worst,
    }


def main():
    print('=' * 70)
    print('8x8 SOCP Teacher Generation (Strict QC)')
    print(f'  {len(SCAN_DIRS)} unique scan directions')
    print(f'  Trust region: ||w-w_taylor||<={TRUST_RADIUS_FACTOR}*||w_taylor||')
    print(f'  Norm limit: ||w||<={NORM_RATIO}*||w_taylor||')
    print(f'  Null: <={-20*np.log10(EPS_NULL):.0f}dB')
    print(f'  Acceptance: main_err<1e-3, pt<=1deg, null<=-28dB, norm<=1.5x, improve>=0.5dB')
    print('=' * 70)

    coords, normals = load_real_coordinates()
    px, py, pz = coords[:, 0], coords[:, 1], coords[:, 2]
    amp_x, amp_y = taylor_2d_separable(NX, NY, SLL_DESIGN)

    results = []
    t_start = time.time()

    for i, (theta0, phi0) in enumerate(SCAN_DIRS):
        null_dirs = get_null_dirs(theta0, phi0)
        u0 = np.sin(np.deg2rad(theta0)) * np.cos(np.deg2rad(phi0))
        v0 = np.sin(np.deg2rad(theta0)) * np.sin(np.deg2rad(phi0))
        w0 = np.cos(np.deg2rad(theta0))

        w_taylor = coordinate_taylor_3d(px, py, pz, amp_x, amp_y, theta0, phi0)
        w_taylor_n = normalize_weights(w_taylor, px, py, pz, u0, v0, w0)

        # Taylor评估
        t_eval = eval_full_3d(w_taylor_n, px, py, pz, theta0, phi0, null_dirs)

        null_u = [np.sin(np.deg2rad(tn)) * np.cos(np.deg2rad(pn)) for tn, pn in null_dirs]
        null_v = [np.sin(np.deg2rad(tn)) * np.sin(np.deg2rad(pn)) for tn, pn in null_dirs]
        null_w = [np.cos(np.deg2rad(tn)) for tn, pn in null_dirs]

        # 副瓣约束点
        u_c = np.linspace(-1, 1, N_COARSE)
        v_c = np.linspace(-1, 1, N_COARSE)
        ug_c, vg_c = np.meshgrid(u_c, v_c, indexing='ij')
        vis_c = (ug_c**2 + vg_c**2) <= 1.0
        wg_c = uv_to_uvw(ug_c, vg_c)
        bw = 0.886 * 2.0 / NX * 180 / np.pi
        exc_uv = np.sin(np.deg2rad(3.0 * bw / max(np.cos(np.deg2rad(theta0)), 0.1)))
        dist_c = np.sqrt((ug_c - u0)**2 + (vg_c - v0)**2)
        sl_mask_c = (dist_c >= exc_uv) & vis_c
        sl_u = list(ug_c[sl_mask_c])
        sl_v = list(vg_c[sl_mask_c])
        sl_w = list(wg_c[sl_mask_c])

        # 切平面迭代
        best_sll = t_eval['sll']
        best_w = w_taylor_n.copy()
        best_eval = t_eval
        peak_constraints = []
        solver_status = 'not_attempted'
        n_iters_actual = 0
        w_socp = w_taylor_n.copy()

        for it in range(N_CUTTING_ITERS):
            w_opt, solver_status = solve_socp_with_trust(
                px, py, pz, u0, v0, w0, sl_u, sl_v, sl_w,
                null_u, null_v, null_w,
                w_taylor, w_taylor_n, peak_constraints)

            if w_opt is None:
                break

            w_opt_n = normalize_weights(w_opt, px, py, pz, u0, v0, w0)
            s_eval = eval_full_3d(w_opt_n, px, py, pz, theta0, phi0, null_dirs)
            n_iters_actual = it + 1

            if s_eval['sll'] < best_sll - 0.05:
                best_sll = s_eval['sll']
                best_w = w_opt_n.copy()
                best_eval = s_eval
                w_socp = w_opt_n

            # 检查峰值偏移
            if s_eval['peak_ratio'] > 1.001 or s_eval['pointing_err'] > 1.0:
                peak_u = best_eval.get('peak_theta', 0)
                # 加入峰值约束
                new_peak = None
                if s_eval['pointing_err'] > 1.0:
                    # 找峰值位置
                    peak_u_val = u0 + 0.1 * np.sin(np.deg2rad(s_eval['pointing_err']))
                    peak_v_val = v0
                    new_peak = (peak_u_val, peak_v_val, np.sqrt(max(0, 1 - peak_u_val**2 - peak_v_val**2)))
                if new_peak and len(peak_constraints) < 4:
                    peak_constraints.append(new_peak)

            # 加入最差副瓣点
            for u_w, v_w, w_w in s_eval['worst_sidelobes'][:2]:
                already = any(abs(su - u_w) < 0.01 and abs(sv - v_w) < 0.01
                              for su, sv in zip(sl_u, sl_v))
                if not already:
                    sl_u.append(u_w)
                    sl_v.append(v_w)
                    sl_w.append(w_w)

        # 最终评估
        s_eval = best_eval
        w_final = best_w

        # 验收
        main_err = abs(np.abs(np.conj(steering_vec_3d(px, py, pz, u0, v0, w0)) @ w_final) - 1.0)
        w_norm = np.linalg.norm(w_final)
        t_norm = np.linalg.norm(w_taylor_n)
        norm_ratio = w_norm / (t_norm + 1e-30)
        max_amp = np.max(np.abs(w_final))
        worst_null = s_eval['worst_null']
        improvement = s_eval['sll'] - t_eval['sll']

        valid = True
        issues = []
        if main_err > 1e-3:
            valid = False; issues.append(f'main_err={main_err:.2e}')
        if s_eval['pointing_err'] > 1.0:
            valid = False; issues.append(f'pt_err={s_eval["pointing_err"]:.2f}')
        if worst_null > -28:
            valid = False; issues.append(f'null={worst_null:.1f}dB')
        if norm_ratio > NORM_RATIO:
            valid = False; issues.append(f'norm_ratio={norm_ratio:.2f}')
        if improvement > -0.5:
            valid = False; issues.append(f'improve={improvement:.1f}dB')

        status = 'valid' if valid else ('fallback_taylor' if improvement > 0 else 'invalid')

        r = {
            'idx': i,
            'theta0': float(theta0), 'phi0': float(phi0),
            'taylor_sll': float(t_eval['sll']),
            'socp_sll': float(s_eval['sll']),
            'improvement': float(improvement),
            'taylor_pt': float(t_eval['pointing_err']),
            'socp_pt': float(s_eval['pointing_err']),
            'peak_ratio': float(s_eval['peak_ratio']),
            'worst_null': float(worst_null),
            'null_depths': s_eval['null_depths'],
            'w_norm': float(w_norm),
            't_norm': float(t_norm),
            'norm_ratio': float(norm_ratio),
            'max_amp': float(max_amp),
            'main_err': float(main_err),
            'solver_status': solver_status,
            'n_iters': n_iters_actual,
            'status': status,
            'issues': '; '.join(issues) if issues else '',
        }
        results.append(r)

        print(f'  [{i+1:2d}/{len(SCAN_DIRS)}] th={theta0:.0f} ph={phi0:.0f} '
              f'T={t_eval["sll"]:.1f} S={s_eval["sll"]:.1f} d={improvement:+.1f} '
              f'pt={s_eval["pointing_err"]:.2f} peak={s_eval["peak_ratio"]:.3f} '
              f'null={worst_null:.1f} norm={norm_ratio:.2f} '
              f'iters={n_iters_actual} [{status}]')

    total_time = time.time() - t_start
    n_valid = sum(1 for r in results if r['status'] == 'valid')
    n_fallback = sum(1 for r in results if r['status'] == 'fallback_taylor')
    n_invalid = sum(1 for r in results if r['status'] == 'invalid')

    print(f'\n{"="*70}')
    print(f'SUMMARY: {len(results)} directions, {total_time:.1f}s')
    print(f'  Valid: {n_valid}, Fallback: {n_fallback}, Invalid: {n_invalid}')
    print(f'{"="*70}')
    print(f'{"th":>4} {"ph":>5} {"T_sll":>6} {"S_sll":>6} {"delta":>6} {"pt":>5} {"peak":>6} {"null":>6} {"norm":>5} {"status":>15}')
    print('-' * 75)
    for r in results:
        print(f'{r["theta0"]:>4.0f} {r["phi0"]:>5.0f} {r["taylor_sll"]:>6.1f} {r["socp_sll"]:>6.1f} '
              f'{r["improvement"]:>+6.1f} {r["socp_pt"]:>5.2f} {r["peak_ratio"]:>6.3f} '
              f'{r["worst_null"]:>6.1f} {r["norm_ratio"]:>5.2f} {r["status"]:>15}')

    # 保存
    out_path = os.path.join(OUTPUT_DIR, 'teacher_8x8_qc.json')
    with open(out_path, 'w') as f:
        json.dump({'results': results, 'n_valid': n_valid, 'n_fallback': n_fallback,
                   'n_invalid': n_invalid, 'total_time_s': total_time,
                   'config': {'trust_radius': TRUST_RADIUS_FACTOR,
                              'norm_ratio': NORM_RATIO,
                              'null_threshold_db': 28,
                              'n_iters': N_CUTTING_ITERS}},
                  f, indent=2, default=str)
    print(f'\nSaved: {out_path}')


if __name__ == '__main__':
    main()
