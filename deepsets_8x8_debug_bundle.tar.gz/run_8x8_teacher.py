"""8×8曲面阵列 SOCP教师标签生成 + DeepSets训练。

使用HFSS真实坐标(element_port_map.csv)。
坐标mm→波长归一化(λ=23.9834mm)。
"""

import os, sys, time, json, csv
import numpy as np
import cvxpy as cp

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'project'))
from mylib.antenna_calc import taylor_2d_separable
from mylib.train import get_device

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
PROJECT_DIR = os.path.join(os.path.dirname(BASE_DIR), 'project')
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'results')
os.makedirs(OUTPUT_DIR, exist_ok=True)

# 真实参数
LAMBDA_MM = 23.9834
NX = NY = 8
N_ELEM = 64
SLL_DESIGN = 30  # 8x8阵列用30dB Taylor
FREQ_GHZ = 12.5

# 扫描方向
THETA_CHOICES = [0.0, 15.0, 30.0, 45.0, 60.0]
PHI_CHOICES = [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0]

# SOCP参数
N_COARSE = 11
N_CUTTING_ITERS = 5
EPS_NULL = 0.0316  # -30dB

N_TRAIN = 150
N_VAL = 20
N_TEST = 30


def load_real_coordinates():
    """从CSV加载真实8×8坐标(mm)并转为波长单位。"""
    csv_path = os.path.join(BASE_DIR, 'element_port_map.csv')
    coords = []
    normals = []
    with open(csv_path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            x_mm = float(row['x_mm'])
            y_mm = float(row['y_mm'])
            z_mm = float(row['z_mm'])
            # mm → 波长
            x = x_mm / LAMBDA_MM
            y = y_mm / LAMBDA_MM
            z = z_mm / LAMBDA_MM
            coords.append((x, y, z))
            # 法向向量
            nx = float(row['ew_x'])
            ny = float(row['ew_y'])
            nz = float(row['ew_z'])
            normals.append((nx, ny, nz))
    return np.array(coords), np.array(normals)


def steering_vec_3d(px, py, pz, u, v, w):
    k = 2 * np.pi
    return np.exp(1j * k * (px * u + py * v + pz * w))


def coordinate_taylor_3d(px, py, pz, amp_x, amp_y, theta0, phi0):
    k = 2 * np.pi
    u0 = np.sin(np.deg2rad(theta0)) * np.cos(np.deg2rad(phi0))
    v0 = np.sin(np.deg2rad(theta0)) * np.sin(np.deg2rad(phi0))
    w0 = np.cos(np.deg2rad(theta0))
    amp = np.outer(amp_y, amp_x).ravel()
    phase = k * (px * u0 + py * v0 + pz * w0)
    return amp * np.exp(1j * phase)


def normalize_weights(w, px, py, pz, u0, v0, w0):
    a_main = steering_vec_3d(px, py, pz, u0, v0, w0)
    resp = np.conj(a_main) @ w
    if np.abs(resp) < 1e-12:
        return w
    return w / resp


def uv_to_uvw(u, v):
    w2 = 1.0 - u**2 - v**2
    return np.sqrt(np.maximum(w2, 0))


def get_null_dirs(theta0, phi0):
    if theta0 < 10:
        return [(30, 0), (30, 90), (30, 180), (30, 270)]
    return [
        (theta0, (phi0 + 90) % 360),
        (theta0, (phi0 + 180) % 360),
        (theta0, (phi0 + 270) % 360),
        (min(theta0 + 25, 85), (phi0 + 45) % 360),
    ]


def solve_socp_3d(px, py, pz, u0, v0, w0, sl_u, sl_v, sl_w, null_uv, null_w, eps_null=EPS_NULL):
    n = len(px)
    w = cp.Variable(n, complex=True)
    t = cp.Variable()
    a_main = steering_vec_3d(px, py, pz, u0, v0, w0)
    constraints = [a_main.conj() @ w == 1.0 + 0j]
    for u_s, v_s, w_s in zip(sl_u, sl_v, sl_w):
        a_sl = steering_vec_3d(px, py, pz, u_s, v_s, w_s)
        constraints.append(cp.norm(a_sl.conj() @ w, 2) <= t)
    for u_n, v_n, w_n in zip(null_uv[0], null_uv[1], null_w):
        a_n = steering_vec_3d(px, py, pz, u_n, v_n, w_n)
        constraints.append(cp.norm(a_n.conj() @ w, 2) <= eps_null)
    prob = cp.Problem(cp.Minimize(t), constraints)
    try:
        prob.solve(solver=cp.SCS, verbose=False, max_iters=10000)
        if prob.status not in ['optimal', 'optimal_inaccurate']:
            prob.solve(solver=cp.CLARABEL, verbose=False)
    except Exception:
        return None
    if prob.status not in ['optimal', 'optimal_inaccurate']:
        return None
    return w.value


def eval_dense_3d(w, px, py, pz, theta0, phi0, null_dirs, n_eval=81):
    k = 2 * np.pi
    u0 = np.sin(np.deg2rad(theta0)) * np.cos(np.deg2rad(phi0))
    v0 = np.sin(np.deg2rad(theta0)) * np.sin(np.deg2rad(phi0))
    w0 = np.cos(np.deg2rad(theta0))
    u = np.linspace(-1, 1, n_eval)
    v = np.linspace(-1, 1, n_eval)
    ug, vg = np.meshgrid(u, v, indexing='ij')
    vis = (ug**2 + vg**2) <= 1.0
    wg = uv_to_uvw(ug, vg)
    bw = 0.886 * 2.0 / NX * 180 / np.pi
    exc_uv = np.sin(np.deg2rad(3.0 * bw / max(np.cos(np.deg2rad(theta0)), 0.1)))
    dist = np.sqrt((ug - u0)**2 + (vg - v0)**2)
    sl_mask = (dist >= exc_uv) & vis

    vis_flat = vis.ravel()
    ug_flat = ug.ravel()
    vg_flat = vg.ravel()
    wg_flat = wg.ravel()
    pat_all = np.zeros(len(ug_flat))
    for i in range(len(ug_flat)):
        if vis_flat[i]:
            psi = k * (px * ug_flat[i] + py * vg_flat[i] + pz * wg_flat[i])
            pat_all[i] = np.abs(np.sum(np.conj(w) * np.exp(1j * psi)))

    psi_main = k * (px * u0 + py * v0 + pz * w0)
    main_resp = np.abs(np.sum(np.conj(w) * np.exp(1j * psi_main)))
    if main_resp < 1e-10:
        return float('nan'), 0, []

    sl_flat = sl_mask.ravel()
    pat_sl = pat_all[sl_flat]
    sll = 20 * np.log10(np.max(pat_sl) / (main_resp + 1e-30))

    peak_idx = np.argmax(pat_all)
    peak_u = ug_flat[peak_idx]
    peak_v = vg_flat[peak_idx]
    peak_theta = np.degrees(np.arcsin(np.clip(np.sqrt(peak_u**2 + peak_v**2), 0, 1)))
    peak_phi = np.degrees(np.arctan2(peak_v, peak_u)) % 360

    from mylib.antenna_calc import angular_distance_deg
    pt_err = angular_distance_deg(peak_theta, peak_phi, theta0, phi0)

    sl_u_flat = ug_flat[sl_flat]
    sl_v_flat = vg_flat[sl_flat]
    sl_w_flat = wg_flat[sl_flat]
    sorted_idx = np.argsort(pat_sl)[::-1][:10]
    worst = [(sl_u_flat[i], sl_v_flat[i], sl_w_flat[i]) for i in sorted_idx]

    return sll, pt_err, worst


def run_socp_cutting(px, py, pz, u0, v0, w0, theta0, phi0, null_dirs, sll_taylor, w_taylor_norm):
    null_u = [np.sin(np.deg2rad(tn)) * np.cos(np.deg2rad(pn)) for tn, pn in null_dirs]
    null_v = [np.sin(np.deg2rad(tn)) * np.sin(np.deg2rad(pn)) for tn, pn in null_dirs]
    null_w = [np.cos(np.deg2rad(tn)) for tn, pn in null_dirs]

    u_c = np.linspace(-1, 1, N_COARSE)
    v_c = np.linspace(-1, 1, N_COARSE)
    ug_c, vg_c = np.meshgrid(u_c, v_c, indexing='ij')
    vis_c = (ug_c**2 + vg_c**2) <= 1.0
    wg_c = uv_to_uvw(ug_c, vg_c)
    bw = 0.886 * 2.0 / NX * 180 / np.pi
    exc_uv = np.sin(np.deg2rad(3.0 * bw / max(np.cos(np.deg2rad(theta0)), 0.1)))
    dist_c = np.sqrt((ug_c - u0)**2 + (vg_c - v0)**2)
    sl_mask_c = (dist_c >= exc_uv) & vis_c
    sl_u = list(ug_c[sl_mask_c])
    sl_v = list(vg_c[sl_mask_c])
    sl_w = list(wg_c[sl_mask_c])

    best_sll = sll_taylor
    best_w = w_taylor_norm.copy()

    for it in range(N_CUTTING_ITERS):
        w_opt = solve_socp_3d(px, py, pz, u0, v0, w0, sl_u, sl_v, sl_w,
                              (null_u, null_v), null_w)
        if w_opt is None:
            break
        w_opt = normalize_weights(w_opt, px, py, pz, u0, v0, w0)
        sll_s, pt_s, worst_s = eval_dense_3d(w_opt, px, py, pz, theta0, phi0, null_dirs)
        if not np.isnan(sll_s) and sll_s < best_sll - 0.05:
            best_sll = sll_s
            best_w = w_opt.copy()
        for u_w, v_w, w_w in worst_s:
            already = any(abs(su - u_w) < 0.01 and abs(sv - v_w) < 0.01
                          for su, sv in zip(sl_u, sl_v))
            if not already:
                sl_u.append(u_w)
                sl_v.append(v_w)
                sl_w.append(w_w)

    return best_w, best_sll


def main():
    print('=' * 70)
    print('8x8 HFSS Curved Array: SOCP Teacher + DeepSets Training')
    print(f'  Frequency: {FREQ_GHZ} GHz, Lambda: {LAMBDA_MM} mm')
    print(f'  Array: {NX}x{NY}={N_ELEM} elements')
    print(f'  SOCP: {N_COARSE}x{N_COARSE} grid, {N_CUTTING_ITERS} iters')
    print(f'  Scan: theta={THETA_CHOICES}, phi={PHI_CHOICES}')
    print(f'  Data: {N_TRAIN}+{N_VAL}+{N_TEST}={N_TRAIN+N_VAL+N_TEST} samples')
    print('=' * 70)

    # 加载真实坐标
    coords, normals = load_real_coordinates()
    px = coords[:, 0]
    py = coords[:, 1]
    pz = coords[:, 2]
    print(f'\nReal coordinates loaded: {len(px)} elements')
    print(f'  X: [{px.min():.3f}, {px.max():.3f}] lambda')
    print(f'  Y: [{py.min():.3f}, {py.max():.3f}] lambda')
    print(f'  Z: [{pz.min():.4f}, {pz.max():.4f}] lambda')

    # Taylor激励
    amp_x, amp_y = taylor_2d_separable(NX, NY, SLL_DESIGN)

    # 生成教师标签
    n_total = N_TRAIN + N_VAL + N_TEST
    rng = np.random.RandomState(42)

    all_data = []
    t_start = time.time()

    for i in range(n_total):
        theta0 = rng.choice(THETA_CHOICES)
        phi0 = rng.choice(PHI_CHOICES)
        null_dirs = get_null_dirs(theta0, phi0)

        u0 = np.sin(np.deg2rad(theta0)) * np.cos(np.deg2rad(phi0))
        v0 = np.sin(np.deg2rad(theta0)) * np.sin(np.deg2rad(phi0))
        w0 = np.cos(np.deg2rad(theta0))

        # Taylor基线
        w_taylor = coordinate_taylor_3d(px, py, pz, amp_x, amp_y, theta0, phi0)
        w_taylor_n = normalize_weights(w_taylor, px, py, pz, u0, v0, w0)
        sll_t, _, _ = eval_dense_3d(w_taylor_n, px, py, pz, theta0, phi0, null_dirs)

        # SOCP
        t0 = time.time()
        w_socp, sll_s = run_socp_cutting(
            px, py, pz, u0, v0, w0, theta0, phi0, null_dirs, sll_t, w_taylor_n)
        dt = time.time() - t0

        all_data.append({
            'px': px, 'py': py, 'pz': pz,
            'w_taylor_re': w_taylor_n.real, 'w_taylor_im': w_taylor_n.imag,
            'w_socp_re': w_socp.real, 'w_socp_im': w_socp.imag,
            'sll_taylor': float(sll_t), 'sll_socp': float(sll_s),
            'theta0': float(theta0), 'phi0': float(phi0),
            'u0': float(u0), 'v0': float(v0), 'w0': float(w0),
            'time_s': dt,
        })

        if (i + 1) % 20 == 0:
            elapsed = time.time() - t_start
            eta = (n_total - i - 1) * (elapsed / (i + 1))
            print(f'  [{i+1:3d}/{n_total}] th={theta0:.0f} ph={phi0:.0f} '
                  f't={sll_t:.1f} s={sll_s:.1f} d={sll_s-sll_t:+.1f} '
                  f't={dt:.1f}s ETA={eta:.0f}s')

    total_time = time.time() - t_start
    print(f'\nGeneration complete: {total_time:.1f}s ({total_time/n_total:.1f}s/sample)')

    # 保存
    split = np.zeros(n_total, dtype=np.int32)
    split[:N_TRAIN] = 0
    split[N_TRAIN:N_TRAIN+N_VAL] = 1
    split[N_TRAIN+N_VAL:] = 2

    save_dict = {
        'split': split, 'n_elements': N_ELEM,
        'n_train': N_TRAIN, 'n_val': N_VAL, 'n_test': N_TEST,
        'frequency_ghz': FREQ_GHZ, 'lambda_mm': LAMBDA_MM,
    }
    for key in ['px', 'py', 'pz', 'w_taylor_re', 'w_taylor_im',
                'w_socp_re', 'w_socp_im']:
        save_dict[key] = np.array([s[key] for s in all_data])
    for key in ['sll_taylor', 'sll_socp', 'theta0', 'phi0', 'u0', 'v0', 'w0']:
        save_dict[key] = np.array([s[key] for s in all_data])

    save_path = os.path.join(OUTPUT_DIR, 'teacher_8x8.npz')
    np.savez(save_path, **save_dict)
    print(f'Saved: {save_path}')

    # 汇总
    t_slls = [s['sll_taylor'] for s in all_data]
    s_slls = [s['sll_socp'] for s in all_data]
    print(f'\nSummary:')
    print(f'  Taylor mean SLL: {np.mean(t_slls):.1f} dB')
    print(f'  SOCP mean SLL: {np.mean(s_slls):.1f} dB')
    print(f'  Mean improvement: {np.mean(s_slls)-np.mean(t_slls):+.1f} dB')
    print(f'  Mean time: {np.mean([s["time_s"] for s in all_data]):.2f}s/sample')

    # 按扫描方向统计
    thetas = np.array([s['theta0'] for s in all_data])
    print(f'\nBy scan direction:')
    for th in THETA_CHOICES:
        mask = thetas == th
        n = np.sum(mask)
        if n > 0:
            tm = np.mean([s['sll_taylor'] for s, m in zip(all_data, mask) if m])
            sm = np.mean([s['sll_socp'] for s, m in zip(all_data, mask) if m])
            print(f'  theta={th:.0f}: n={n} taylor={tm:.1f} socp={sm:.1f} delta={sm-tm:+.1f}')

    print(f'\nNext: train DeepSets on teacher_8x8.npz')


if __name__ == '__main__':
    main()
