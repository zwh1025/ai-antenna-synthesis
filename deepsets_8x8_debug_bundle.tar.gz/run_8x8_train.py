"""8×8 DeepSets训练 + 评估。"""

import os, sys, time, json
import numpy as np
import torch
import torch.nn as nn

sys.path.insert(0, '/mnt/workspace/gitCode/cann/tiaozhansai/project')
from mylib.deepsets import DeepSetsModel, count_parameters
from mylib.train import EarlyStopping
from run_8x8_teacher import eval_dense_3d, get_null_dirs, normalize_weights, load_real_coordinates

REVISION_DIR = '/mnt/workspace/gitCode/cann/tiaozhansai/revision'
OUTPUT_DIR = os.path.join(REVISION_DIR, 'results')
WEIGHT_SCALE = 64.0  # N=64
EPOCHS = 500
BATCH_SIZE = 8
LR = 5e-4


def load_data():
    path = os.path.join(OUTPUT_DIR, 'teacher_8x8.npz')
    data = np.load(path)
    split = data['split']
    train_idx = np.where(split == 0)[0]
    val_idx = np.where(split == 1)[0]
    test_idx = np.where(split == 2)[0]

    def make(idx):
        px = data['px'][idx]
        py = data['py'][idx]
        pz = data['pz'][idx]
        w_re = data['w_taylor_re'][idx]
        w_im = data['w_taylor_im'][idx]
        u0 = data['u0'][idx]
        v0 = data['v0'][idx]
        w0 = data['w0'][idx]
        ne = px.shape[1]
        feat = np.stack([
            px, py, pz,
            w_re * WEIGHT_SCALE, w_im * WEIGHT_SCALE,
            u0[:, None].repeat(ne, 1), v0[:, None].repeat(ne, 1),
            w0[:, None].repeat(ne, 1),
            np.full((len(idx), ne), 0.6, dtype=np.float32),
        ], axis=-1).astype(np.float32)
        target = np.stack([
            (data['w_socp_re'][idx] - w_re) * WEIGHT_SCALE,
            (data['w_socp_im'][idx] - w_im) * WEIGHT_SCALE,
        ], axis=-1).astype(np.float32)
        meta = {
            'px': px, 'py': py, 'pz': pz,
            'w_taylor_re': w_re, 'w_taylor_im': w_im,
            'sll_taylor': data['sll_taylor'][idx],
            'sll_socp': data['sll_socp'][idx],
            'theta0': data['theta0'][idx], 'phi0': data['phi0'][idx],
        }
        return feat, target, meta

    return make(train_idx), make(val_idx), make(test_idx)


def train_model(model, train_feat, train_target, val_feat, val_target, device):
    from torch.utils.data import DataLoader, TensorDataset
    model = model.to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', factor=0.5, patience=10)
    early = EarlyStopping(patience=30)
    crit = nn.MSELoss()

    ds = TensorDataset(torch.as_tensor(train_feat), torch.as_tensor(train_target))
    loader = DataLoader(ds, batch_size=BATCH_SIZE, shuffle=True)
    val_x = torch.as_tensor(val_feat, dtype=torch.float32, device=device)
    val_y = torch.as_tensor(val_target, dtype=torch.float32, device=device)

    best_val = float('inf')
    best_state = None

    for epoch in range(EPOCHS):
        model.train()
        for bx, by in loader:
            bx, by = bx.to(device), by.to(device)
            optimizer.zero_grad()
            loss = crit(model(bx), by)
            loss.backward()
            optimizer.step()
        model.eval()
        with torch.no_grad():
            vl = crit(model(val_x), val_y).item()
        scheduler.step(vl)
        if vl < best_val:
            best_val = vl
            best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
        if early.step(vl):
            break
        if (epoch + 1) % 50 == 0:
            print(f'  Epoch {epoch+1}: val_loss={vl:.6f}')

    if best_state:
        model.load_state_dict(best_state)
    return model, best_val, epoch + 1


def evaluate(model, feat, meta, device):
    model.eval()
    results = {}
    for i in range(len(feat)):
        x = torch.as_tensor(feat[i:i+1], dtype=torch.float32, device=device)
        with torch.no_grad():
            delta = model(x)[0].cpu().numpy()
        w_ai = (meta['w_taylor_re'][i] + delta[:, 0] / WEIGHT_SCALE) + \
               1j * (meta['w_taylor_im'][i] + delta[:, 1] / WEIGHT_SCALE)
        th0 = float(meta['theta0'][i])
        ph0 = float(meta['phi0'][i])
        null_dirs = get_null_dirs(th0, ph0)
        sll, _, _ = eval_dense_3d(w_ai, meta['px'][i], meta['py'][i],
                                   meta['pz'][i], th0, ph0, null_dirs)
        sll_val = float(sll) if not np.isnan(sll) else -100.0
        th_key = int(th0)
        if th_key not in results:
            results[th_key] = {'sll_ai': [], 'sll_t': [], 'sll_s': []}
        results[th_key]['sll_ai'].append(sll_val)
        results[th_key]['sll_t'].append(float(meta['sll_taylor'][i]))
        results[th_key]['sll_s'].append(float(meta['sll_socp'][i]))

    summary = {}
    for th, v in sorted(results.items()):
        tm, sm, am = np.mean(v['sll_t']), np.mean(v['sll_s']), np.mean(v['sll_ai'])
        rec = (am - tm) / (sm - tm) * 100 if abs(sm - tm) > 0.01 else 0
        summary[th] = {'taylor': float(tm), 'socp': float(sm), 'ai': float(am), 'recovery': float(rec)}
    return summary


def main():
    device = torch.device('cpu')
    print('=' * 70)
    print('8x8 DeepSets Training')
    print('=' * 70)

    (train_f, train_t, _), (val_f, val_t, _), (test_f, _, test_m) = load_data()
    print(f'Train: {len(train_f)}, Val: {len(val_f)}, Test: {len(test_f)}')

    model = DeepSetsModel(9, 128, 2)
    print(f'Parameters: {count_parameters(model):,}')

    t0 = time.perf_counter()
    model, best_val, n_ep = train_model(model, train_f, train_t, val_f, val_t, device)
    train_time = time.perf_counter() - t0
    print(f'Trained {n_ep} epochs in {train_time:.1f}s, best_val={best_val:.6f}')

    # 保存模型
    model_path = os.path.join(OUTPUT_DIR, 'deepsets_8x8.pt')
    torch.save(model.state_dict(), model_path)
    print(f'Model saved: {model_path}')

    # 评估
    print('\nVal set:')
    (_, _, val_m_full) = load_data()[1]
    val_summary = evaluate(model, val_f, val_m_full, device)
    for th, v in sorted(val_summary.items()):
        print(f'  theta={th}: T={v["taylor"]:.1f} S={v["socp"]:.1f} A={v["ai"]:.1f} rec={v["recovery"]:.0f}%')

    print('\nTest set:')
    test_summary = evaluate(model, test_f, test_m, device)
    for th, v in sorted(test_summary.items()):
        print(f'  theta={th}: T={v["taylor"]:.1f} S={v["socp"]:.1f} A={v["ai"]:.1f} rec={v["recovery"]:.0f}%')

    # 汇总
    all_t = [v['taylor'] for v in test_summary.values()]
    all_s = [v['socp'] for v in test_summary.values()]
    all_a = [v['ai'] for v in test_summary.values()]
    overall_t = np.mean(all_t)
    overall_s = np.mean(all_s)
    overall_a = np.mean(all_a)
    overall_rec = (overall_a - overall_t) / (overall_s - overall_t) * 100

    print(f'\n{"="*70}')
    print(f'OVERALL (test): Taylor={overall_t:.1f} SOCP={overall_s:.1f} AI={overall_a:.1f}')
    print(f'Recovery: {overall_rec:.1f}%')
    print(f'{"="*70}')

    # 推理时延
    x_inf = torch.randn(1, 64, 9)
    for _ in range(10):
        with torch.no_grad():
            _ = model(x_inf)
    times = []
    for _ in range(100):
        t0 = time.perf_counter()
        with torch.no_grad():
            _ = model(x_inf)
        times.append((time.perf_counter() - t0) * 1000)
    print(f'Inference: {np.mean(times):.2f}ms (CPU)')

    # 保存结果
    results = {
        'val': val_summary, 'test': test_summary,
        'overall': {'taylor': float(overall_t), 'socp': float(overall_s),
                     'ai': float(overall_a), 'recovery': float(overall_rec)},
        'train_time_s': float(train_time), 'epochs': n_ep,
        'params': count_parameters(model),
        'inference_ms': float(np.mean(times)),
    }
    with open(os.path.join(OUTPUT_DIR, 'deepsets_8x8_results.json'), 'w') as f:
        json.dump(results, f, indent=2, default=str)
    print(f'Results saved.')


if __name__ == '__main__':
    main()
