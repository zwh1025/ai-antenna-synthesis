"""8×8曲面阵列 SOCP教师标签生成（严格质检版 v2）。

修改点：
  1. eval_full_3d()返回peak_u/peak_v/peak_w
  2. 峰值约束用实际峰值位置，非估算
  3. 每轮最多加1个最严重峰值，检查方向距离避免重复
  4. best_valid和best_invalid分离，valid优先
  5. 无valid候选时标记fallback_taylor/unsupported_direction
  6. peak_ratio<=1.001加入valid判定
  7. 81×81全局网格+峰值附近0.25°局部细化
  8. 旋转对称性回归检查
  9. 保存复数权值到NPZ
"""

import os, sys, time, json, csv
import numpy as np
import cvxpy as cp

sys.path.insert(0, '/mnt/workspace/gitCode/cann/tiaozhansai/project')
from mylib.antenna_calc import taylor_2d_separable, angular_distance_deg
from run_8x8_teacher import (
    load_real_coordinates, steering_vec_3d, coordinate_taylor_3d,
    normalize_weights, uv_to_uvw, get_null_dirs,
)

OUTPUT_DIR = '/mnt/workspace/gitCode/cann/tiaozhansai/revision/results'
os.makedirs(OUTPUT_DIR, exist_ok=True)

LAMBDA_MM = 23.9834
NX = NY = 8
N_ELEM = 64
SLL_DESIGN = 30
FREQ_GHZ = 12.5
EPS_NULL = 0.0398  # -28dB
N_COARSE = 11
N_CUTTING_ITERS = 10
N_EVAL = 81
TRUST_RADIUS_FACTOR = 0.3
NORM_RATIO = 1.5

SCAN_DIRS = [(0.0, 0.0)]
for th in [15.0, 30.0, 45.0, 60.0]:
    for ph in [0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0]:
        SCAN_DIRS.append((th, ph))


def solve_socp_with_trust(px, py, pz, u0, v0, w0,
                           sl_u, sl_v, sl_w,
                           null_u, null_v, null_w,
                           w_taylor_norm,
                           peak_constraints=None):
    n = len(px)
    w = cp.Variable(n, complex=True)
    t = cp.Variable()

    a_main = steering_vec_3d(px, py, pz, u0, v0, w0)
    constraints = [a_main.conj() @ w == 1.0 + 0j]

    for u_s, v_s, w_s in zip(sl_u, sl_v, sl_w):
        a_sl = steering_vec_3d(px, py, pz, u_s, v_s, w_s)
        constraints.append(cp.norm(a_sl.conj() @ w, 2) <= t)

    for u_n, v_n, w_n in zip(null_u, null_v, null_w):
        a_n = steering_vec_3d(px, py, pz, u_n, v_n, w_n)
        constraints.append(cp.norm(a_n.conj() @ w, 2) <= EPS_NULL)

    w_taylor_re = w_taylor_norm.real
    w_taylor_im = w_taylor_norm.imag
    trust_r = TRUST_RADIUS_FACTOR * np.linalg.norm(w_taylor_norm)
    norm_max = NORM_RATIO * np.linalg.norm(w_taylor_norm)

    w_diff = w - (w_taylor_re + 1j * w_taylor_im)
    constraints.append(cp.norm(w_diff, 2) <= trust_r)
    constraints.append(cp.norm(w, 2) <= norm_max)

    if peak_constraints:
        for u_p, v_p, w_p in peak_constraints:
            a_p = steering_vec_3d(px, py, pz, u_p, v_p, w_p)
            constraints.append(cp.norm(a_p.conj() @ w, 2) <= 1.0)

    prob = cp.Problem(cp.Minimize(t), constraints)
    try:
        prob.solve(solver=cp.SCS, verbose=False, max_iters=20000)
        if prob.status not in ['optimal', 'optimal_inaccurate']:
            return None, prob.status
    except Exception as e:
        return None, str(e)
    return w.value, prob.status


def eval_full_3d(w, px, py, pz, theta0, phi0, null_dirs, n_eval=N_EVAL):
    """81x81全可见域评估 + 峰值附近局部细化。返回完整诊断。"""
    k = 2 * np.pi
    u0 = np.sin(np.deg2rad(theta0)) * np.cos(np.deg2rad(phi0))
    v0 = np.sin(np.deg2rad(theta0)) * np.sin(np.deg2rad(phi0))
    w0 = np.cos(np.deg2rad(theta0))

    u = np.linspace(-1, 1, n_eval)
    v = np.linspace(-1, 1, n_eval)
    ug, vg = np.meshgrid(u, v, indexing='ij')
    vis = (ug**2 + vg**2) <= 1.0
    wg = uv_to_uvw(ug, vg)

    bw = 0.886 * 2.0 / NX * 180 / np.pi
    exc_uv = np.sin(np.deg2rad(3.0 * bw / max(np.cos(np.deg2rad(theta0)), 0.1)))
    dist = np.sqrt((ug - u0)**2 + (vg - v0)**2)
    sl_mask = (dist >= exc_uv) & vis

    vis_flat = vis.ravel()
    ug_flat = ug.ravel()
    vg_flat = vg.ravel()
    wg_flat = wg.ravel()
    pat_all = np.zeros(len(ug_flat))
    for i in range(len(ug_flat)):
        if vis_flat[i]:
            psi = k * (px * ug_flat[i] + py * vg_flat[i] + pz * wg_flat[i])
            pat_all[i] = np.abs(np.sum(np.conj(w) * np.exp(1j * psi)))

    psi_main = k * (px * u0 + py * v0 + pz * w0)
    main_resp = np.abs(np.sum(np.conj(w) * np.exp(1j * psi_main)))

    peak_idx = np.argmax(pat_all)
    peak_u = ug_flat[peak_idx]
    peak_v = vg_flat[peak_idx]
    peak_w = wg_flat[peak_idx]
    peak_val = pat_all[peak_idx]
    peak_ratio = peak_val / (main_resp + 1e-30)

    # 局部细化: 在峰值附近0.25度网格搜索
    peak_theta_coarse = np.degrees(np.arcsin(np.clip(np.sqrt(peak_u**2 + peak_v**2), 0, 1)))
    peak_phi_coarse = np.degrees(np.arctan2(peak_v, peak_u)) % 360

    refine_range = 2.0  # degrees
    refine_step = 0.25  # degrees
    refine_thetas = np.arange(max(0, peak_theta_coarse - refine_range),
                              min(90, peak_theta_coarse + refine_range) + refine_step,
                              refine_step)
    refine_phis = np.arange(max(0, peak_phi_coarse - refine_range),
                            min(360, peak_phi_coarse + refine_range) + refine_step,
                            refine_step)

    best_peak_val = peak_val
    best_peak_u = peak_u
    best_peak_v = peak_v
    best_peak_w = peak_w

    for rt in refine_thetas:
        for rp in refine_phis:
            ru = np.sin(np.deg2rad(rt)) * np.cos(np.deg2rad(rp))
            rv = np.sin(np.deg2rad(rt)) * np.sin(np.deg2rad(rp))
            rw = np.cos(np.deg2rad(rt))
            if ru**2 + rv**2 > 1.0:
                continue
            psi_r = k * (px * ru + py * rv + pz * rw)
            val_r = np.abs(np.sum(np.conj(w) * np.exp(1j * psi_r)))
            if val_r > best_peak_val:
                best_peak_val = val_r
                best_peak_u = ru
                best_peak_v = rv
                best_peak_w = rw

    peak_u = best_peak_u
    peak_v = best_peak_v
    peak_w = best_peak_w
    peak_val = best_peak_val
    peak_ratio = peak_val / (main_resp + 1e-30)

    peak_theta = np.degrees(np.arcsin(np.clip(np.sqrt(peak_u**2 + peak_v**2), 0, 1)))
    peak_phi = np.degrees(np.arctan2(peak_v, peak_u)) % 360
    pt_err = angular_distance_deg(peak_theta, peak_phi, theta0, phi0)

    sl_flat = sl_mask.ravel()
    pat_sl = pat_all[sl_flat]
    sll = 20 * np.log10(np.max(pat_sl) / (main_resp + 1e-30)) if main_resp > 1e-10 else -300

    sl_u_flat = ug_flat[sl_flat]
    sl_v_flat = vg_flat[sl_flat]
    sl_w_flat = wg_flat[sl_flat]
    sorted_idx = np.argsort(pat_sl)[::-1][:10]
    worst = [(sl_u_flat[i], sl_v_flat[i], sl_w_flat[i]) for i in sorted_idx]

    null_results = []
    for tn, pn in null_dirs:
        un = np.sin(np.deg2rad(tn)) * np.cos(np.deg2rad(pn))
        vn = np.sin(np.deg2rad(tn)) * np.sin(np.deg2rad(pn))
        wn = np.cos(np.deg2rad(tn))
        psi_n = k * (px * un + py * vn + pz * wn)
        nd = 20 * np.log10(np.abs(np.sum(np.conj(w) * np.exp(1j * psi_n))) / (main_resp + 1e-30))
        null_results.append(float(nd))

    return {
        'sll': float(sll),
        'pointing_err': float(pt_err),
        'main_resp': float(main_resp),
        'peak_ratio': float(peak_ratio),
        'peak_u': float(peak_u),
        'peak_v': float(peak_v),
        'peak_w': float(peak_w),
        'peak_theta': float(peak_theta),
        'peak_phi': float(peak_phi),
        'worst_null': float(max(null_results)),
        'null_depths': null_results,
        'worst_sidelobes': worst,
    }


def check_valid(eval_result, taylor_sll, w_norm, t_norm, main_err):
    """检查是否满足全部valid条件。"""
    if main_err > 1e-3:
        return False, f'main_err={main_err:.2e}'
    if eval_result['pointing_err'] > 1.0:
        return False, f'pt_err={eval_result["pointing_err"]:.2f}'
    if eval_result['peak_ratio'] > 1.001:
        return False, f'peak_ratio={eval_result["peak_ratio"]:.4f}'
    if eval_result['worst_null'] > -28:
        return False, f'null={eval_result["worst_null"]:.1f}dB'
    norm_ratio = w_norm / (t_norm + 1e-30)
    if norm_ratio > NORM_RATIO:
        return False, f'norm_ratio={norm_ratio:.2f}'
    improvement = eval_result['sll'] - taylor_sll
    if improvement > -0.5:
        return False, f'improve={improvement:.1f}dB'
    return True, ''


def angular_dist_uv(u1, v1, u2, v2):
    """两个uv方向之间的角距离(度)。"""
    r1 = np.sqrt(u1**2 + v1**2)
    r2 = np.sqrt(u2**2 + v2**2)
    if r1 < 1e-10 or r2 < 1e-10:
        return np.degrees(abs(r1 - r2))
    cos_a = (u1*u2 + v1*v2) / (r1 * r2)
    cos_a = np.clip(cos_a, -1, 1)
    return np.degrees(np.arccos(cos_a))


def main():
    print('=' * 70)
    print('8x8 SOCP Teacher Generation (Strict QC v2)')
    print(f'  {len(SCAN_DIRS)} unique scan directions')
    print(f'  Trust: ||w-w_taylor||<={TRUST_RADIUS_FACTOR}*||w_taylor||, ||w||<={NORM_RATIO}*||w_taylor||')
    print(f'  Valid: main_err<1e-3, pt<=1deg, peak<=1.001, null<=-28dB, norm<=1.5x, improve>=0.5dB')
    print(f'  Peak refinement: 0.25 deg local grid')
    print('=' * 70)

    coords, normals = load_real_coordinates()
    px, py, pz = coords[:, 0], coords[:, 1], coords[:, 2]
    amp_x, amp_y = taylor_2d_separable(NX, NY, SLL_DESIGN)

    results = []
    weights_valid = {}  # {idx: (w_re, w_im)}
    valid_mask = []
    fallback_mask = []
    unsupported_mask = []
    solver_failed_mask = []

    t_start = time.time()

    for i, (theta0, phi0) in enumerate(SCAN_DIRS):
        null_dirs = get_null_dirs(theta0, phi0)
        u0 = np.sin(np.deg2rad(theta0)) * np.cos(np.deg2rad(phi0))
        v0 = np.sin(np.deg2rad(theta0)) * np.sin(np.deg2rad(phi0))
        w0 = np.cos(np.deg2rad(theta0))

        w_taylor = coordinate_taylor_3d(px, py, pz, amp_x, amp_y, theta0, phi0)
        w_taylor_n = normalize_weights(w_taylor, px, py, pz, u0, v0, w0)
        t_eval = eval_full_3d(w_taylor_n, px, py, pz, theta0, phi0, null_dirs)
        t_norm = np.linalg.norm(w_taylor_n)

        null_u = [np.sin(np.deg2rad(tn)) * np.cos(np.deg2rad(pn)) for tn, pn in null_dirs]
        null_v = [np.sin(np.deg2rad(tn)) * np.sin(np.deg2rad(pn)) for tn, pn in null_dirs]
        null_w = [np.cos(np.deg2rad(tn)) for tn, pn in null_dirs]

        u_c = np.linspace(-1, 1, N_COARSE)
        v_c = np.linspace(-1, 1, N_COARSE)
        ug_c, vg_c = np.meshgrid(u_c, v_c, indexing='ij')
        vis_c = (ug_c**2 + vg_c**2) <= 1.0
        wg_c = uv_to_uvw(ug_c, vg_c)
        bw = 0.886 * 2.0 / NX * 180 / np.pi
        exc_uv = np.sin(np.deg2rad(3.0 * bw / max(np.cos(np.deg2rad(theta0)), 0.1)))
        dist_c = np.sqrt((ug_c - u0)**2 + (vg_c - v0)**2)
        sl_mask_c = (dist_c >= exc_uv) & vis_c
        sl_u = list(ug_c[sl_mask_c])
        sl_v = list(vg_c[sl_mask_c])
        sl_w = list(wg_c[sl_mask_c])

        best_valid = None  # (sll, w, eval)
        best_invalid = None  # (sll, w, eval)
        peak_constraints = []
        solver_status = 'not_attempted'
        n_iters_actual = 0

        for it in range(N_CUTTING_ITERS):
            w_opt, solver_status = solve_socp_with_trust(
                px, py, pz, u0, v0, w0, sl_u, sl_v, sl_w,
                null_u, null_v, null_w, w_taylor_n, peak_constraints)

            if w_opt is None:
                break

            w_opt_n = normalize_weights(w_opt, px, py, pz, u0, v0, w0)
            s_eval = eval_full_3d(w_opt_n, px, py, pz, theta0, phi0, null_dirs)
            n_iters_actual = it + 1
            main_err = abs(abs(np.conj(steering_vec_3d(px, py, pz, u0, v0, w0)) @ w_opt_n) - 1.0)
            w_norm = np.linalg.norm(w_opt_n)

            is_valid, reason = check_valid(s_eval, t_eval['sll'], w_norm, t_norm, main_err)

            if is_valid:
                if best_valid is None or s_eval['sll'] < best_valid[0]:
                    best_valid = (s_eval['sll'], w_opt_n.copy(), s_eval, main_err, w_norm)
            else:
                if best_invalid is None or s_eval['sll'] < best_invalid[0]:
                    best_invalid = (s_eval['sll'], w_opt_n.copy(), s_eval, main_err, w_norm, reason)

            # 峰值抑制：用实际峰值位置
            if s_eval['peak_ratio'] > 1.001 or s_eval['pointing_err'] > 1.0:
                new_peak = (s_eval['peak_u'], s_eval['peak_v'], s_eval['peak_w'])
                # 检查与已有约束的方向距离
                too_close = False
                for pu, pv, pw in peak_constraints:
                    if angular_dist_uv(pu, pv, new_peak[0], new_peak[1]) < 2.0:
                        too_close = True
                        break
                if not too_close and len(peak_constraints) < 5:
                    peak_constraints.append(new_peak)

            # 加入最差副瓣点(每轮最多2个)
            for u_w, v_w, w_w in s_eval['worst_sidelobes'][:2]:
                already = any(abs(su - u_w) < 0.01 and abs(sv - v_w) < 0.01
                              for su, sv in zip(sl_u, sl_v))
                if not already:
                    sl_u.append(u_w)
                    sl_v.append(v_w)
                    sl_w.append(w_w)

        # 最终选择
        if best_valid is not None:
            final_w = best_valid[1]
            final_eval = best_valid[2]
            final_main_err = best_valid[3]
            final_w_norm = best_valid[4]
            status = 'valid'
        elif best_invalid is not None:
            # Taylor本身是否满足安全指标
            t_main_err = abs(abs(np.conj(steering_vec_3d(px, py, pz, u0, v0, w0)) @ w_taylor_n) - 1.0)
            t_valid, _ = check_valid(t_eval, t_eval['sll'], t_norm, t_norm, t_main_err)
            if t_valid:
                final_w = w_taylor_n
                final_eval = t_eval
                final_main_err = t_main_err
                final_w_norm = t_norm
                status = 'fallback_taylor'
            else:
                final_w = best_invalid[1]
                final_eval = best_invalid[2]
                final_main_err = best_invalid[3]
                final_w_norm = best_invalid[4]
                status = 'unsupported_direction'
        else:
            if solver_status not in ['optimal', 'optimal_inaccurate']:
                final_w = w_taylor_n
                final_eval = t_eval
                final_main_err = 0.0
                final_w_norm = t_norm
                status = 'solver_failed'
            else:
                final_w = w_taylor_n
                final_eval = t_eval
                final_main_err = 0.0
                final_w_norm = t_norm
                status = 'unsupported_direction'

        improvement = final_eval['sll'] - t_eval['sll']
        norm_ratio = final_w_norm / (t_norm + 1e-30)
        max_amp = np.max(np.abs(final_w))

        r = {
            'idx': i,
            'theta0': float(theta0), 'phi0': float(phi0),
            'taylor_sll': float(t_eval['sll']),
            'final_sll': float(final_eval['sll']),
            'improvement': float(improvement),
            'taylor_pt': float(t_eval['pointing_err']),
            'final_pt': float(final_eval['pointing_err']),
            'peak_ratio': float(final_eval['peak_ratio']),
            'peak_u': float(final_eval['peak_u']),
            'peak_v': float(final_eval['peak_v']),
            'peak_w': float(final_eval['peak_w']),
            'worst_null': float(final_eval['worst_null']),
            'null_depths': final_eval['null_depths'],
            'w_norm': float(final_w_norm),
            't_norm': float(t_norm),
            'norm_ratio': float(norm_ratio),
            'max_amp': float(max_amp),
            'main_err': float(final_main_err),
            'solver_status': solver_status,
            'n_iters': n_iters_actual,
            'n_peak_constraints': len(peak_constraints),
            'status': status,
        }
        results.append(r)
        weights_valid[i] = (final_w.real.copy(), final_w.imag.copy())

        if status == 'valid':
            valid_mask.append(i)
        elif status == 'fallback_taylor':
            fallback_mask.append(i)
        elif status == 'solver_failed':
            solver_failed_mask.append(i)
        else:
            unsupported_mask.append(i)

        print(f'  [{i+1:2d}/{len(SCAN_DIRS)}] th={theta0:.0f} ph={phi0:>3.0f} '
              f'T={t_eval["sll"]:.1f} F={final_eval["sll"]:.1f} d={improvement:+.1f} '
              f'pt={final_eval["pointing_err"]:.2f} peak={final_eval["peak_ratio"]:.4f} '
              f'null={final_eval["worst_null"]:.1f} norm={norm_ratio:.2f} '
              f'iters={n_iters_actual} peaks={len(peak_constraints)} [{status}]')

    total_time = time.time() - t_start

    # 旋转对称性回归检查
    print(f'\n{"="*70}')
    print('ROTATION SYMMETRY CHECK')
    print(f'{"="*70}')
    symmetry_issues = []
    for th in [15.0, 30.0, 45.0, 60.0]:
        group_90 = [r for r in results if r['theta0'] == th and r['phi0'] in [0, 90, 180, 270]]
        group_45 = [r for r in results if r['theta0'] == th and r['phi0'] in [45, 135, 225, 315]]
        for group, name in [(group_90, 'phi=0/90/180/270'), (group_45, 'phi=45/135/225/315')]:
            if len(group) < 2:
                continue
            slls = [r['final_sll'] for r in group]
            pts = [r['final_pt'] for r in group]
            norms = [r['norm_ratio'] for r in group]
            sll_range = max(slls) - min(slls)
            pt_range = max(pts) - min(pts)
            norm_range = max(norms) - min(norms)
            if sll_range > 3.0 or pt_range > 1.5 or norm_range > 0.2:
                issue = f'theta={th:.0f} {name}: SLL_range={sll_range:.1f}dB pt_range={pt_range:.2f} norm_range={norm_range:.3f}'
                symmetry_issues.append(issue)
                print(f'  WARNING: {issue}')
            else:
                print(f'  OK: theta={th:.0f} {name}: SLL_range={sll_range:.1f}dB pt_range={pt_range:.2f}')

    # 汇总
    print(f'\n{"="*70}')
    print(f'SUMMARY: {len(results)} directions, {total_time:.1f}s')
    print(f'  Valid: {len(valid_mask)}, Fallback: {len(fallback_mask)}, '
          f'Unsupported: {len(unsupported_mask)}, Solver_failed: {len(solver_failed_mask)}')
    if symmetry_issues:
        print(f'  Symmetry issues: {len(symmetry_issues)}')
    print(f'{"="*70}')

    # 表格
    print(f'\n{"th":>4} {"ph":>5} {"T_sll":>6} {"F_sll":>6} {"delta":>6} {"pt":>5} {"peak":>7} {"null":>6} {"norm":>5} {"status":>20}')
    print('-' * 80)
    for r in results:
        print(f'{r["theta0"]:>4.0f} {r["phi0"]:>5.0f} {r["taylor_sll"]:>6.1f} {r["final_sll"]:>6.1f} '
              f'{r["improvement"]:>+6.1f} {r["final_pt"]:>5.2f} {r["peak_ratio"]:>7.4f} '
              f'{r["worst_null"]:>6.1f} {r["norm_ratio"]:>5.2f} {r["status"]:>20}')

    # 保存JSON
    out_json = os.path.join(OUTPUT_DIR, 'teacher_8x8_qc_v2.json')
    with open(out_json, 'w') as f:
        json.dump({
            'results': results,
            'n_valid': len(valid_mask), 'n_fallback': len(fallback_mask),
            'n_unsupported': len(unsupported_mask), 'n_solver_failed': len(solver_failed_mask),
            'valid_indices': valid_mask, 'fallback_indices': fallback_mask,
            'unsupported_indices': unsupported_mask, 'solver_failed_indices': solver_failed_mask,
            'symmetry_issues': symmetry_issues,
            'total_time_s': total_time,
            'config': {'trust_radius': TRUST_RADIUS_FACTOR, 'norm_ratio': NORM_RATIO,
                       'null_threshold_db': 28, 'n_iters': N_CUTTING_ITERS,
                       'n_eval': N_EVAL, 'refine_step_deg': 0.25},
        }, f, indent=2, default=str)
    print(f'\nJSON saved: {out_json}')

    # 保存权值NPZ
    n = len(SCAN_DIRS)
    w_re = np.zeros((n, N_ELEM))
    w_im = np.zeros((n, N_ELEM))
    for idx in range(n):
        if idx in weights_valid:
            w_re[idx] = weights_valid[idx][0]
            w_im[idx] = weights_valid[idx][1]

    out_npz = os.path.join(OUTPUT_DIR, 'teacher_8x8_qc_weights.npz')
    np.savez(out_npz,
             w_re=w_re, w_im=w_im,
             px=px, py=py, pz=pz,
             valid_mask=np.array(valid_mask),
             fallback_mask=np.array(fallback_mask),
             unsupported_mask=np.array(unsupported_mask),
             solver_failed_mask=np.array(solver_failed_mask),
             scan_dirs=np.array(SCAN_DIRS),
             )
    print(f'Weights saved: {out_npz}')
    print('=' * 70)


if __name__ == '__main__':
    main()
