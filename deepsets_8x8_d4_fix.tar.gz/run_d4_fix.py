"""D4对称置换矩阵 + 单元测试 + Canonical推理包装器 + v5重新评估

核心修复：
  1. 坐标固定, 只置换权值
  2. D4完整8种变换(4旋转+4镜像旋转)
  3. 变换前后物理不变量测试
  4. Canonical推理: 任意phi折叠到0-45, 推理后逆置换恢复
  5. 81x81评估
  6. 支持域门控
"""

import os, sys, time, json, hashlib
import numpy as np
import torch

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(BASE_DIR, 'mylib'))
OUTPUT_DIR = os.path.join(BASE_DIR, 'output')

N_ELEM = 64
NX = NY = 8
WEIGHT_SCALE = 64.0

# D4群的8种变换: (rot_type, name)
# rot_type: 0=identity, 1-3=90/180/270度旋转
# 4-7=镜像+旋转
D4_TRANSFORMS = [
    (0, 'identity'),
    (1, 'rot90'),
    (2, 'rot180'),
    (3, 'rot270'),
    (4, 'mirror_x'),      # x->-x, y->y
    (5, 'mirror_y'),      # x->x, y->-y
    (6, 'mirror_diag'),   # x<->y
    (7, 'mirror_anti'),   # x->-y, y->-x
]


def load_coords():
    import csv
    csv_path = os.path.join(BASE_DIR, 'element_port_map.csv')
    coords = []
    with open(csv_path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            coords.append((
                float(row['x_mm']) / 23.9834,
                float(row['y_mm']) / 23.9834,
                float(row['z_mm']) / 23.9834,
            ))
    return np.array(coords)


def apply_d4_transform(x, y, z, transform_id):
    """对坐标施加D4变换。返回变换后的(x,y,z)。"""
    if transform_id == 0:  # identity
        return x, y, z
    elif transform_id == 1:  # rot90: (x,y)->(y,-x)
        return y, -x, z
    elif transform_id == 2:  # rot180: (x,y)->(-x,-y)
        return -x, -y, z
    elif transform_id == 3:  # rot270: (x,y)->(-y,x)
        return -y, x, z
    elif transform_id == 4:  # mirror_x: (x,y)->(-x,y)
        return -x, y, z
    elif transform_id == 5:  # mirror_y: (x,y)->(x,-y)
        return x, -y, z
    elif transform_id == 6:  # mirror_diag: (x,y)->(y,x)
        return y, x, z
    elif transform_id == 7:  # mirror_anti: (x,y)->(-y,-x)
        return -y, -x, z
    return x, y, z


def build_permutation(coords, transform_id):
    """构建D4置换矩阵P: P[i] = j表示变换后位置i对应原始阵元j。

    方法: 对每个阵元i的坐标施加D4变换R, 得到R(coords[i]),
    然后在原始坐标表中寻找与之最接近的阵元j。
    """
    n = len(coords)
    px = coords[:, 0]; py = coords[:, 1]; pz = coords[:, 2]
    perm = np.zeros(n, dtype=np.int32)

    for i in range(n):
        tx, ty, tz = apply_d4_transform(px[i], py[i], pz[i], transform_id)
        # 找最近原始阵元
        best_j = 0; best_dist = 1e10
        for j in range(n):
            d = (px[j] - tx)**2 + (py[j] - ty)**2 + (pz[j] - tz)**2
            if d < best_dist:
                best_dist = d; best_j = j
        perm[i] = best_j

    return perm


def transform_phi(phi, transform_id):
    """变换后的phi角度。"""
    if transform_id == 0: return phi
    elif transform_id == 1: return (phi + 90) % 360
    elif transform_id == 2: return (phi + 180) % 360
    elif transform_id == 3: return (phi + 270) % 360
    elif transform_id == 4: return (180 - phi) % 360  # mirror_x: u->-u, v->v
    elif transform_id == 5: return (360 - phi) % 360  # mirror_y: u->u, v->-v
    elif transform_id == 6: return (90 - phi) % 360   # mirror diag
    elif transform_id == 7: return (270 - phi) % 360  # mirror anti
    return phi


def fold_to_canonical(phi):
    """将任意phi折叠到0-45度, 返回(canonical_phi, transform_id)。"""
    phi = phi % 360
    best_phi = phi; best_tid = 0; best_dist = abs(phi)

    for tid in range(8):
        tp = transform_phi(phi, tid) % 360
        # 折叠到0-45
        if tp > 45:
            # 尝试反向折叠
            for fold_tid in range(8):
                folded = transform_phi(tp, fold_tid) % 360
                if 0 <= folded <= 45:
                    dist = min(abs(folded - phi % 45), 45 - abs(folded - phi % 45))
                    if dist < best_dist:
                        best_dist = dist
                        best_phi = folded
                        best_tid = tid
                    break
        else:
            if 0 <= tp <= 45:
                dist = min(abs(tp - phi % 45), 45 - abs(tp - phi % 45))
                if dist < best_dist:
                    best_dist = dist
                    best_phi = tp
                    best_tid = tid

    return best_phi, best_tid


# ============================================================
# 物理函数 (81x81评估)
# ============================================================
def steering_vec(px, py, pz, u, v, w):
    k = 2 * np.pi
    return np.exp(1j * k * (px * u + py * v + pz * w))

def normalize_mainlobe(w, px, py, pz, u0, v0, w0):
    a = steering_vec(px, py, pz, u0, v0, w0)
    resp = np.conj(a) @ w
    if np.abs(resp) < 1e-12: return w
    return w / resp

def angular_dist_deg(th1, ph1, th2, ph2):
    t1, p1 = np.deg2rad(th1), np.deg2rad(ph1)
    t2, p2 = np.deg2rad(th2), np.deg2rad(ph2)
    cos_d = np.cos(t1)*np.cos(t2) + np.sin(t1)*np.sin(t2)*np.cos(p1-p2)
    return float(np.rad2deg(np.arccos(np.clip(cos_d, -1, 1))))

def get_null_dirs(theta0, phi0):
    if theta0 < 10:
        return [(30, 0), (30, 90), (30, 180), (30, 270)]
    return [
        (theta0, (phi0 + 90) % 360),
        (theta0, (phi0 + 180) % 360),
        (theta0, (phi0 + 270) % 360),
        (min(theta0 + 25, 85), (phi0 + 45) % 360),
    ]


def eval_full_81(w, px, py, pz, th0, ph0, null_dirs):
    """81x81全可见域评估。"""
    k = 2 * np.pi
    u0 = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph0))
    v0 = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph0))
    w0 = np.cos(np.deg2rad(th0))
    n_eval = 81
    u = np.linspace(-1, 1, n_eval); v = np.linspace(-1, 1, n_eval)
    ug, vg = np.meshgrid(u, v, indexing='ij')
    vis = (ug**2 + vg**2) <= 1.0; wg = np.sqrt(np.maximum(1-ug**2-vg**2, 0))
    bw = 0.886 * 2.0 / NX * 180 / np.pi
    exc = np.sin(np.deg2rad(3.0 * bw / max(np.cos(np.deg2rad(th0)), 0.1)))
    dist = np.sqrt((ug-u0)**2 + (vg-v0)**2)
    sl_mask = (dist >= exc) & vis
    vf = vis.ravel(); uf = ug.ravel(); vf2 = vg.ravel(); wf = wg.ravel()
    pat = np.zeros(len(uf))
    for i in range(len(uf)):
        if vf[i]:
            psi = k * (px*uf[i] + py*vf2[i] + pz*wf[i])
            pat[i] = np.abs(np.sum(np.conj(w) * np.exp(1j * psi)))
    psi_m = k * (px*u0 + py*v0 + pz*w0)
    mr = np.abs(np.sum(np.conj(w) * np.exp(1j * psi_m)))
    pi2 = np.argmax(pat)
    pval = pat[pi2]
    pu = uf[pi2]; pv = vf2[pi2]; pw = wf[pi2]
    # 局部细化
    pt_c = np.degrees(np.arcsin(np.clip(np.sqrt(pu**2+pv**2), 0, 1)))
    pp_c = np.degrees(np.arctan2(pv, pu)) % 360
    for rt in np.arange(max(0, pt_c-2.0), min(90, pt_c+2.0)+0.25, 0.25):
        for rpw in np.arange(pp_c-2.0, pp_c+2.0+0.25, 0.25):
            rp = rpw % 360.0
            ru = np.sin(np.deg2rad(rt))*np.cos(np.deg2rad(rp))
            rv = np.sin(np.deg2rad(rt))*np.sin(np.deg2rad(rp))
            rw = np.cos(np.deg2rad(rt))
            if ru**2+rv**2 > 1.0: continue
            vr = np.abs(np.sum(np.conj(w)*np.exp(1j*k*(px*ru+py*rv+pz*rw))))
            if vr > pval: pval=vr; pu=ru; pv=rv; pw=rw
    pr = pval / (mr + 1e-30)
    pth = np.degrees(np.arcsin(np.clip(np.sqrt(pu**2+pv**2), 0, 1)))
    pph = np.degrees(np.arctan2(pv, pu)) % 360
    pte = angular_dist_deg(pth, pph, th0, ph0)
    sf = sl_mask.ravel(); ps = pat[sf]
    sll = 20*np.log10(np.max(ps)/(mr+1e-30)) if mr > 1e-10 else -300
    nulls = []
    for tn, pn in null_dirs:
        un = np.sin(np.deg2rad(tn))*np.cos(np.deg2rad(pn))
        vn = np.sin(np.deg2rad(tn))*np.sin(np.deg2rad(pn))
        wn = np.cos(np.deg2rad(tn))
        nd = 20*np.log10(np.abs(np.sum(np.conj(w)*np.exp(1j*k*(px*un+py*vn+pz*wn))))/(mr+1e-30))
        nulls.append(float(nd))
    return {'sll': float(sll), 'pt': float(pte), 'pr': float(pr),
            'mr': float(mr), 'wn': float(max(nulls)), 'nulls': nulls}


def taylor_2d(Nx, Ny, SLL):
    import math
    posx = (np.arange(1, Nx + 1) - (Nx / 2 + 0.5)) * 0.5
    posy = (np.arange(1, Ny + 1) - (Ny / 2 + 0.5)) * 0.5
    def taylor_1d(N, pos, RdB):
        R0 = 10 ** (RdB / 20)
        A = np.arccosh(R0) / np.pi
        n_bar = max(int(np.ceil(2 * A ** 2 + 0.5)), 2)
        m = np.arange(1, n_bar).reshape(-1, 1)
        n = np.arange(1, n_bar).reshape(1, -1)
        def fact(x):
            return np.array([math.factorial(int(v)) for v in np.asarray(x).ravel()]).reshape(np.asarray(x).shape)
        sigma = n_bar / (A ** 2 + (n_bar - 0.5) ** 2) ** 0.5
        Sm1 = (fact(n_bar - 1) ** 2) / fact(n_bar + m - 1) / fact(n_bar - m - 1)
        Sm2 = np.prod(1 - (m ** 2 / sigma ** 2 / (A ** 2 + (n - 0.5) ** 2)), axis=1).reshape(-1, 1)
        Sm = Sm1 * Sm2
        pos = np.asarray(pos).reshape(1, -1)
        exc = 1 + 2 * np.sum(Sm * np.cos(m * pos * 2 * np.pi / (N * 0.5)), axis=0)
        exc = exc / np.max(exc)
        return exc.ravel()
    ax = taylor_1d(Nx, posx, SLL)
    ay = taylor_1d(Ny, posy, SLL)
    return ax, ay


# ============================================================
# DeepSets模型 (与v5一致)
# ============================================================
import torch.nn as nn

class DeepSetsV2(nn.Module):
    def __init__(self, input_dim=9, hidden_dim=256, output_dim=2):
        super().__init__()
        self.phi = nn.Sequential(
            nn.Linear(input_dim, hidden_dim), nn.LayerNorm(hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim), nn.LayerNorm(hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim), nn.LayerNorm(hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.rho = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim), nn.LayerNorm(hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.output_net = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim), nn.LayerNorm(hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, output_dim),
        )

    def forward(self, x):
        h = self.phi(x)
        mean_p = h.mean(dim=1)
        max_p = h.max(dim=1)[0]
        pooled = torch.cat([mean_p, max_p], dim=-1)
        g = self.rho(pooled)
        g_exp = g.unsqueeze(1).expand(-1, h.size(1), -1)
        combined = torch.cat([h, g_exp], dim=-1)
        return self.output_net(combined)


# ============================================================
# 单元测试
# ============================================================
def run_d4_unit_tests(coords, perms):
    """D4置换的物理不变量测试。"""
    print('\n' + '='*70)
    print('D4 UNIT TESTS')
    print('='*70)

    px = coords[:, 0]; py = coords[:, 1]; pz = coords[:, 2]
    ax, ay = taylor_2d(NX, NY, 30)

    all_pass = True

    for tid, name in D4_TRANSFORMS:
        perm = perms[tid]
        issues = []

        # 1. 一一置换: 每个元素恰好出现一次
        if len(set(perm.tolist())) != N_ELEM:
            issues.append('NOT_PERMUTATION')
            print(f'  [{name}] FAIL: not a permutation')
            all_pass = False
            continue

        # 2. 范数不变
        w_test = np.random.randn(N_ELEM) + 1j * np.random.randn(N_ELEM)
        w_perm = w_test[perm]
        if abs(np.linalg.norm(w_perm) - np.linalg.norm(w_test)) > 1e-10:
            issues.append('NORM_CHANGED')
            print(f'  [{name}] FAIL: norm changed')
            all_pass = False
            continue

        # 3. 主瓣复响应不变 (在变换后的方向上)
        th0 = 30.0; ph0 = 45.0
        ph_transformed = transform_phi(ph0, tid)
        u0 = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph0))
        v0 = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph0))
        w0 = np.cos(np.deg2rad(th0))

        # Taylor在原始方向
        wt = np.outer(ay, ax).ravel() * np.exp(1j * 2*np.pi*(px*u0 + py*v0 + pz*w0))
        wt_norm = normalize_mainlobe(wt, px, py, pz, u0, v0, w0)

        # 置换后的Taylor在变换后的方向
        u0_t = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph_transformed))
        v0_t = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph_transformed))
        w0_t = np.cos(np.deg2rad(th0))
        wt_perm = wt_norm[perm]
        wt_perm_norm = normalize_mainlobe(wt_perm, px, py, pz, u0_t, v0_t, w0_t)

        main_err = abs(abs(np.conj(steering_vec(px,py,pz,u0_t,v0_t,w0_t)) @ wt_perm_norm) - 1.0)
        if main_err > 1e-10:
            issues.append(f'MAIN_ERR={main_err:.2e}')

        # 4. 方向图不变性
        nd_orig = get_null_dirs(th0, ph0)
        nd_trans = get_null_dirs(th0, ph_transformed)
        ev_orig = eval_full_81(wt_norm, px, py, pz, th0, ph0, nd_orig)
        ev_perm = eval_full_81(wt_perm_norm, px, py, pz, th0, ph_transformed, nd_trans)

        sll_diff = abs(ev_orig['sll'] - ev_perm['sll'])
        pt_diff = abs(ev_orig['pt'] - ev_perm['pt'])
        peak_diff = abs(ev_orig['pr'] - ev_perm['pr'])

        if sll_diff > 0.1: issues.append(f'SLL_DIFF={sll_diff:.2f}')
        if pt_diff > 0.01: issues.append(f'PT_DIFF={pt_diff:.4f}')
        if peak_diff > 1e-6: issues.append(f'PEAK_DIFF={peak_diff:.2e}')

        if issues:
            print(f'  [{name}] FAIL: {"; ".join(issues)}')
            all_pass = False
        else:
            print(f'  [{name}] PASS (SLL={ev_orig["sll"]:.2f}/{ev_perm["sll"]:.2f} '
                  f'pt={ev_orig["pt"]:.4f}/{ev_perm["pt"]:.4f})')

    print(f'\n  Overall: {"ALL PASS" if all_pass else "FAILED"}')
    return all_pass


# ============================================================
# Canonical推理包装器
# ============================================================
class CanonicalWrapper:
    """将任意(theta,phi)方向通过D4变换折叠到canonical(0-45)度,
    调用DeepSets推理, 然后通过逆置换恢复到原始物理端口顺序。"""

    def __init__(self, model, coords, perms, mean_stats, std_stats):
        self.model = model
        self.coords = coords
        self.perms = perms  # perms[tid] = permutation array
        self.px = coords[:, 0]; self.py = coords[:, 1]; self.pz = coords[:, 2]
        self.mean_stats = mean_stats
        self.std_stats = std_stats
        self.ax, self.ay = taylor_2d(NX, NY, 30)

    def compute_taylor(self, th0, ph0):
        k = 2 * np.pi
        u0 = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph0))
        v0 = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph0))
        w0 = np.cos(np.deg2rad(th0))
        wt = np.outer(self.ay, self.ax).ravel() * np.exp(1j * k*(self.px*u0 + self.py*v0 + self.pz*w0))
        return normalize_mainlobe(wt, self.px, self.py, self.pz, u0, v0, w0)

    def fold_to_canonical(self, phi):
        """折叠phi到0-45度, 返回(canonical_phi, transform_id)。"""
        phi = phi % 360
        best_phi = phi % 46; best_tid = 0

        for tid in range(8):
            tp = transform_phi(phi, tid) % 360
            # 尝试再变换回0-45
            for tid2 in range(8):
                folded = transform_phi(tp, tid2) % 360
                if folded <= 45.0001:
                    if abs(folded - best_phi) < abs(best_phi - phi % 46):
                        best_phi = folded; best_tid = tid
                    break
        return best_phi, best_tid

    def predict(self, th0, ph0, support_label='valid'):
        """带支持域门控的推理。"""
        if support_label in ('degraded', 'unsupported'):
            wt = self.compute_taylor(th0, ph0)
            return wt, 'rejected', 0.0, 0.0
        elif support_label == 'fallback_taylor':
            wt = self.compute_taylor(th0, ph0)
            return wt, 'taylor', 0.0, 0.0

        # valid: Canonical推理
        canon_ph, tid = self.fold_to_canonical(ph0)

        # Taylor在canonical方向
        wt_canon = self.compute_taylor(th0, canon_ph)

        # 构建输入特征
        u0c = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(canon_ph))
        v0c = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(canon_ph))
        w0c = np.cos(np.deg2rad(th0))

        px_n = (self.px - self.mean_stats['px_mean']) / (self.std_stats['px_std'] + 1e-8)
        py_n = (self.py - self.mean_stats['py_mean']) / (self.std_stats['py_std'] + 1e-8)
        pz_n = (self.pz - self.mean_stats['pz_mean']) / (self.std_stats['pz_std'] + 1e-8)

        feat = np.stack([
            px_n, py_n, pz_n,
            wt_canon.real * WEIGHT_SCALE, wt_canon.imag * WEIGHT_SCALE,
            np.full(N_ELEM, u0c), np.full(N_ELEM, v0c),
            np.full(N_ELEM, w0c), np.full(N_ELEM, 0.6, dtype=np.float32),
        ], axis=-1).astype(np.float32)

        x = torch.as_tensor(feat[None], dtype=torch.float32)
        with torch.no_grad():
            delta = self.model(x)[0].numpy()

        # AI权值在canonical方向
        w_ai_canon = (wt_canon.real + delta[:, 0] / WEIGHT_SCALE) + \
                     1j * (wt_canon.imag + delta[:, 1] / WEIGHT_SCALE)
        w_ai_canon = normalize_mainlobe(w_ai_canon, self.px, self.py, self.pz, u0c, v0c, w0c)

        # 逆置换: 从canonical方向恢复到原始物理方向
        # perm[tid][i] = j: 变换后位置i对应原始阵元j
        # 逆置换: inv_perm[j] = i
        perm = self.perms[tid]
        inv_perm = np.zeros(N_ELEM, dtype=np.int32)
        for i in range(N_ELEM):
            inv_perm[perm[i]] = i

        # 原始方向的Taylor
        wt_orig = self.compute_taylor(th0, ph0)
        u0 = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph0))
        v0 = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph0))
        w0 = np.cos(np.deg2rad(th0))

        # AI权值: 把canonical权值按逆置换映射到原始方向
        w_ai_orig = w_ai_canon[inv_perm]
        w_ai_orig = normalize_mainlobe(w_ai_orig, self.px, self.py, self.pz, u0, v0, w0)

        return w_ai_orig, 'ai', canon_ph, tid


# ============================================================
# 评估函数
# ============================================================
def evaluate_with_wrapper(wrapper, thetas, phis, taylor_slls, support_labels, px, py, pz):
    """用Canonical包装器评估, 81x81网格, alpha回退。"""
    results = []

    for i in range(len(thetas)):
        th0 = float(thetas[i]); ph0 = float(phis[i])
        sl = support_labels[i] if i < len(support_labels) else 'valid'

        w_ai, mode, canon_ph, tid = wrapper.predict(th0, ph0, sl)

        wt = wrapper.compute_taylor(th0, ph0)
        nd = get_null_dirs(th0, ph0)

        u0 = np.sin(np.deg2rad(th0))*np.cos(np.deg2rad(ph0))
        v0 = np.sin(np.deg2rad(th0))*np.sin(np.deg2rad(ph0))
        w0 = np.cos(np.deg2rad(th0))

        # 评估AI
        ev_ai = eval_full_81(w_ai, px, py, pz, th0, ph0, nd)
        t_sll = float(taylor_slls[i]) if i < len(taylor_slls) else float(eval_full_81(wt, px, py, pz, th0, ph0, nd)['sll'])

        ai_pass = (ev_ai['pt'] <= 1.0 and ev_ai['pr'] <= 1.001 and
                   ev_ai['wn'] <= -28.0 and ev_ai['sll'] - t_sll <= -0.5 and
                   np.linalg.norm(w_ai) / (np.linalg.norm(wt) + 1e-30) <= 1.5)

        # alpha回退
        alpha_best = 1.0; w_final = w_ai; ev_final = ev_ai
        final_pass = ai_pass; used_alpha = False

        if not ai_pass and mode == 'ai':
            for alpha in [0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1, 0.0]:
                w_mix = alpha * w_ai + (1 - alpha) * wt
                w_mix = normalize_mainlobe(w_mix, px, py, pz, u0, v0, w0)
                ev_mix = eval_full_81(w_mix, px, py, pz, th0, ph0, nd)
                mix_pass = (ev_mix['pt'] <= 1.0 and ev_mix['pr'] <= 1.001 and
                           ev_mix['wn'] <= -28.0 and ev_mix['sll'] - t_sll <= -0.5 and
                           np.linalg.norm(w_mix) / (np.linalg.norm(wt) + 1e-30) <= 1.5)
                if mix_pass:
                    alpha_best = alpha; w_final = w_mix; ev_final = ev_mix
                    final_pass = True; used_alpha = True; break
            if not final_pass:
                w_final = wt; ev_final = eval_full_81(wt, px, py, pz, th0, ph0, nd)
                alpha_best = 0.0; used_alpha = True

        results.append({
            'idx': i, 'theta0': th0, 'phi0': ph0,
            'support_label': sl, 'mode': mode,
            'canon_phi': float(canon_ph), 'd4_tid': int(tid),
            'taylor_sll': float(t_sll),
            'ai_sll': float(ev_ai['sll']),
            'final_sll': float(ev_final['sll']),
            'improvement': float(ev_final['sll'] - t_sll),
            'pt': float(ev_final['pt']), 'peak': float(ev_final['pr']),
            'worst_null': float(ev_final['wn']),
            'norm_ratio': float(np.linalg.norm(w_final) / (np.linalg.norm(wt) + 1e-30)),
            'main_err': float(abs(ev_final['mr'] - 1.0)),
            'ai_pass': bool(ai_pass), 'final_pass': bool(final_pass),
            'alpha': float(alpha_best), 'used_alpha': bool(used_alpha),
            'w_re': w_final.real.tolist(), 'w_im': w_final.imag.tolist(),
        })

    return results


def main():
    print('='*70)
    print('D4 Symmetry Fix + v5 Re-evaluation')
    print('='*70)

    coords = load_coords()
    px = coords[:, 0]; py = coords[:, 1]; pz = coords[:, 2]

    # ============================================================
    # 1. 构建D4置换矩阵
    # ============================================================
    print('\n--- Building D4 permutations ---')
    perms = {}
    for tid, name in D4_TRANSFORMS:
        perm = build_permutation(coords, tid)
        perms[tid] = perm
        # 验证一一置换
        is_perm = len(set(perm.tolist())) == N_ELEM
        print(f'  {name}: permutation={is_perm}, unique={len(set(perm.tolist()))}')

    # ============================================================
    # 2. 单元测试
    # ============================================================
    test_pass = run_d4_unit_tests(coords, perms)

    if not test_pass:
        print('\n*** D4 UNIT TESTS FAILED - STOP ***')
        return

    # ============================================================
    # 3. 加载v5模型
    # ============================================================
    model = DeepSetsV2(9, 256, 2)
    model_path = os.path.join(OUTPUT_DIR, 'deepsets_8x8_v5_best.pt')
    model.load_state_dict(torch.load(model_path, map_location='cpu'))
    model.eval()
    print(f'\nModel loaded: {model_path}')

    # 加载配置(标准化参数)
    with open(os.path.join(OUTPUT_DIR, 'config_v5.json')) as f:
        config = json.load(f)
    mean_stats = config['mean_stats']
    std_stats = config['std_stats']

    # ============================================================
    # 4. Canonical推理包装器
    # ============================================================
    wrapper = CanonicalWrapper(model, coords, perms, mean_stats, std_stats)

    # ============================================================
    # 5. 加载数据
    # ============================================================
    npz = np.load(os.path.join(OUTPUT_DIR, 'split_v4_2.npz'), allow_pickle=True)
    labels = npz['labels']; qualities = npz['qualities']
    thetas_all = npz['thetas']; phis_all = npz['phis']
    split = npz['split']; t_sll_all = npz['taylor_sll']

    # 支持域标签
    support_labels = []
    for i in range(len(thetas_all)):
        if labels[i] == 1:
            support_labels.append('valid')
        elif t_sll_all[i] > -15:
            support_labels.append('degraded')
        else:
            support_labels.append('fallback_taylor')

    # ============================================================
    # 6. 评估Block Val (canonical + D4变换)
    # ============================================================
    val_idx = np.where(split == 1)[0]
    print(f'\n--- Block Val ({len(val_idx)} samples) ---')
    val_results = evaluate_with_wrapper(
        wrapper, thetas_all[val_idx], phis_all[val_idx],
        t_sll_all[val_idx], [support_labels[i] for i in val_idx],
        px, py, pz)

    n_pass = sum(1 for r in val_results if r['final_pass'])
    n_ai_pass = sum(1 for r in val_results if r['ai_pass'])
    n_alpha = sum(1 for r in val_results if r['used_alpha'] and r['alpha'] > 0)
    n_taylor = sum(1 for r in val_results if r['alpha'] == 0.0)
    print(f'  AI pass: {n_ai_pass}/{len(val_results)} ({n_ai_pass/len(val_results)*100:.0f}%)')
    print(f'  Final pass (AI+alpha): {n_pass}/{len(val_results)} ({n_pass/len(val_results)*100:.0f}%)')
    print(f'  Alpha fallback: {n_alpha}, Taylor fallback: {n_taylor}')
    print(f'  Mean improvement: {np.mean([r["improvement"] for r in val_results]):+.2f} dB')

    # ============================================================
    # 7. 评估Block Test
    # ============================================================
    test_idx = np.where(split == 2)[0]
    print(f'\n--- Block Test ({len(test_idx)} samples) ---')
    test_results = evaluate_with_wrapper(
        wrapper, thetas_all[test_idx], phis_all[test_idx],
        t_sll_all[test_idx], [support_labels[i] for i in test_idx],
        px, py, pz)

    n_test_pass = sum(1 for r in test_results if r['final_pass'])
    n_test_ai = sum(1 for r in test_results if r['ai_pass'])
    n_test_alpha = sum(1 for r in test_results if r['used_alpha'] and r['alpha'] > 0)
    n_test_taylor = sum(1 for r in test_results if r['alpha'] == 0.0)
    test_pass_rate = n_test_pass / len(test_results) * 100
    print(f'  AI pass: {n_test_ai}/{len(test_results)} ({n_test_ai/len(test_results)*100:.0f}%)')
    print(f'  Final pass (AI+alpha): {n_test_pass}/{len(test_results)} ({test_pass_rate:.0f}%)')
    print(f'  Alpha fallback: {n_test_alpha}, Taylor fallback: {n_test_taylor}')
    print(f'  Mean improvement: {np.mean([r["improvement"] for r in test_results]):+.2f} dB')

    # 高角度
    high_angle = [r for r in test_results if r['theta0'] >= 50]
    if high_angle:
        ha_pass = sum(1 for r in high_angle if r['final_pass'])
        print(f'  High angle (>=50°): {ha_pass}/{len(high_angle)} pass')

    # SLL差中位数(vs SOCP)
    socp_slls = npz['final_sll'][test_idx]
    ai_slls = [r['final_sll'] for r in test_results]
    sll_diffs = [a - s for a, s in zip(ai_slls, socp_slls)]
    print(f'  SLL diff (AI-SOCP) median: {np.median(sll_diffs):.2f} dB')

    # ============================================================
    # 8. 评估Random IID
    # ============================================================
    rt_npz = np.load(os.path.join(OUTPUT_DIR, 'random_iid_test_v4_2.npz'), allow_pickle=True)
    rt_th = rt_npz['thetas']; rt_ph = rt_npz['phis']
    rt_labels = rt_npz['labels']; rt_t_sll = rt_npz['taylor_sll']

    # 支持域标签
    rt_support = []
    for i in range(len(rt_th)):
        if rt_labels[i] == 1:
            rt_support.append('valid')
        elif rt_t_sll[i] > -15:
            rt_support.append('degraded')
        else:
            rt_support.append('unsupported' if rt_npz['worst_null'][i] > -28 else 'fallback_taylor')

    print(f'\n--- Random IID Test ({len(rt_th)} directions) ---')
    rt_results = evaluate_with_wrapper(
        wrapper, rt_th, rt_ph, rt_t_sll, rt_support, px, py, pz)

    rt_valid = [r for r in rt_results if r['support_label'] == 'valid']
    rt_invalid = [r for r in rt_results if r['support_label'] != 'valid']
    rt_v_pass = sum(1 for r in rt_valid if r['final_pass'])
    rt_v_rate = rt_v_pass / len(rt_valid) * 100 if rt_valid else 0
    print(f'  Valid: {len(rt_valid)}, Pass: {rt_v_pass} ({rt_v_rate:.0f}%)')
    print(f'  Invalid: {len(rt_invalid)} (should reject/fallback)')
    for r in rt_invalid:
        print(f'    th={r["theta0"]:.1f} ph={r["phi0"]:.1f} [{r["support_label"]}]: mode={r["mode"]} alpha={r["alpha"]:.1f}')

    # ============================================================
    # 9. D4变换一致性检查
    # ============================================================
    print(f'\n--- D4 Consistency Check (theta=30, phi=0 vs 8 transforms) ---')
    th_test = 30.0; ph_test = 0.0
    wt_test = wrapper.compute_taylor(th_test, ph_test)
    nd_test = get_null_dirs(th_test, ph_test)
    ev_base = eval_full_81(wt_test, px, py, pz, th_test, ph_test, nd_test)
    print(f'  Base: SLL={ev_base["sll"]:.2f} pt={ev_base["pt"]:.4f} peak={ev_base["pr"]:.6f}')

    for tid, name in D4_TRANSFORMS[1:]:  # skip identity
        ph_t = transform_phi(ph_test, tid)
        perm = perms[tid]
        wt_perm = wt_test[perm]
        u0t = np.sin(np.deg2rad(th_test))*np.cos(np.deg2rad(ph_t))
        v0t = np.sin(np.deg2rad(th_test))*np.sin(np.deg2rad(ph_t))
        w0t = np.cos(np.deg2rad(th_test))
        wt_perm_n = normalize_mainlobe(wt_perm, px, py, pz, u0t, v0t, w0t)
        nd_t = get_null_dirs(th_test, ph_t)
        ev_t = eval_full_81(wt_perm_n, px, py, pz, th_test, ph_t, nd_t)
        sll_diff = abs(ev_base['sll'] - ev_t['sll'])
        pt_diff = abs(ev_base['pt'] - ev_t['pt'])
        consistent = sll_diff < 0.1 and pt_diff < 0.01
        print(f'  {name}: SLL={ev_t["sll"]:.2f} pt={ev_t["pt"]:.4f} '
              f'diff={sll_diff:.3f}/{pt_diff:.4f} {"OK" if consistent else "FAIL"}')

    # ============================================================
    # 10. 门槛检查
    # ============================================================
    print(f'\n{"="*70}')
    print('GATE CHECK')
    print(f'{"="*70}')
    print(f'  Block Test final pass: {test_pass_rate:.0f}% (>=80%): {"PASS" if test_pass_rate >= 80 else "FAIL"}')
    print(f'  Random IID valid pass: {rt_v_rate:.0f}% (>=85%): {"PASS" if rt_v_rate >= 85 else "FAIL"}')
    print(f'  SLL diff median: {np.median(sll_diffs):.2f} dB (<=2dB): {"PASS" if abs(np.median(sll_diffs)) <= 2 else "FAIL"}')
    print(f'  D4 unit tests: {"PASS" if test_pass else "FAIL"}')

    # ============================================================
    # 11. 保存
    # ============================================================
    # 权值NPZ
    pred_w_re = np.array([[r['w_re'][j] for j in range(N_ELEM)] for r in test_results])
    pred_w_im = np.array([[r['w_im'][j] for j in range(N_ELEM)] for r in test_results])
    pred_npz = os.path.join(OUTPUT_DIR, 'predictions_v5_d4.npz')
    np.savez(pred_npz, w_re=pred_w_re, w_im=pred_w_im,
             thetas=thetas_all[test_idx], phis=phis_all[test_idx])

    # 结果JSON
    results = {
        'd4_unit_tests_pass': test_pass,
        'block_val': val_results,
        'block_test': test_results,
        'random_iid': rt_results,
        'gate': {
            'block_test_pass': float(test_pass_rate),
            'random_iid_pass': float(rt_v_rate),
            'sll_diff_median': float(np.median(sll_diffs)),
        },
        'perms': {str(tid): perms[tid].tolist() for tid in range(8)},
    }
    res_path = os.path.join(OUTPUT_DIR, 'results_v5_d4.json')
    with open(res_path, 'w') as f:
        json.dump(results, f, indent=2, default=str)

    # D4置换脚本
    # SHA-256
    sha_list = {}
    for name, path in [('results_v5_d4.json', res_path),
                        ('predictions_v5_d4.npz', pred_npz)]:
        with open(path, 'rb') as f:
            sha = hashlib.sha256(f.read()).hexdigest()
        sha_list[name] = sha

    with open(os.path.join(OUTPUT_DIR, 'sha256_v5_d4.txt'), 'w') as f:
        for name, sha in sha_list.items():
            f.write(f'{name}: {sha}\n')
            print(f'  {name}: {sha}')

    print(f'\n{"="*70}')
    print('DONE')
    print(f'{"="*70}')


if __name__ == '__main__':
    main()
